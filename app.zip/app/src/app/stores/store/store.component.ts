import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { BankDetail } from 'src/app/shared/models/bankDetail.model';
import { KycDocument } from 'src/app/shared/models/kycDocument.model';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { StoreEntityService } from '../services/store-entity.service';
import { StoreModel } from '../models/store.model';
import { map } from 'rxjs/operators';
import { ClientEntityService } from 'src/app/clients/services/client-entity.service';
import { Observable } from 'rxjs';
import { ClientModel } from 'src/app/clients/models/client.model';

import { NgxSpinnerService } from "ngx-spinner";
import { SharedService } from 'src/app/shared/service/shared.service';



@Component({
  selector: 'store',
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.css']
})
export class StoreComponent implements OnInit {


  store: StoreModel;

  storeForm: FormGroup;
  alertMessage: string = null;
  editMode: boolean = false;

  buttonText: string = "Submit";
  totalStoreCount: number = -1;

  clients$: Observable<ClientModel[]>;

  constructor(private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private storeEntityService: StoreEntityService,
    private clientEntityService: ClientEntityService,
    private spinner: NgxSpinnerService,
    private sharedService: SharedService) { }

  ngOnInit(): void {
    this.storeForm = this.fb.group({
      id: [''],
      clientId: ['', Validators.required],
      storeName: ['', Validators.required],
      gstn: ['', [Validators.required]],//, Validators.pattern("^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[0-9]{1}$")
      pan: ['', [Validators.required, Validators.pattern("^([A-Z]){5}([0-9]){4}([A-Z]){1}$")]],
      contactName: ['', Validators.required],
      phone: ['', [Validators.required, Validators.pattern("^(?:(?:\\+|0{0,2})91(\\s*[\\-]\\s*)?|[0]?)?[6789]\\d{9}$")]],
      email: ['', [Validators.required, Validators.email]],
      regAddress: [],
      bankDetails: this.fb.array([]),
      kycDocuments: this.fb.array([])
    });

    this.AddBank();
    this.AddKycDocument();

    this.route.params.subscribe(
      (params: Params) => {
        this.editMode = !!params['id'];
        this.buttonText = this.editMode ? "Update" : "Submit";
        if (this.editMode) {

          const storeIdToEdit = +params['id'];

          if (!this.storeEntityService.loaded$) {
            this.storeEntityService.getByKey(storeIdToEdit).subscribe(store => {
              this.PopulateForm(store);
            });
          }
          else {
            this.storeEntityService.entities$.pipe(
              map(stores => stores.find(store => store.id == storeIdToEdit))
            ).subscribe(store => {
              this.PopulateForm(store);
            });
          }

        }
      }
    );

    this.storeEntityService.count$.subscribe(count => {
      this.totalStoreCount = count;
    });


    this.clients$ = this.clientEntityService.entities$;


    this.clientEntityService.loaded$.subscribe(loaded => {
      if(!loaded){
        this.clientEntityService.getAll();
      }
    });


  }

  get f() { return this.storeForm.controls; }

  PopulateForm(store: StoreModel) {
    this.storeForm.patchValue({
      id: store.id,
      clientId: store.clientId,
      storeName: store.storeName,
      contactName: store.contactName,
      phone: store.phone,
      email: store.email
    });


    (<FormGroup>this.storeForm.get('regAddress')).patchValue({
      address1: store.storeAddress.address1,
      address2: store.storeAddress.address2,
      state: store.storeAddress.state,
      city: store.storeAddress.city,
      pincode: store.storeAddress.pincode
    });

    this.storeForm.setControl('bankDetails', this.GetBankFormArray(store.bankDetails));
    this.storeForm.setControl('kycDocuments', this.GetKycDocsFormArray(store.kycDocuments));


    console.log('this.storeForm : ', this.storeForm);
    console.log('this.storeForm value: ', this.storeForm.value);
  }

  SetFormToInitialValues() {
    this.storeForm.patchValue({
      id: '',
      clientId: '',
      storeName: '',
      contactName: '',
      phone: '',
      email: '',
    });


    (<FormGroup>this.storeForm.get('regAddress')).patchValue({
      address1: '',
      address2: '',
      state: '',
      city: '',
      pincode: '',
    });

    this.storeForm.setControl('bankDetails', this.GetBankFormArray([]));
    this.storeForm.setControl('kycDocuments', this.GetKycDocsFormArray([]));
    this.AddBank();
    this.AddKycDocument();
  }

  GetBankFormArray(bankArray: BankDetail[]): FormArray {
    const _formArray = this.fb.array([]);
    bankArray.forEach(element => {
      _formArray.push(this.fb.group({
        bankDet: element
      }));
    });

    console.log('_formArray : ', _formArray);
    return _formArray;
  }

  GetKycDocsFormArray(kycDocArray: KycDocument[]): FormArray {
    const _formArray = this.fb.array([]);
    kycDocArray.forEach(element => {
      _formArray.push(this.fb.group({
        kycDet: element
      }));
    });
    return _formArray;
  }



  AddBank() {
    const _fArray = <FormArray>this.storeForm.get('bankDetails');
    const _bankDet: BankDetail = {
      id: -1,
      accountName: "",
      accountNumber: "",
      accBankName: -1,
      accBranch: -1,
      ifsc: "",
      isActive: true
    };
    const _fgrp = this.fb.group(
      {
        bankDet: _bankDet
      }
    );
    _fArray.push(_fgrp);
  }

  DeleteBank(bankDetIndex: number) {
    (<FormArray>this.storeForm.get('bankDetails')).removeAt(bankDetIndex);
  }

  AddKycDocument() {
    const _fArray = <FormArray>this.storeForm.get('kycDocuments');
    const _kycDet: KycDocument = {
      id: -1,
      document: -1,
      fileName: "",
      base64String: "",
      filePath: ""
    };
    const _fgrp = this.fb.group(
      {
        kycDet: _kycDet
      }
    );
    _fArray.push(_fgrp);
  }

  DeleteKycDocument(kycDocIndex: number) {
    (<FormArray>this.storeForm.get('kycDocuments')).removeAt(kycDocIndex);
  }

  onSubmit() {
    if (!this.storeForm.valid) {
      this.alertMessage = "Please enter valid details";
      this.validateAllFormFields(this.storeForm);
      this.sharedService.setValidateAddress(true);
      this.sharedService.setValidateBankDetails(true);
      this.sharedService.setValidateKycDetails(true); 
      return;
    }
    const formValue = this.storeForm.value;

    const storeData: StoreModel = {
      ...this.store,
      ...this.storeForm.value
    };

    const _bankDetArray: BankDetail[] = [];
    const _kycDocArray: KycDocument[] = [];

    formValue['bankDetails'].forEach(element => {
      const bankDet: BankDetail = element['bankDet'];
      _bankDetArray.push(bankDet);
    });
    formValue['kycDocuments'].forEach(element => {
      const kycDoc: KycDocument = element['kycDet'];
      _kycDocArray.push(kycDoc);
    });

    storeData.storeAddress = formValue.regAddress;
    storeData.bankDetails = _bankDetArray;
    storeData.kycDocuments = _kycDocArray;
    console.log('storeData : ', storeData);
    if (!this.editMode) {

      storeData.id = this.totalStoreCount + 1;
      storeData.createdDate = new Date();


      this.spinner.show();

      this.storeEntityService.add(storeData).subscribe(res => {
        this.spinner.hide();
        this.alertMessage = "Store added successfully";
        this.SetFormToInitialValues();
      },
        error => {
          console.log('error : ', error);
          this.spinner.hide();
          this.alertMessage = error.error.error.statusMessage;
        });;

      //this.storeForm.reset();
    }
    else {
      this.spinner.show();
      this.storeEntityService.update(storeData).subscribe(res => {
        this.spinner.hide();
        this.alertMessage = "Store updated successfully";
      },
        error => {
          console.log('error : ', error);
          this.spinner.hide();
          this.alertMessage = error.error.error.statusMessage;
        });

    }
  }

  closeAlert() {
    this.alertMessage = null;
    if (this.editMode && this.storeForm.valid) {
      this.router.navigateByUrl('/stores');
    }
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
}

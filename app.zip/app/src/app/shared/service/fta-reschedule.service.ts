import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { FtaRescheduleUpdateModel, FtaTimeslotModel } from '../models/fta-reschedule-action.model';

@Injectable({'providedIn' : 'root'})
export class FtaRescheduleService {

    constructor(private http : HttpClient){}

    getFtaTimeSlots(){
        return this.http.get<FtaTimeslotModel[]>(environment.apiUrl + 'order/GetFtaHsrpDeliveryTimeslots').pipe(map(res => res['deliveryTimeslots']));
    }

    updateFtaHsrpRescheduleDate(ftaRescheduleUpdateModel : FtaRescheduleUpdateModel){
        return this.http.post(environment.apiUrl + 'order/UpdateFtaHsrpRescheduleDate',ftaRescheduleUpdateModel).pipe(map(res => res['response']));
    }
}
﻿using iStock.DataAccessLayer.DataContext;
using iStock.DataAccessLayer.IDataOperations;

using iStock.Models;
using iStock.Models.DALModels;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace iStock.DataAccessLayer.DataOperations
{
    public class ApplicationDataOperations : IApplicationDataOperations
    {
        public async Task<string> GetApplicationVersion()
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, ""))
            {
                //var _configRecord = await dbContext.Config.Where(c => c.ConfigName.ToLower() == "version").FirstOrDefaultAsync();

                //if (_configRecord != null)
                //{
                //    return _configRecord.ConfigValue;
                //}
                return "1.0";
            }            
        }

    }
}

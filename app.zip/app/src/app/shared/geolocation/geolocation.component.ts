import { Component, OnInit, forwardRef, Input } from '@angular/core';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, FormGroup, FormBuilder, ControlValueAccessor, Validator, Validators, FormControl } from '@angular/forms';
import { SharedService } from '../service/shared.service';

@Component({
  selector: 'geolocation',
  templateUrl: './geolocation.component.html',
  styleUrls: ['./geolocation.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => GeolocationComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => GeolocationComponent),
      multi: true
    }
  ]
})
export class GeolocationComponent implements OnInit, ControlValueAccessor, Validator {

  @Input() formHeading: string;

  geolocationForm: FormGroup;

  constructor(private fb: FormBuilder,
    private sharedService: SharedService) { }

  public onTouched: () => void = () => { };

  writeValue(val: any): void {
    val && this.geolocationForm.setValue(val, { emitEvent: false });
  }
  registerOnChange(fn: any): void {
    this.geolocationForm.valueChanges.subscribe(fn);
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    isDisabled ? this.geolocationForm.disable() : this.geolocationForm.enable();
  }

  validate(control: import("@angular/forms").AbstractControl): import("@angular/forms").ValidationErrors {
    return this.geolocationForm.valid ? null : { invalidForm: { valid: false, message: "geolocationForm fields are invalid" } };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {  
      const control = formGroup.get(field);             
      if (control instanceof FormControl) {             
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {        
        this.validateAllFormFields(control);            
      } 
    });
  }

  ngOnInit(): void {

    this.geolocationForm = this.fb.group({
      latitude: ['', Validators.required],
      longitude: ['', Validators.required],
    });

    this.sharedService.validateGeolocation$.subscribe(validateGeolocation => {
      if(validateGeolocation){
          this.validateAllFormFields(this.geolocationForm);
      }
    });
  }

  ngOnDestroy(){
    this.sharedService.setValidateGeolocation(false);
  }

  get f() { return this.geolocationForm.controls; }

}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.ResponseModels
{
    public class DocumentViewResponseModel : BaseResponseModel
    {
        public List<DocumentViewModel> CustomerDetails { get; set; }
    }

    public class SingleDocumentViewResponseModel : BaseResponseModel
    {
        public DocumentViewModel CustomerDetails { get; set; }
    }

    public class SearchResponseModel : BaseResponseModel
    {
        public SearchModel DocumentDetails { get; set; }
    }
    public class RejectionReasonResponseModel : BaseResponseModel
    {
        public List<RejectionReasonModel> RejectionReasonDetails { get; set; }
    }
    public class DownloadFileResponseModel : BaseResponseModel
    {
        public DownloadFileModel FileDetails { get; set; }
    }

    public class DocumentTypeResponseModel : BaseResponseModel
    {
        public List<DocumentTypeModel> DocumentTypeDetails { get; set; }
    }
}

import { DefaultDataService, HttpUrlGenerator } from '@ngrx/data';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Update } from '@ngrx/entity';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { UserInfoModel } from '../models/user.model';



@Injectable({providedIn : 'root'})
export class UserListDataService extends DefaultDataService<UserInfoModel>{

  entities: UserInfoModel[] = [];

  constructor(http: HttpClient, httpUrlGenerator: HttpUrlGenerator) {
    super('UserList', http, httpUrlGenerator);
  }


  getAll() : Observable<UserInfoModel[]>{
    return this.http.get(environment.apiUrl + "user/GetAllUserList").pipe(map(response => response['userDetail']));
  }    
  
  update(update : Update<UserInfoModel>): Observable<UserInfoModel>{   
    return this.http.put<UserInfoModel>(environment.apiUrl+ 'user/UpdateUser/'+update.id, update.changes)
                    .pipe(map(response => response['userDetail']));
  }  

}
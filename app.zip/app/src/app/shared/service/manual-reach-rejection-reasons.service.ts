import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ManualReachMasterModel } from '../models/manual-reach-action.model';
import { map } from 'rxjs/operators';

@Injectable({'providedIn' : 'root'})
export class ManualReachRejectionReasonService {

    constructor(private http : HttpClient){}
    
    getManualReachRejectionReasons(storeId : number){
        return this.http.get<ManualReachMasterModel[]>(environment.apiUrl + 'order/GetReachRejectionReasonList/' + storeId)
                                .pipe(map(res=>res['reachRejectionDetails']));
    }
}
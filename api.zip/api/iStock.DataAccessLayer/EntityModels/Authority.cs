﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class Authority
    {
        public int Id { get; set; }
        public string RoutePath { get; set; }
        public string MenuName { get; set; }
        public bool? RoleWise { get; set; }
        public string Roles { get; set; }
        public bool? UserWise { get; set; }
        public string Users { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool? IsActive { get; set; }
    }
}

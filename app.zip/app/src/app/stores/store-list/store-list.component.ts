import { Component, OnInit } from '@angular/core';
import { StoreEntityService } from '../services/store-entity.service';
import { Observable } from 'rxjs';
import { StoreModel } from '../models/store.model';
import { FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';

import * as moment from 'moment';

@Component({
  selector: 'store-list',
  templateUrl: './store-list.component.html',
  styleUrls: ['./store-list.component.css']
})
export class StoreListComponent implements OnInit {

  alertMessage : string = null;

  confirmMessage : string = null;
  clientStores$ : Observable<StoreModel[]>;
  filter = new FormControl('');

  storeIdToDelete : number = -1;

  frameworkComponents : any;

  columnDefs = [
                { 
                  headerName: 'Name', 
                  field: 'storeName', 
                  sortable : true, 
                  filter : true,
                  width : 180, resizable : true                  
                },
    {headerName: 'Client', field: 'clientId', sortable : true, filter : true,width : 180, resizable : true  },
    {headerName: 'Creation Date', field: 'createdDate', sortable : true, filter : true,width : 180,
         resizable : true,
         valueFormatter: function (params) {
          return moment(params.value).format('D-MMM-YYYY');
          } 
      },
    {
      headerName: '',
      cellRenderer: 'editDeleteButtonRenderer',
      cellRendererParams: {
        onEditClick: this.editStore.bind(this),
        onDeleteClick: this.deleteStore.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(private storeEntityService : StoreEntityService,
              private router : Router,
              private route : ActivatedRoute) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }
    this.clientStores$ = this.storeEntityService.entities$;        
  }

  onConfirmOk(){
    if(this.storeIdToDelete > -1){
      this.storeEntityService.delete(this.storeIdToDelete).subscribe(res=>{
        this.alertMessage = "Store deleted successfully";
      },
      error=>{
        this.alertMessage = error.error.error.statusMessage;
      });;
    }
    this.confirmMessage = null;
  }
  onConfirmCancel(){
    this.storeIdToDelete = -1;
    this.confirmMessage = null;
  }

  editStore(storeRow){
    let storeId : number = +storeRow.rowData.id;
    this.router.navigate([storeId,'edit'],{relativeTo:this.route});
  }

  deleteStore(storeRow){
    this.storeIdToDelete = +storeRow.rowData.id;
    this.confirmMessage = "Are you sure to delete store " + this.storeIdToDelete + " ?";
  }

  
  closeAlert() {
    this.alertMessage = null;    
  }

}

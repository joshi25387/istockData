﻿using iStock.CrudBusinessLayer.Interfaces;
using iStock.DataAccessLayer.IDataOperations;
using iStock.Models;
using iStock.Models.ResponseModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace iStock.CrudBusinessLayer
{
    public class StockCrudLogics : IStockCrudLogics
    {
        private readonly IStockDataOperations stockDataOperations;

        public StockCrudLogics(IStockDataOperations stockDataOperations)
        {
            this.stockDataOperations = stockDataOperations;
        }
        public async Task<IActionResult> CreateIncomingOrder(string requestor, IncomingOrderModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model == null)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await stockDataOperations.CreateIncomingOrder(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> DeleteIncomingOrder(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await stockDataOperations.DeleteIncomingOrder(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetIncomingOrderById(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await stockDataOperations.GetIncomingOrderById(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new IncomingOrderSingleResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, IncomingOrderDetails = dataLayerResponse.IncomingOrderDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetIncomingOrders(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await stockDataOperations.GetIncomingOrders(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new IncomingOrderResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, IncomingOrderDetails = dataLayerResponse.IncomingOrderDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> UpdateIncomingOrder(string requestor, IncomingOrderModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model.Id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await stockDataOperations.UpdateIncomingOrder(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }


        public async Task<IActionResult> CreatePerformaInvoice(string requestor, PerformaInvoiceModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model == null)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await stockDataOperations.CreatePerformaInvoice(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> DeletePerformaInvoice(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await stockDataOperations.DeletePerformaInvoice(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
        public async Task<IActionResult> GetPerformaInvoiceById(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await stockDataOperations.GetPerformaInvoiceById(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new PerformaInvoiceSingleResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, PerformaInvoiceDetails = dataLayerResponse.PerformaInvoiceDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
        public async Task<IActionResult> GetPerformaInvoices(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await stockDataOperations.GetPerformaInvoices(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new PerformaInvoiceResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, PerformaInvoiceDetails = dataLayerResponse.PerformaInvoiceDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
        public async Task<IActionResult> UpdatePerformaInvoice(string requestor, PerformaInvoiceModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model.Id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await stockDataOperations.UpdatePerformaInvoice(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
    }
}

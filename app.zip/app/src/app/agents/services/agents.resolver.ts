import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AgentEntityService } from './agent-entity.service';
import { tap, filter, first } from 'rxjs/operators';

@Injectable()
export class AgentsResolver implements Resolve<boolean>{
    
    constructor(private agentsEntityService : AgentEntityService){}
    
    resolve(
             route : ActivatedRouteSnapshot,
             state : RouterStateSnapshot
        ) : Observable<boolean>{

            return this.agentsEntityService.loaded$
                    .pipe(
                        tap(loaded => {
                            if(!loaded){
                                this.agentsEntityService.getAll();
                            }
                        }),
                        filter(loaded => !!loaded),
                        first()
                    );

             
        }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.DALModels
{
    public class UserDetailDALModel : BaseDALStatus
    {
        public List<UserDetailModel> UserDetails { get; set; }
    }

    public class UserDetailSingleDALModel : BaseDALStatus
    {
        public UserDetailModel UserDetail { get; set; }
    }
    //public class UserInfoDALModel : BaseDALStatus
    //{
    //    public List<UserInfoModel> UserDetail { get; set; }
    //}
    //public class UserInfoSingleDALModel : BaseDALStatus
    //{
    //    public UserInfoModel UserDetail { get; set; }
    //}

    public class AgentDetailDALModel : BaseDALStatus
    {
        public FieldAgentDetailModel AgentDetails { get; set; }
    }
}

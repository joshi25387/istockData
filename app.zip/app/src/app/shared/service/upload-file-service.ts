import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { OrderUploadStatusModel } from 'src/app/orders/models/order-upload-status.model';

@Injectable({'providedIn' : 'root'})
export class UploadOrderFileStatusService {

    constructor(private http : HttpClient){}

    getUploadedOrderStatus(){
        return this.http.get<OrderUploadStatusModel[]>(environment.apiUrl + 'order/GetUploadedOrderStatus').pipe(map(res => res['orderUploadStatus']));
    }
}
import { NgModule } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { Routes, RouterModule } from '@angular/router';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import * as fromAuth from './reducers';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { AuthEffects } from './auth.effects';
import { UserManagementComponent } from './user-management/user-management.component';
import { UserStoreMappingComponent } from './user-store-mapping/user-store-mapping.component';
// import { UserCreationComponent } from './user-creation/user-creation.component';
import { UserUpdationComponent } from './user-updation/user-updation.component';
import { UserCreationComponent } from './user-creation/user-creation.component';




// import { BrowserModule } from '@angular/platform-browser';


const authRoutes : Routes = [
    {
        path : "", component : LoginComponent
    },
    {
        path : "user-management", component : UserManagementComponent
    }
    ,
    {
        path : "user-management/create", component : UserCreationComponent
    }
    ,
    {
        path : "user-management/edit", component : UserCreationComponent
    }    
];


@NgModule({
    declarations : [LoginComponent, UserManagementComponent, UserStoreMappingComponent
         , UserCreationComponent
        , UserUpdationComponent],
    imports : [
        
        SharedModule,
        ReactiveFormsModule,
        RouterModule.forChild(authRoutes),
        StoreModule.forFeature(fromAuth.authFeatureKey,
                                fromAuth.authReducer),
        EffectsModule.forFeature([
            AuthEffects
        ])
    ]
})
export class AuthModule {


}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models
{
   public  class RoleModel
    {
        public string Id { get; set; }
        public string Role { get; set; }
    }
}

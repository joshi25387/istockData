// import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpHeaders } from '@angular/common/http';
// import { from } from 'rxjs';
// import { User } from '../auth/models/user.model';

// export class AuthInterceptor implements HttpInterceptor{
//     intercept(req: import("@angular/common/http").HttpRequest<any>, next: import("@angular/common/http").HttpHandler): import("rxjs").Observable<import("@angular/common/http").HttpEvent<any>> {
//         return from(this.handleAccess(req, next));
//     }

//     private async handleAccess(request: HttpRequest<any>, next: HttpHandler):
//         Promise<HttpEvent<any>> {

//         let accesstoken = "";
//         let userId = "";
//         let userRole = "";
        
//         if(localStorage.getItem('user')!=null){            
//             let userDetails : User = JSON.parse(localStorage.getItem('user'));           
//             accesstoken = userDetails.token
//             // userId = userDetails.userId
//             userRole = userDetails.role
//         }
//         console.log('token : ',accesstoken);
//       const token = accesstoken;
//       let changedRequest = request;
      
//       const headerSettings: {[name: string]: string | string[]; } = {};
   
//       for (const key of request.headers.keys()) {
//         headerSettings[key] = request.headers.getAll(key);
//       }
//       if (token!="") {
//         headerSettings['Authorization'] = 'Bearer ' + token;
//         // headerSettings['UserId'] =  userId;
//         headerSettings['UserRole'] = userRole;
//       }
      
//       const newHeader = new HttpHeaders(headerSettings);
      
//       changedRequest = request.clone({
//         headers: newHeader});
//       return next.handle(changedRequest).toPromise();

//     }

// }



/*--------------------------------------------------------------------------------*/

import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable } from 'rxjs';
import {tap} from 'rxjs/operators';
import {Router} from '@angular/router';
import { AppState } from '../reducers';
import { Store } from '@ngrx/store';
import { logout } from '../auth/auth.actions';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private router: Router, private store : Store<AppState>) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const currentUser = JSON.parse(localStorage.getItem('user'));

   // console.log('currentUser : ',currentUser);

    if (currentUser && currentUser.token) {
      request = request.clone({
        setHeaders: {
          //'Content-Type': 'application/json',
          Authorization: `Bearer ${currentUser.token}`
        }
      });
    }

    return next.handle(request).pipe( tap(() => {},
      (err: any) => {
        console.log('error : ', err);
      if (err instanceof HttpErrorResponse) {
        if (err.status !== 401) {
         return;
        }
        this.store.dispatch(logout());        
        this.router.navigate(['login']);
      }
    }));
  }
}
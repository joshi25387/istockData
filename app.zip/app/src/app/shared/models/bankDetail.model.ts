export interface BankDetail{
    id? : number,
    accountName : string,
    accountNumber : string,
    ifsc : string,
    accBankName : number,
    accBranch : number,
    isActive? : boolean
}

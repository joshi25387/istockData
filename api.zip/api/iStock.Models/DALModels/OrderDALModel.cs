﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.DALModels
{
    public class IncomingOrderDALModel : BaseDALStatus
    {
        public List<IncomingOrderModel> IncomingOrderDetails { get; set; }
    }
    public class IncomingOrderSingleDALModel : BaseDALStatus
    {
        public IncomingOrderModel IncomingOrderDetails { get; set; }
    }
    public class PerformaInvoiceDALModel : BaseDALStatus
    { 
        public List<PerformaInvoiceModel> PerformaInvoiceDetails { get; set; }
    }

    public class PerformaInvoiceSingleDALModel : BaseDALStatus
    {
        public PerformaInvoiceModel PerformaInvoiceDetails { get; set; }
    }


}

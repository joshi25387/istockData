﻿using iStock.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace iStock.CrudBusinessLayer.Interfaces
{
    public interface IUserCrudLogics
    {
        Task<IActionResult> GetRoles(string requestor);
        Task<IActionResult> CreateUser(string requestor, UserModel model);
        Task<IActionResult> GetUserAuthority(string requestor);
        Task<IActionResult> GetUserDetails(string requestor);
    }
}

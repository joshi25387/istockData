﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.ResponseModels
{
    public class ArrivalPortMasterResponseModel : BaseResponseModel
    {
        public List<ArrivalPortMasterModel> ArrivalPortDetails { get; set; }
    }
    public class ArrivalPortSingleResponseModel : BaseResponseModel
    {
        public ArrivalPortMasterModel ArrivalPortDetails { get; set; }
    }

    public class CountryMasterResponseModel : BaseResponseModel
    {
        public List<CountryMasterModel> CountryDetails { get; set; }
    }
    public class ItemGroupMasterResponseModel : BaseResponseModel
    {
        public List<ItemGroupMasterModel> ItemGroupDetails { get; set; }
    }

    public class StateMasterResponseModel : BaseResponseModel
    {
        public List<StateMasterModel> StateDetails { get; set; }
    }
    public class CityMasterResponseModel : BaseResponseModel
    {
        public List<CityMasterModel> CityDetails { get; set; }
    }
    public class CountrySingleResponseModel : BaseResponseModel
    {
        public CountryMasterModel CountryDetails { get; set; }
    }
    public class ItemGroupSingleResponseModel : BaseResponseModel
    {
        public ItemGroupMasterModel ItemGroupDetails { get; set; }
    }

    public class DocumentStatusMasterResponseModel : BaseResponseModel
    {
        public List<DocumentStatusMasterModel> DocumentStatusDetails { get; set; }
    }

    public class PartyGroupMasterResponseModel : BaseResponseModel
    {
        public List<PartyGroupMasterModel> PartyGroupDetails { get; set; }
    }
    public class PartyGroupSingleResponseModel : BaseResponseModel
    {
        public PartyGroupMasterModel PartyGroupDetails { get; set; }
    }

    public class PartyMasterResponseModel : BaseResponseModel
    {
        public List<PartyMasterModel> PartyDetails { get; set; }
    }
    public class PartySingleResponseModel : BaseResponseModel
    {
        public PartyMasterModel PartyDetails { get; set; }
    }

    public class ShippingLineMasterResponseModel : BaseResponseModel
    {
        public List<ShippingLineMasterModel> ShippingLineDetails { get; set; }
    }

    public class ItemMasterResponseModel : BaseResponseModel
    {
        public List<ItemMasterModel> ItemDetails { get; set; }
    }
    public class ItemSingleResponseModel : BaseResponseModel
    {
        public ItemMasterModel ItemDetails { get; set; }
    }
}

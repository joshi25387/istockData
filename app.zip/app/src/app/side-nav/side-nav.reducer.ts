import {
    ActionReducer,
    ActionReducerMap,
    createFeatureSelector,
    createSelector,
    MetaReducer,
    createReducer,
    on
  } from '@ngrx/store';
  
  import { SideNavActions } from './side-nav.actionTypes';

  
  export const authFeatureKey = 'auth';
  
  export interface SideNavState {
    visible : boolean
  }
  export const initialSideNavState : SideNavState = {
    visible : false
  }
  
  export const sideNavReducer = createReducer(
    initialSideNavState,
    
    on(SideNavActions.toggleSideNav, (state,action) => {
      return {
        visible : !state.visible
      }
    }),   
    on(SideNavActions.hideSideNav,(state,action) => {
      return{
        visible : false
      }
    })   
  )
  
  
  
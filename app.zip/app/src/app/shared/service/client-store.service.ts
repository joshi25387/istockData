import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { UserClientModel, UserStoreModel } from 'src/app/auth/models/client-store.model';

@Injectable({'providedIn' : 'root'})
export class ClientStoreService {

    constructor(private http : HttpClient){}

    GetUserClientList(){
        return this.http.get<UserClientModel[]>(environment.apiUrl + 'client/GetUserClientList').pipe(map(res => res['clientDetails']));
    }

    GetUserStoreList(clientId){
        return this.http.get<UserStoreModel[]>(environment.apiUrl + 'client/GetUserStoreList?ClientId='+clientId).pipe(map(res => res['storeDetails']));       
    }
}
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentAcknowledgementConfirmComponent } from './payment-acknowledgement-confirm.component';

describe('PaymentAcknowledgementConfirmComponent', () => {
  let component: PaymentAcknowledgementConfirmComponent;
  let fixture: ComponentFixture<PaymentAcknowledgementConfirmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentAcknowledgementConfirmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentAcknowledgementConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

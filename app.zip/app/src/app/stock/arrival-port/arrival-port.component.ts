import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

import { ArrivalPortModel } from '../model/master-data.model';
import { MasterDataService } from '../services/master-data.service';

@Component({
  selector: 'arrival-port',
  templateUrl: './arrival-port.component.html',
  styleUrls: ['./arrival-port.component.css']
})
export class ArrivalPortComponent implements OnInit {

  arrivalPortForm: FormGroup;
  alertMessage: string = null;
  editMode: boolean = false;
  viewMode: boolean = false;
  
  cardText : string = "Add Arrival Port";
  buttonText: string = "Submit";

  errorAlertMessage : string = '';
  
  arrivalPort: ArrivalPortModel;

  constructor(private fb: FormBuilder,
    private router: Router,
    private masterDataService : MasterDataService,
    private route: ActivatedRoute,    
    private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.arrivalPortForm = this.fb.group({
      id: [''],
      city: ['', Validators.required],      
    });

    this.route.params.subscribe(
      (params: Params) => {
        this.editMode = !!params['id'];
        this.buttonText = this.editMode ? "Update" : "Submit";
        if (this.editMode) {
          this.cardText = "Update Arrival Port";
          const arrivalPortIdToEdit = +params['id'];

          this.masterDataService.getArrivalPortById(arrivalPortIdToEdit).subscribe(res=>{
              this.PopulateForm(res);
          });
        }
      }
    );

    this.arrivalPortForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.arrivalPortForm);
    });         
  }


  validationMessages = {
    'city' : {
      'required' : 'City is required'
    }
  };

  formErrors = {
    'city' : ''
  }

  get f() { return this.arrivalPortForm.controls; }

  PopulateForm(arrivalPort: ArrivalPortModel) {
    if (arrivalPort) {      
      this.arrivalPortForm.patchValue({
        id: arrivalPort.id,
        city: arrivalPort.city        
      });
    }
  }


  onSubmit() {

    this.logValidationErrorsOnSubmit();
   
    if(this.errorAlertMessage!=''){
      this.alertMessage = this.errorAlertMessage;
      return;
    }
   
    
    if (!this.arrivalPortForm.valid) {
      this.alertMessage = "Please enter valid details";      
      return;
    }

    

    let formValue = this.arrivalPortForm.getRawValue();
    let arrivalPortData: ArrivalPortModel = {
      ...this.arrivalPort,
      ...formValue
    };
   

    if (!this.editMode) {   
      this.spinner.show();
      arrivalPortData.id = 0;
      this.masterDataService.createArrivalPort(arrivalPortData).subscribe(res=>{
        console.log('res : ',res);
        if(res){
          if(res['statusCode'] == 200){
            this.arrivalPortForm.reset();
          }
          this.alertMessage = res['statusMessage']          
        }
        this.spinner.hide();
      });
    }
    else {
      this.spinner.show();
      this.masterDataService.updateArrivalPort(arrivalPortData).subscribe(res=>{
        console.log('res : ',res);
        this.spinner.hide();
      });
    }
  }

  closeAlert() {
    this.alertMessage = null;    
  }

  logValidationErrors(group : FormGroup = this.arrivalPortForm) : void {
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid &&
          (abstractControl.touched || abstractControl.dirty)){
            const messages = this.validationMessages[key];

            for(const errorKey in abstractControl.errors){
              if(errorKey){
                this.formErrors[key] += messages[errorKey] + ' ';                
              }
            }
          }
      }
    });
  }

  logValidationErrorsOnSubmit(group : FormGroup = this.arrivalPortForm) : void {
    this.errorAlertMessage ='';
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid ){
            const messages = this.validationMessages[key];
            for(const errorKey in abstractControl.errors){
              if(errorKey){
                abstractControl.markAsTouched({ onlySelf: true });
                this.formErrors[key] += messages[errorKey] + ' ';
                if(this.errorAlertMessage == ''){
                  this.errorAlertMessage = messages[errorKey];
                }
              }
            }
          }
      }
    });
  }


}

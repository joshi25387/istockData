// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,


  // apiUrl  :'https://www.softageteledocm.com/LastLapPilotAPI/api/',
  // fileDownloadBaseUrl : 'https://www.softageteledocm.com/LastLapPilotAPI/',
  // reportingApiUrl : 'https://www.softageteledocm.com/SoftAgeReporting/api/',
  // reportingSsrsUrl : 'https://www.softageteledocm.com/SoftAgeReporting/SSRS_Reports/ReportPage.aspx'



  // apiUrl  :'https://www.softageahm.com/LastLapDevAPI/api/',
  // fileDownloadBaseUrl : 'https://www.softageahm.com/LastLapDevAPI/',
  // reportingApiUrl : 'https://www.softageteledocm.com/SoftAgeReporting/api/',
  // reportingSsrsUrl : 'https://www.softageteledocm.com/SoftAgeReporting/SSRS_Reports/ReportPage.aspx'



  apiUrl : 'http://localhost:51797/api/',
  firstMileApiUrl : 'http://localhost:51795/api/',
  fileDownloadBaseUrl : 'http://localhost:51796/',
  reportingApiUrl : 'http://localhost:51177/api/',  
  reportingSsrsUrl : 'https://www.softageteledocm.com/SoftAgeReporting/SSRS_Reports/ReportPage.aspx',


  //  apiUrl  :'http://172.43.44.71/LastLapAPI/api/'


  //apiUrl  :'https://www.softageahm.com/LastLapTestAPI/api/',
  

  
  
 //apiUrl  :'https://www.softageteledocm.com/LastLapAPI/api/',
  

  //reportingApiUrl : 'https://www.softageteledocm.com/SoftAgeReporting/api/',  
  

  
  // apiUrl : 'http://14.142.226.172/LastLapDevAPI/api/',
  // fileDownloadBaseUrl : 'http://14.142.226.172/LastLapDevAPI/'

  // apiUrl  :'https://www.softageteledocm.com/LastLapAPI/api/',
  // fileDownloadBaseUrl :'https://www.softageteledocm.com/LastLapAPI/',
  // reportingApiUrl : 'https://www.softageteledocm.com/SoftAgeReporting/api/',
  // reportingSsrsUrl : 'https://www.softageteledocm.com/SoftAgeReporting/SSRS_Reports/ReportPage.aspx'
  // apiUrl  :'http://14.142.226.172/LastLapAPI/api/'



  //  apiUrl  :'https://www.softageteledocm.com/LastLapPilotAPI/api/',
  //  fileDownloadBaseUrl  :'https://www.softageteledocm.com/LastLapPilotAPI/'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.

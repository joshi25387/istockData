import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';


@Component({
  selector: 'admin-action-renderer',
  template: `
  <div class="btn-group btn-group-sm" role="group">
    <button type="button" class="btn btn-primary btn-sm" (click)="onManualReachActionClick($event)"  title="Manual Reach">&nbsp;<i class="fa fa-edit"></i></button>
    </div>
    `
})

export class AdminActionsRendererComponent implements ICellRendererAngularComp {

  params;
  label: string;

  agInit(params): void {
    this.params = params;
    this.label = this.params.label || null;
  }

  refresh(params?: any): boolean {
    return true;
  }

  onManualReachActionClick($event) {
    if (this.params.onManualReachActionClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onManualReachActionClick(params);
    }
  }

}
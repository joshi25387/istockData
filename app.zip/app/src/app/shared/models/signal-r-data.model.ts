export interface ManualReachNotificationModel{
    count : number;
}
import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ClientModel } from '../models/client.model';
import { ClientEntityService } from '../services/client-entity.service';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';
import * as moment from 'moment';

@Component({
  selector: 'client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.css']
})

export class ClientListComponent implements OnInit {
  
  confirmMessage : string = null;
  alertMessage: string = null;
  clients$: Observable<ClientModel[]>;
  filter = new FormControl('');
  
  clientIdToDelete : number = -1;

  frameworkComponents : any;

  columnDefs = [
    { headerName: 'Client Id', field: 'id', sortable : true, filter : true,width : 90, resizable : true },
    { headerName: 'Client Name', field: 'companyName', sortable : true, filter : true,width : 180 ,resizable : true},
    { headerName: 'Email', field: 'email', sortable : true, filter : true,width : 180 ,resizable : true },
    { headerName: 'Mobile', field: 'phone', sortable : true, filter : true ,width : 180 ,resizable : true},
    { headerName: 'Created On', field: 'createdDate', sortable : true, filter : true,width : 180 ,
          resizable : true,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
      },    
    { headerName: '', cellRenderer: 'editDeleteButtonRenderer', 
    cellRendererParams: {
        onEditClick: this.editClient.bind(this),
        onDeleteClick: this.deleteClient.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(private clientEntityService : ClientEntityService,
    private router : Router,
    private route : ActivatedRoute) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }
    this.clients$ = this.clientEntityService.entities$;  
  }
  onConfirmOk(){
    if(this.clientIdToDelete > -1){
      this.clientEntityService.delete(this.clientIdToDelete).subscribe(res=>{
        this.alertMessage = "Client deleted successfully";
      },
      error=>{
        this.alertMessage = error.error.error.statusMessage;
      });
    }
    this.confirmMessage = null;
  }

  onConfirmCancel(){
    this.clientIdToDelete = -1;
    this.confirmMessage = null;
  }

  editClient(clientRow){
    let clientId : number = +clientRow.rowData.id;
    this.router.navigate([clientId,'edit'],{relativeTo:this.route});
  }

  deleteClient(storeRow){
    this.clientIdToDelete = +storeRow.rowData.id;
    this.confirmMessage = "Are you sure to delete client " + this.clientIdToDelete + " ?";
  }

  closeAlert() {
    this.alertMessage = null;    
  }
  
}

import { ProjectStoreModel } from "src/app/shared/models/order-reallocation.model";

export interface User{
    userId :  string;
    userName : string;
    role : string;
    token : string;

}

export interface UserDetail{
    isLoaded : boolean;    
    name : string;
    role? : string;
    userCode? : string;
}

export interface UserInfoModel{
    id:number;
    userId : string;
    userName : string;
    roleId : string;
    roleName : string;
    emailId : string;
    contactNo : string;
    isActive : boolean;
    clientStoreMappings : ProjectStoreModel[];
    firstName? : string;
    lastName? : string;
    isAdmin? : boolean;
    isClientAdmin? : boolean;
    isClient? : boolean;
    clientId? : number,
    storeId? : number,
    //deviceId? : string
}


export interface UserCreationModel{
    id?:number,
    userName : string,
    firstName : string,
    lastName : string,
    email : string,
    mobileNumber : string,
    roleId : string,
    isClient : boolean,
    isClientAdmin : boolean,
    isAdmin : boolean,
    clientId : number,
    storeId : number,
    //deviceId? : string,
    isActive : boolean
}
export interface UserRoleModel{
    id : string,
    name : string
}


export interface AuthorityModel{
    routePath : string,
    menuName : string
}
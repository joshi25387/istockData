import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';


@Component({
  selector: 'addPo-view-button-renderer',
  template: `
  <div class="btn-group btn-group-sm float-right" role="group">
        <button type="button" class="btn btn-primary btn-sm" (click)="onAddPOClick($event)"  title="Add PO">&nbsp;<i class="fa fa-plus"></i></button> 
       
    </div>
    `
})


// <span style="width: 5px;"></span>                                                           
// <button type="button" class="btn btn-info btn-sm" (click) = "onViewClick($event)" title="View">&nbsp;<i class="fa fa-eye"></i></button>
export class AddPOViewButtonRendererComponent implements ICellRendererAngularComp {

  params;
  label: string;

  agInit(params): void {
    this.params = params;
    this.label = this.params.label || null;
  }

  refresh(params?: any): boolean {
    return true;
  }

  onAddPOClick($event) {
    if (this.params.onAddPOClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onAddPOClick(params);
    }
  }

  onViewClick($event) {
    if (this.params.onViewClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onViewClick(params);
    }
  }
}
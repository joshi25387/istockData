import { Address } from 'src/app/shared/models/address.model';

export interface ClientModel {
    id: number;
    companyName: string;    
    contactName: string;
    phone: number;
    email: string;    
    regAddress : Address;    
    createdBy?: string;
    createdDate? : Date;
    updatedBy?: string;
    updatedDAte? : Date;
    isActive: boolean;
}
﻿using Microsoft.Extensions.Logging;
using System;

namespace iStock.Helpers.Logging
{
    interface ILoggerFactory : IDisposable
    {
        ILogger CreateLogger(string categoryName);
        void AddProvider(ILoggerProvider provider);
    }
}

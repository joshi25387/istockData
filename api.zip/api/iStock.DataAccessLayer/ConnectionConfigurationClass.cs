﻿using Microsoft.Extensions.Configuration;
using System.IO;

namespace iStock.DataAccessLayer
{
    public class ConnectionConfigurationClass
    {
        public string DbConnectionString
        {
            get 
            {
                if (ConnectionAppSettings.Exists())
                {
                    var dbConnectionSettings = ConnectionAppSettings.GetSection("LMDConnection");
                    if (dbConnectionSettings.Exists())
                    {
                        return dbConnectionSettings.Value;
                    }
                    else
                    {
                        return string.Empty;
                    }
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private IConfigurationSection ConnectionAppSettings { get; set; }

        public ConnectionConfigurationClass()
        {
            var configBuilder = new ConfigurationBuilder();
            var settingsFilePath = Path.Combine(Directory.GetCurrentDirectory(), "appSettings.json");
            configBuilder.AddJsonFile(settingsFilePath, false);

            var root = configBuilder.Build();
            ConnectionAppSettings = root.GetSection("ConnectionStrings");            
        }
    }
}

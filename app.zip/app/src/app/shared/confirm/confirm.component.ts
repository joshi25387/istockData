import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'confirm',
  templateUrl: './confirm.component.html',
  styleUrls: ['./confirm.component.css']
})
export class ConfirmComponent implements OnInit {

  @Input() message : string;

  @Output() ok = new EventEmitter<void>();
  @Output() cancel = new EventEmitter<void>();
  constructor() { }

  ngOnInit(): void {
  }

  onOk(){
    this.ok.emit();
  }
  onCancel(){
    this.cancel.emit();
  }

}

import { Injectable } from '@angular/core';
import { UserInfoModel } from '../models/user.model';

@Injectable({providedIn : 'root'})
export class UserDataStorage {

    public userToEdit: UserInfoModel;

    public constructor() { }

}
﻿using AutoMapper;
using iStock.DataAccessLayer.DataOperations;
using iStock.DataAccessLayer.IDataOperations;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.DataAccessLayer
{
    public static class IServiceCollectionExtension
    {
        public static IServiceCollection AddDataAccessLayerDependencies(this IServiceCollection services)
        {
            services.AddAutoMapper(typeof(IServiceCollectionExtension));                      
            services.AddTransient<IUserDataOperations, UserDataOperations>();
            services.AddTransient<IApplicationDataOperations, ApplicationDataOperations>();
            services.AddTransient<IMasterDataDataOperations, MasterDataDataOperations>();
            services.AddTransient<IStockDataOperations, StockDataOperations>();


            return services;
        }
    }
}

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbCalendar, NgbDateAdapter } from '@ng-bootstrap/ng-bootstrap';
import { FtaRescheduleActionModel, FtaRescheduleUpdateModel, FtaTimeslotModel } from '../models/fta-reschedule-action.model';
import { FtaRescheduleService } from '../service/fta-reschedule.service';
import * as moment from 'moment';

@Component({
  selector: 'fta-reschedule-action',
  templateUrl: './fta-reschedule-action.component.html',
  styleUrls: ['./fta-reschedule-action.component.css']
})
export class FtaRescheduleActionComponent implements OnInit {

  @Input() ftaRescheduleActionModel : FtaRescheduleActionModel;

  @Output() reschedule = new EventEmitter<any>();
  @Output() cancel = new EventEmitter<any>();

  showConfirmDialog : boolean = false;
  confirmMessage : string ="";
  alertMessage : string = null;

  deliveryDate : Date = null;
  deliverySlotId : number = -1;

  ftaRescheduleUpdateModel : FtaRescheduleUpdateModel = {};
  

  timeSlots : FtaTimeslotModel[] = [];

  constructor(private ngbCalendar: NgbCalendar, 
    private dateAdapter: NgbDateAdapter<string>,
    private orderFTARescheduleService : FtaRescheduleService) { }

  ngOnInit(): void {
    this.orderFTARescheduleService.getFtaTimeSlots().subscribe(response => {
      if(response){
        this.timeSlots = response;
      }
    });
  }

  onReschedule(){    
    this.confirmMessage = "Are you sure you want to reschedule this order ?";
    this.showConfirmDialog = true;
  }

  onConfirmOk(){
    console.log('yes');
    this.showConfirmDialog = false;
    this.confirmMessage = "";
    //console.log('moment().diff(this.deliveryDate) : ',moment().diff(this.deliveryDate));


    if (this.deliveryDate !=null && this.deliverySlotId > 0) {
      this.ftaRescheduleUpdateModel.orderNo = this.ftaRescheduleActionModel.orderNo;
      this.ftaRescheduleUpdateModel.registrationNo = this.ftaRescheduleActionModel.registrationNo;
      this.ftaRescheduleUpdateModel.deliveryDate = this.deliveryDate;
      this.ftaRescheduleUpdateModel.timeSlotId = this.deliverySlotId;          
      this.reschedule.emit(this.ftaRescheduleUpdateModel);            
    }
    else{
      this.alertMessage = 'Please select delivery date and delivery slot';      
    }    
  }
  onConfirmCancel(){
    this.showConfirmDialog = false;
    this.confirmMessage = "";
  }

  onCancel(){
    this.cancel.emit();
  }

  closeAlert(){
    this.alertMessage = null;
  }

}

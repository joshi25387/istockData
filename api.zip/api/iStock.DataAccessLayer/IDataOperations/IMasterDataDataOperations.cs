﻿using iStock.Models;
using iStock.Models.DALModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace iStock.DataAccessLayer.IDataOperations
{
    public interface IMasterDataDataOperations
    {
        Task<ArrivalPortMasterDALModel> GetArrivalPortMaster(string requestor);
        Task<ArrivalPortSingleDALModel> GetArrivalPortById(string requestor,int id);
        Task<BaseDALStatus> CreateArrivalPort(string requestor, ArrivalPortMasterModel model);
        Task<BaseDALStatus> UpdateArrivalPort(string requestor, ArrivalPortMasterModel model);
        Task<BaseDALStatus> DeleteArrivalPort(string requestor, int id);


        Task<CountryMasterDALModel> GetCountryMaster(string requestor);
        Task<StateMasterDALModel> GetStateMaster(string requestor);
        Task<CityMasterDALModel> GetCityMaster(string requestor,int stateId);
        Task<CountrySingleDALModel> GetCountryById(string requestor,int id);
        Task<BaseDALStatus> CreateCountry(string requestor, CountryMasterModel model);
        Task<BaseDALStatus> UpdateCountry(string requestor, CountryMasterModel model);
        Task<BaseDALStatus> DeleteCountry(string requestor, int id);


        Task<PartyGroupMasterDALModel> GetPartyGroupMaster(string requestor);
        Task<PartyGroupSingleDALModel> GetPartyGroupById(string requestor,int id);
        Task<BaseDALStatus> CreatePartyGroup(string requestor, PartyGroupMasterModel model);
        Task<BaseDALStatus> UpdatePartyGroup(string requestor, PartyGroupMasterModel model);
        Task<BaseDALStatus> DeletePartyGroup(string requestor, int id);


        Task<PartyMasterDALModel> GetPartyMaster(string requestor);
        Task<PartySingleDALModel> GetPartyById(string requestor,int id);
        Task<BaseDALStatus> CreateParty(string requestor, PartyMasterModel model);
        Task<BaseDALStatus> UpdateParty(string requestor, PartyMasterModel model);
        Task<BaseDALStatus> DeleteParty(string requestor, int id);


        
        Task<DocumentStatusMasterDALModel> GetDocumentStatusMaster(string requestor);
        Task<BaseDALStatus> CreateDocumentStatus(string requestor, DocumentStatusMasterModel model);
        Task<BaseDALStatus> UpdateDocumentStatus(string requestor, DocumentStatusMasterModel model);
        Task<BaseDALStatus> DeleteDocumentStatus(string requestor, int id);


        Task<ItemMasterDALModel> GetItemMaster(string requestor);
        Task<ItemSingleDALModel> GetItemById(string requestor,int id);
        Task<BaseDALStatus> CreateItem(string requestor, ItemMasterModel model);
        Task<BaseDALStatus> UpdateItem(string requestor, ItemMasterModel model);
        Task<BaseDALStatus> DeleteItem(string requestor, int id);


        Task<ItemGroupMasterDALModel> GetItemGroupMaster(string requestor);
        Task<ItemGroupSingleDALModel> GetItemGroupById(string requestor, int id);
        Task<BaseDALStatus> CreateItemGroup(string requestor, ItemGroupMasterModel model);
        Task<BaseDALStatus> UpdateItemGroup(string requestor, ItemGroupMasterModel model);
        Task<BaseDALStatus> DeleteItemGroup(string requestor, int id);
    }
}

import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { tap, filter } from 'rxjs/operators';
import { Store, select } from '@ngrx/store';
import { AppState } from '../reducers';
import { isLoggedIn, isLoggedOut } from './auth.selectors';
import { Injectable } from '@angular/core';
import { setUser, login } from './auth.actions';
import { User } from './models/user.model';


@Injectable({'providedIn' : 'root'})
export class AuthGuard implements CanActivate {
    constructor(private store : Store<AppState>, private router  :Router){}
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {           
        return this.store
                    .pipe(
                        select(isLoggedIn),
                        tap(loggedIn => {
                            
                            if(localStorage.getItem('user')){            
                                const user : User = JSON.parse(localStorage.getItem('user'));
                                const userAuthorities = localStorage.getItem('userAuthorities');
                                let _requestedUrl = route['_routerState'].url;                               
                                this.store.dispatch(setUser({user}));                                  
                                if(_requestedUrl == '/stock/home' || userAuthorities.indexOf(_requestedUrl) > -1){
                                    return of(true);
                                }
                                else{
                                    var _urlSplits = userAuthorities.split(',');
                                    let _childPathMatches = false;

                                    _urlSplits.forEach(element => {
                                        if(_requestedUrl.indexOf(element) > -1){                                            
                                            _childPathMatches = true;                                            
                                        }
                                    });      
                                    if(_childPathMatches){
                                        return of(true);
                                    }
                                    else{
                                        this.router.navigateByUrl('/login');                                    
                                    }                                    
                                }                                                      
                            }
                            else{                                
                                this.router.navigateByUrl('/login');                                
                            }                
                        })
                    )
    }
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'inwarding',
  templateUrl: './inwarding.component.html',
  styleUrls: ['./inwarding.component.css']
})
export class InwardingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

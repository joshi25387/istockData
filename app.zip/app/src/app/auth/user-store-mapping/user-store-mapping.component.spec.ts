import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserStoreMappingComponent } from './user-store-mapping.component';

describe('UserStoreMappingComponent', () => {
  let component: UserStoreMappingComponent;
  let fixture: ComponentFixture<UserStoreMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserStoreMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserStoreMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

﻿using iStock.Models;
using iStock.Models.DALModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace iStock.DataAccessLayer.IDataOperations
{
    public interface IUserDataOperations
    {
        Task<RoleDALModel> GetRoles(string requestor);
        Task<UserDetailDALModel> CreateUser(string requestor, UserModel model);
        Task<AuthorityDALModel> GetUserAuthority(string requestor);
        Task<UserDetailDALModel> GetUserDetails(string requestor);
    }
}

import { createAction } from '@ngrx/store';

export const toggleSideNav = createAction(
    "[Header] Toggle Side Nav"
);

export const hideSideNav = createAction(
    "[Login] Hide Side Nav"
);

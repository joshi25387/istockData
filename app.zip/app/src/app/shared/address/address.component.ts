import { Component, OnInit, Input, OnDestroy, forwardRef } from '@angular/core';
import { ControlValueAccessor,NG_VALUE_ACCESSOR,FormGroup, FormBuilder, Validators,NG_VALIDATORS, Validator, FormControl } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { SharedService } from '../service/shared.service';
import { PincodeEntityService } from './services/pincode-entity.service';


@Component({
  selector: 'address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => AddressComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => AddressComponent),
      multi: true
    }
  ]
})
export class AddressComponent implements OnInit,ControlValueAccessor,Validator {


  @Input() formHeading : string;

  addressForm : FormGroup;

  constructor(private fb : FormBuilder,
    private sharedService: SharedService,
    private pincodeEntityService : PincodeEntityService) { }
  
  public onTouched: () => void = () => {};

  writeValue(val: any): void {
    //val && this.addressForm.setValue(val, { emitEvent: false });
    val && this.addressForm.setValue(val);
  }
  registerOnChange(fn: any): void {
    this.addressForm.valueChanges.subscribe(fn);
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    isDisabled ? this.addressForm.disable() : this.addressForm.enable();
  }

  validate(control: import("@angular/forms").AbstractControl): import("@angular/forms").ValidationErrors {
    return this.addressForm.valid ? null : { invalidForm: {valid: false, message: "addressForm fields are invalid"}};
  }
  
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {  
      const control = formGroup.get(field);             
      if (control instanceof FormControl) {             
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {        
        this.validateAllFormFields(control);            
      } 
    });
  }

  ngOnInit(): void {
    this.addressForm = this.fb.group({
      address1 : ['',Validators.required],
      address2 : ['',Validators.required],
      state : [{value : '' , disabled : true}],
      city : [{value : '' , disabled : true}],
      pincode : ['', [Validators.required, Validators.pattern("^[1-9]{1}[0-9]{2}\s{0,1}[0-9]{3}$")]]
    });

    this.addressForm.get('pincode').valueChanges.subscribe(pincode => {
      this.addressForm.patchValue({
        state : '',
        city : ''
      });
      if(pincode.toString().length == 6){
          this.pincodeEntityService.getWithQuery(pincode).subscribe(response => {

            console.log('response : ',response);
             let record = response[0];

             console.log('record : ',record);
            if(record){
              this.addressForm.patchValue({
                state : record.state,
                city : record.city
              });
            }
          });
      }
    });

    this.sharedService.validateAddress$.subscribe(validateAddress => {
      console.log("validateAddress - "+validateAddress);
      if(validateAddress){
          this.validateAllFormFields(this.addressForm);
      }
    });

  } 

  ngOnDestroy(){
    this.sharedService.setValidateAddress(false);
  }

  get f() { return this.addressForm.controls; }
  
}

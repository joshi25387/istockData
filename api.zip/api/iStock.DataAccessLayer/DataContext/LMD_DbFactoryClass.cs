﻿using Microsoft.EntityFrameworkCore.Design;
using System;

namespace iStock.DataAccessLayer.DataContext
{
    /// <summary>
    /// This will help entity framework to identify which DB Context class to use
    /// </summary>
    public class LMD_DbFactoryClass : IDesignTimeDbContextFactory<LMD_DataContext>
    {
        public LMD_DataContext CreateDbContext(string[] args)
        {
            throw new NotImplementedException();
        }
    }
}

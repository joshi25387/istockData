import { createSelector, createFeatureSelector } from '@ngrx/store';
import { AuthState } from './reducers';


export const authState = createFeatureSelector<AuthState>("auth");

export const isLoggedIn = createSelector(
    authState,
    auth => {        
        if(auth){
            return !!auth.user
        }
        else{
            return false;
        }                
    }
);

export const isLoggedOut = createSelector(
    isLoggedIn,
    loggedIn => !loggedIn
);
﻿using iStock.CrudBusinessLayer.Interfaces;
using iStock.Models;
using iStock.Models.DALModels;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
//using SoftAge.EmailService;
//using SoftAge.SMSService;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;


namespace iStock.ApiLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly SignInManager<IdentityUser> _signInManager;

        //private readonly IEmailSender _emailSender;
        //private readonly ISMSSender _smsSender;
        private readonly IUserCrudLogics _userCrudOps;
        private readonly IConfiguration _configuration;

        public UserController(
            UserManager<IdentityUser> userManager,
            RoleManager<IdentityRole> roleManager,
            SignInManager<IdentityUser> signInManager,
            IUserCrudLogics userCrudOps,
            //IEmailSender emailSender,
            //ISMSSender smsSender,
            IConfiguration configuration
            )
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _signInManager = signInManager;
            _configuration = configuration;
           // _emailSender = emailSender;
           // _smsSender = smsSender;
            _userCrudOps = userCrudOps;
        }



        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetUserAuthority")]
        public async Task<IActionResult> GetUserAuthority()
        {
            var requestor = string.Empty;
            var userRole = string.Empty;

            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                var userRoleClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
                if (userRoleClaim != null && !string.IsNullOrWhiteSpace(userRoleClaim.Value))
                {
                    userRole = userRoleClaim.Value;
                }
            }
            return await _userCrudOps.GetUserAuthority(requestor);
        }
    }
}

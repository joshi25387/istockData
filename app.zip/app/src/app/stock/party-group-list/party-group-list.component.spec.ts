import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartyGroupListComponent } from './party-group-list.component';

describe('PartyGroupListComponent', () => {
  let component: PartyGroupListComponent;
  let fixture: ComponentFixture<PartyGroupListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartyGroupListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartyGroupListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

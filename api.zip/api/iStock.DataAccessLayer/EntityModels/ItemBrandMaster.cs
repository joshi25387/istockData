﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class ItemBrandMaster
    {
        public ItemBrandMaster()
        {
            IncomingOrderContainerDetails = new HashSet<IncomingOrderContainerDetails>();
        }

        public int Id { get; set; }
        public int ItemId { get; set; }
        public string ItemBrandName { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual ItemMaster Item { get; set; }
        public virtual ICollection<IncomingOrderContainerDetails> IncomingOrderContainerDetails { get; set; }
    }
}

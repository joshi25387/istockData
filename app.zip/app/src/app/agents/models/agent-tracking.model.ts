export interface AgentTrackingModel{
    projects : AgentTrackingProjectModel[]
}

export interface AgentTrackingProjectModel{
    projectId?  :number;
    projectName : string;    
    agentTrackingDetails : AgentTrackingDetailModel[],
}

export interface AgentTrackingDetailModel{    
    storeName : string,          
    agentName : string,
    agentMobileNo : string,   
    stateName? : string,
    cityName? : string,  
    isLoggedIn : number,
    storeRadius? : string,
    loginTimestamp : string,
    lastUpdatedTimestamp : string,
    lastUpdatedLatitude  :string,
    lastUpdatedLongitude  :string,
    lastUpdatedAddress : string
}
export interface AgentWiseTrackingDataModel{
    agentName : string,
    isLoggedIn : number,
    storeRadius : string,
    loginTimestamp : string,
    lastUpdatedTimestamp : string,
    lastUpdatedLatitude  :string,
    lastUpdatedLongitude  :string,
    lastUpdatedAddress : string
}
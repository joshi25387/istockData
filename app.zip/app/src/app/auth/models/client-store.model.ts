export interface UserClientModel{
    id?: number,
    name : string
}

export interface UserStoreModel{
    id?: number,
    name : string
}
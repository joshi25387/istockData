import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ItemBrandModel, ItemCountModel, ItemGroupModel, ItemModel, ItemPackingModel } from '../model/master-data.model';
import { MasterDataService } from '../services/master-data.service';

@Component({
  selector: 'item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {

  itemForm : FormGroup;
  alertMessage: string = null;
  editMode: boolean = false;
  viewMode: boolean = false;
  
  cardText : string = "Add Item";
  buttonText: string = "Submit";

  errorAlertMessage : string ='';

  itemGroupList : ItemGroupModel[] = [];
  
  item: ItemModel;
  constructor(private fb : FormBuilder,
    private router: Router,
    private masterDataService : MasterDataService,
    private route: ActivatedRoute,    
    private spinner: NgxSpinnerService) { }

  ngOnInit(): void {

    this.itemForm = this.fb.group({
      id : [''],
      itemGroupId : ['',Validators.required],
      itemName : ['',Validators.required],
      itemBrandList : this.fb.array([
        this.addItemBrandFormGroup()
      ]),
      itemPackingList : this.fb.array([
        this.addItemPackingFormGroup()
      ]),
      itemCountList : this.fb.array([
        this.addItemCountFormGroup()
      ])
    });

    this.masterDataService.getItemGroupList().subscribe(res=>{
      this.itemGroupList = res;
    });

    this.route.params.subscribe(
      (params: Params) => {
        this.editMode = !!params['id'];
        this.buttonText = this.editMode ? "Update" : "Submit";
        if (this.editMode) {
          this.cardText = "Update Item";

          const itemIdToEdit = +params['id'];

          this.masterDataService.getItemById(itemIdToEdit).subscribe(res=>{
              this.PopulateForm(res);
          });
        }
      }
    );

    this.itemForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.itemForm);
    });
  }

  PopulateForm(item: ItemModel) {
    if (item) {      
      this.itemForm.patchValue({
        id: item.id,
        itemGroupId : item.itemGroupId,
        itemName : item.itemName    
      });

      this.itemForm.setControl('itemBrandList',this.setExistingItemBrands(item.itemBrandList));
      this.itemForm.setControl('itemPackingList',this.setExistingItemPackings(item.itemPackingList));
      this.itemForm.setControl('itemCountList',this.setExistingItemCounts(item.itemCountList));
    }
  }

  setExistingItemBrands(itemBrands : ItemBrandModel[]) : FormArray{
    const formArray = new FormArray([]);
    itemBrands.forEach(brandRec => {
      const _fg = this.fb.group({
        id : brandRec.id,
        itemBrandName : brandRec.itemBrandName
      });
      formArray.push(_fg);
    });
    return formArray;
  }
  setExistingItemPackings(itemPackings : ItemPackingModel[]) : FormArray{
    const formArray = new FormArray([]);
    itemPackings.forEach(packingRec => {
      const _fg = this.fb.group({
        id : packingRec.id,
        itemPacking : packingRec.itemPacking
      });
      formArray.push(_fg);
    });
    return formArray;
  }
  setExistingItemCounts(itemCounts : ItemCountModel[]) : FormArray{
    const formArray = new FormArray([]);
    itemCounts.forEach(countRec => {
      const _fg = this.fb.group({
        id : countRec.id,
        itemCount : countRec.itemCount
      });
      formArray.push(_fg);
    });
    return formArray;
  }

  validationMessages = {
    'itemGroupId' : {
      'required' : 'Item group is required'
    },
    'itemName' : {
      'required' : 'Item name is required'
    },
    'itemBrandName' : {
      'required' : 'Item brand is required'
    },
    'itemPacking' : {
      'required' : 'Item packing is required'
    },
    'itemCount' : {
      'required' : 'Item count'
    }    
  };

  formErrors = {
    'itemGroupId' : '',
    'itemName' : '',
    'itemBrandName' : '',
    'itemPacking' : '',
    'itemCount' : ''
  }

  get f() { return this.itemForm.controls; }

  addItemBrand() : void{
    (<FormArray>this.itemForm.get('itemBrandList')).push(this.addItemBrandFormGroup());
  }
  addItemPacking() : void{
    (<FormArray>this.itemForm.get('itemPackingList')).push(this.addItemPackingFormGroup());
  }
  addItemCount() : void{
    (<FormArray>this.itemForm.get('itemCountList')).push(this.addItemCountFormGroup());
  }

  addItemBrandFormGroup() : FormGroup{
    return this.fb.group({
      id : [''],
      itemBrandName : ['',Validators.required]
    });
  }
  addItemPackingFormGroup() : FormGroup{
    return this.fb.group({
      id : [''],
      itemPacking : ['',Validators.required]
    });
  }
  addItemCountFormGroup() : FormGroup{
    return this.fb.group({
      id : [''],
      itemCount : ['',Validators.required]
    });
  }

  deleteItemBrand(brandIndex: number) {    
    (<FormArray>this.itemForm.get('itemBrandList')).removeAt(brandIndex);
  }
  deleteItemPacking(packingIndex: number) { 
    (<FormArray>this.itemForm.get('itemPackingList')).removeAt(packingIndex);
  }
  deleteItemCount(countIndex: number) { 
    (<FormArray>this.itemForm.get('itemCountList')).removeAt(countIndex);
  }

  onSubmit() {

    this.logValidationErrorsOnSubmit();
   
    if(this.errorAlertMessage!=''){
      this.alertMessage = this.errorAlertMessage;
      return;
    }
    
    if (!this.itemForm.valid) {
      this.alertMessage = "Please enter valid details";      
      return;
    }

    

    let formValue = this.itemForm.getRawValue();
    let itemData: ItemModel = {
      ...this.item,
      ...formValue
    };
    console.log('itemData : ', itemData);

    if (!this.editMode) {   
      this.spinner.show();
      itemData.id = 0;
      this.masterDataService.createItem(itemData).subscribe(res=>{
        console.log('res : ',res);
        if(res){
          if(res['statusCode'] == 200){
            this.itemForm.reset();
          }
          this.alertMessage = res['statusMessage']          
        }
        this.spinner.hide();
      });
    }
    else {
      this.spinner.show();
      this.masterDataService.updateItem(itemData).subscribe(res=>{
        console.log('res : ',res);
        if(res){
          if(res['statusCode'] == 200){
            this.itemForm.reset();
          }
          this.alertMessage = res['statusMessage']          
        }
        this.spinner.hide();
      });
    }
  }

  closeAlert() {
    this.alertMessage = null;    
  }

  logValidationErrors(group : FormGroup = this.itemForm) : void {
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else if(abstractControl instanceof FormArray){
        abstractControl.controls.forEach(control => {
          if(control instanceof FormGroup){
            this.logValidationErrors(control);
          }
        });              
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid &&
          (abstractControl.touched || abstractControl.dirty)){
            const messages = this.validationMessages[key];

            for(const errorKey in abstractControl.errors){
              if(errorKey){
                this.formErrors[key] += messages[errorKey] + ' ';                
              }
            }
          }
      }
    });
    console.log(this.formErrors);
  }

  logValidationErrorsOnSubmit(group : FormGroup = this.itemForm) : void {
    this.errorAlertMessage ='';
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else if(abstractControl instanceof FormArray){
        abstractControl.controls.forEach(control => {
          if(control instanceof FormGroup){
            this.logValidationErrors(control);
          }
        });              
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid ){
            const messages = this.validationMessages[key];
            for(const errorKey in abstractControl.errors){
              if(errorKey){
                abstractControl.markAsTouched({ onlySelf: true });
                this.formErrors[key] += messages[errorKey] + ' ';
                if(this.errorAlertMessage == ''){
                  this.errorAlertMessage = messages[errorKey];
                }
              }
            }
          }
      }
    });
  }
}

﻿using AutoMapper;
//using iStock.DataAccessLayer.EntityModels;
using iStock.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.DataAccessLayer
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
            //CreateMap<Client, ClientModel>();
        }
    }
}

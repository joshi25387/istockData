import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ApproverRemarkModel, ManualReachActionModel, ManualReachMasterModel, ManualReachRejectionReasonModel } from '../models/manual-reach-action.model';
import { ManualReachRejectionReasonService } from '../service/manual-reach-rejection-reasons.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/internal/operators/map';

@Component({
  selector: 'manualReachAction',
  templateUrl: './manual-reach-action.component.html',
  styleUrls: ['./manual-reach-action.component.css']
})
export class ManualReachActionComponent implements OnInit {

  @Input() manualReachActionModel : ManualReachActionModel;

  @Output() approve = new EventEmitter<any>();
  @Output() reject = new EventEmitter<any>();
  @Output() cancel = new EventEmitter<any>();

  showConfirmDialog : boolean = false;
  confirmMessage : string ="";
  alertMessage : string = null;
  storeId : number;

  manualReachMasterModel$ : Observable<ManualReachMasterModel>;
  rejectionReasonModel$ : Observable<ManualReachRejectionReasonModel[]>;
  approverRemarkModel$ : Observable<ApproverRemarkModel[]>;
  maxDistanceConfig$ : Observable<string>;
  
  //rejectionReasonList$ : Observable<ManualReachRejectionReasonService[]>;

  isRequestApproved : boolean = false;
  reasonId : string = "";

  distanceFromCustomerLocation : number = 0;

  approverRemarkId : string = "";
  maxDistanceConfigValue : number = 7;

  distanceGreaterThanConfig : boolean = false;


  constructor(private manualReachRejectionReasonService : ManualReachRejectionReasonService) { }

  ngOnInit(): void {
    console.log('manualReachActionModel : ',this.manualReachActionModel);

    this.distanceFromCustomerLocation = this.manualReachActionModel.customerDistance;
    this.storeId = this.manualReachActionModel.storeId;
    if(+this.storeId < 0){
      this.storeId = 0;
    }

    this.manualReachMasterModel$ = this.manualReachRejectionReasonService.getManualReachRejectionReasons(this.storeId);
    this.rejectionReasonModel$ = this.manualReachMasterModel$.pipe(map(x=>x.rejectionReasons));
    this.approverRemarkModel$ = this.manualReachMasterModel$.pipe(map(x=>x.approverRemarks));
    this.maxDistanceConfig$ = this.manualReachMasterModel$.pipe(map(x=>x.maxDistanceConfig));

    this.maxDistanceConfig$.subscribe(value=>{
      this.maxDistanceConfigValue = +value;

      if(this.distanceFromCustomerLocation && this.maxDistanceConfigValue){
        this.distanceGreaterThanConfig = (this.distanceFromCustomerLocation > this.maxDistanceConfigValue);
      }    
    });
  }

  onApprove(){
    if(this.distanceFromCustomerLocation)
    {
      if(this.distanceFromCustomerLocation > this.maxDistanceConfigValue)
      {
        if(this.approverRemarkId == ""){
          this.alertMessage = "Please select remarks";
          return;
        }
        this.isRequestApproved = true;
        this.confirmMessage = "Are you sure you want to approve this request ?";
        this.showConfirmDialog = true;
      }
      else
      {
        this.isRequestApproved = true;
        this.confirmMessage = "Are you sure you want to approve this request ?";
        this.showConfirmDialog = true;
      }
    }
    else
    {
      this.isRequestApproved = true;
      this.confirmMessage = "Are you sure you want to approve this request ?";
      this.showConfirmDialog = true;
    }    
  }

  onReject(){
    if(this.reasonId==""){
      this.alertMessage = "Please select reason";
      return;
    }
    this.isRequestApproved = false;
    this.confirmMessage = "Are you sure you want to reject this request ?";
    this.showConfirmDialog = true;
  }

  onConfirmOk(){

    console.log('yes');
    this.showConfirmDialog = false;
    this.confirmMessage = "";
    if(this.isRequestApproved){
      this.approve.emit(this.approverRemarkId);
    }
    else{
      this.reject.emit(this.reasonId);
    }
  }
  onConfirmCancel(){
    this.showConfirmDialog = false;
    this.confirmMessage = "";
  }

  onCancel(){
    this.cancel.emit();
  }

  closeAlert(){
    this.alertMessage = null;
  }

  onMouseOver(infoWindow, gm) {
    if (gm.lastOpen != null) {
        gm.lastOpen.close();
    }
    gm.lastOpen = infoWindow;
    infoWindow.open();
  }
  onMouseOut(gm){
    if (gm.lastOpen != null) {
      gm.lastOpen.close();
    }
  }

}

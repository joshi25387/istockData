import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Observable } from 'rxjs';
import { PartyModel } from '../model/master-data.model';
import { PerformaInvoiceModel } from '../model/order.model';
import { MasterDataService } from '../services/master-data.service';
import { StockService } from '../services/stock.service';
import * as moment from 'moment';

@Component({
  selector: 'performa-invoice',
  templateUrl: './performa-invoice.component.html',
  styleUrls: ['./performa-invoice.component.css']
})
export class PerformaInvoiceComponent implements OnInit {

  performaInvoiceForm : FormGroup;
  alertMessage: string = null;
  editMode: boolean = false;
  viewMode: boolean = false;

  errorAlertMessage : string = '';

  partyList$ : Observable<PartyModel[]>;
  
  vendorList : PartyModel[];
      
  cardText : string = "Performa Invoice";
  buttonText: string = "Submit";
  
  performaInvoice : PerformaInvoiceModel;

  constructor(private fb : FormBuilder,
    private router: Router,
    private masterDataService : MasterDataService,
    private stockService : StockService,
    private route: ActivatedRoute,    
    private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.performaInvoiceForm = this.fb.group({
      id : [''],
      performaInvoiceNo : ['',Validators.required],      
      invoiceDate : ['',Validators.required],
      vendorId : ['',Validators.required],
      amount : ['',Validators.required]      
    });


    this.partyList$ = this.masterDataService.getPartyList();
    

    this.partyList$.subscribe(res=>{      
      this.vendorList = res.filter(r=>r.partyGroupName.toLowerCase() == "vendor");      
    });

    this.route.params.subscribe(
      (params: Params) => {
        this.editMode = !!params['id'];
        this.buttonText = this.editMode ? "Update" : "Submit";
        if (this.editMode) {
          this.cardText = "Update Performa Invoice";
          const performaInvoiceIdToEdit = +params['id'];

          this.stockService.getPerformaInvoiceById(performaInvoiceIdToEdit).subscribe(res=>{
              this.PopulateForm(res);
          });
        }
      }
    );

    this.performaInvoiceForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.performaInvoiceForm);
    });
  }

  validationMessages = {
    'performaInvoiceNo' : {
      'required' : 'Performa invoice no. is required'
    },
    'invoiceDate' : {
      'required' : 'Invoice date is required'
    },
    'vendorId' : {
      'required' : 'Vendor is required'
    },
    'amount' : {
      'required' : 'Amount is required'
    }    
  };

  formErrors = {
    'performaInvoiceNo' : '',
    'invoiceDate' : '',
    'vendorId' : '',
    'amount' : ''
  }

  get f() { return this.performaInvoiceForm.controls; }


  PopulateForm(performaInvoice: PerformaInvoiceModel) {
    if (performaInvoice) {      
      this.performaInvoiceForm.patchValue({
        id: performaInvoice.id,  
        performaInvoiceNo : performaInvoice.performaInvoiceNo,
        invoiceDate : moment(performaInvoice.invoiceDate).format('D-MMM-YYYY') ,
        vendorId : performaInvoice.vendorId,
        amount : performaInvoice.amount
      });
    }
  }

  onSubmit() {
    if (!this.performaInvoiceForm.valid) {
      this.alertMessage = "Please enter valid details";      
      return;
    }

    

    let formValue = this.performaInvoiceForm.getRawValue();
    let performaInvoiceData: PerformaInvoiceModel = {
      ...this.performaInvoice,
      ...formValue
    };
    console.log('performaInvoiceData : ', performaInvoiceData);

    if (!this.editMode) {   
      this.spinner.show();
      performaInvoiceData.id = 0;
      this.stockService.createPerformaInvoice(performaInvoiceData).subscribe(res=>{
        console.log('res : ',res);
        if(res){
          if(res['statusCode'] == 200){
            this.performaInvoiceForm.reset();
          }
          this.alertMessage = res['statusMessage']          
        }
        this.spinner.hide();
      });
    }
    else {
      this.spinner.show();
      this.stockService.updatePerformaInvoice(performaInvoiceData).subscribe(res=>{
        console.log('res : ',res);
        if(res){          
          this.alertMessage = res['statusMessage']          
        }
        this.spinner.hide();
      });
    }
  }
  closeAlert() {
    this.alertMessage = null;    
  }

  logValidationErrors(group : FormGroup = this.performaInvoiceForm) : void {
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else if(abstractControl instanceof FormArray){
        abstractControl.controls.forEach(control => {
          if(control instanceof FormGroup){
            this.logValidationErrors(control);
          }
        });              
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid &&
          (abstractControl.touched || abstractControl.dirty)){
            const messages = this.validationMessages[key];

            for(const errorKey in abstractControl.errors){
              if(errorKey){
                this.formErrors[key] += messages[errorKey] + ' ';                
              }
            }
          }
      }
    });
  }

  logValidationErrorsOnSubmit(group : FormGroup = this.performaInvoiceForm) : void {
    this.errorAlertMessage ='';
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else if(abstractControl instanceof FormArray){
        abstractControl.controls.forEach(control => {
          if(control instanceof FormGroup){
            this.logValidationErrors(control);
          }
        });              
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid ){
            const messages = this.validationMessages[key];
            for(const errorKey in abstractControl.errors){
              if(errorKey){
                abstractControl.markAsTouched({ onlySelf: true });
                this.formErrors[key] += messages[errorKey] + ' ';
                if(this.errorAlertMessage == ''){
                  this.errorAlertMessage = messages[errorKey];
                }
              }
            }
          }
      }
    });
  }

}

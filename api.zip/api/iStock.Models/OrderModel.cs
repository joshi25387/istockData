﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models
{
    public class IncomingOrderModel
    {
        public int? Id { get; set; }
        public string BlNo { get; set; }
        public int? ArrivalPortId { get; set; }
        public string ArrivalPort { get; set; }
        public int? LoadingWeekNo { get; set; }
        public DateTime? EstDateOfLoading { get; set; }
        public DateTime? EstDateOfArrival { get; set; }
        public int? CountryId { get; set; }
        public string Country { get; set; }
        public int? ShipperId { get; set; }
        public string ShipperName { get; set; }
        public string InvoiceNo { get; set; }
        public int? NoOfContainer { get; set; }
        public int? PackingListQty { get; set; }
        public decimal? TotalGrossWeight { get; set; }
        public decimal? NetWeight { get; set; }
        public int? DocumentStatusId { get; set; }
        public string DocumentStatus { get; set; }
        public string VesselNo { get; set; }
        public int? ShippingLineId { get; set; }
        public string ShippingLine { get; set; }
        public string ShippingTerms { get; set; }
        public string PaymentTermsAdv { get; set; }
        public string PaymentTermsOnDoc { get; set; }
        public string PaymentTermsAfterArr { get; set; }
        public decimal? Freight { get; set; }
        public string Currency { get; set; }
        public decimal? ExchangeRate { get; set; }
        public string PhytoNo { get; set; }
        public string CertificateOfOrigin { get; set; }
        public string NonGmoCertificate { get; set; }
        public string PerformaInvoiceNo { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public List<IncomingOrderContainerDetailModel> ContainerDetails { get; set; }
    }

    public class IncomingOrderContainerDetailModel
    {
        public string ContainerNo { get; set; }
        public int? TotalQty { get; set; }
        public List<IncomingOrderContainerItemDetailModel> ContainerItemDetails { get; set; }
    }
    public class IncomingOrderContainerItemDetailModel
    {
        public int? ItemId { get; set; }
        public int? BrandId { get; set; }
        public int? PackingId { get; set; }
        public int? CountId { get; set; }
        public int? Qty { get; set; }
        public string SelfAllocated { get; set; }
        public int? AllocatedPartyId { get; set; }
    }



    public class PerformaInvoiceModel
    {
        public int? Id { get; set; }
        public string PerformaInvoiceNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public int VendorId { get; set; }
        public string VendorName { get; set; }
        public decimal Amount { get; set; }
        public string InvoiceStatus { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}

import { DefaultDataService, HttpUrlGenerator } from '@ngrx/data';
import { Agent } from '../models/agent.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Update } from '@ngrx/entity';

@Injectable()
export class AgentsDataService extends DefaultDataService<Agent>{


  entities: Agent[] = [];

  constructor(http : HttpClient, httpUrlGenerator : HttpUrlGenerator){
      super('Agent',http,httpUrlGenerator);
  }

  agentData : Agent[] = [
    {
      id  :  1,      
      agentName : 'Agent 1',      
      mobile : 9876767676,
      email : 'email.gmail.com',

      permanentAddress : {
        address1 : 'Address1',
        address2 : 'Address2',
        city : 1,
        state : 1,
        pincode : 910989
      },
      currentAddress : {
        address1 : 'Address1',
        address2 : 'Address2',
        city : 1,
        state : 1,
        pincode : 910989
      },
      vehicleType : 1,
      vehicleNumber : "kjhkjhjk9",
      drivingLicenseNo : "DL12345",
      aadharNo : "AAdhar123",
      panNumber : "PAN123",
      agentStoreMapping : [{
        clientId : 1,
        storeId : [1]
     }],
      geolocation : {
        latitude : '76.76868787',
        longitude : '98.980980980'        
      },
      bankDetails : [
        {
          accountName : 'Account name',
          accountNumber : '8768768767867',
          accBankName : 1,
          accBranch : 2,
          ifsc : 'IFSCI1234567'
        }
      ],
      kycDocuments : [
        {
          document : 1,
          fileName : "XYZ",
          base64String : "",
          filePath : ""
        }
      ],
      createdDate : new Date(),
      imeiDetails: ["36521361shdhjfbs2364","sdbfvsmnabzc6516318739"]

    },
    {
      id  :  2,      
      agentName : 'Agent 2',      
      mobile : 9876767676,
      email : 'email.gmail.com',

      permanentAddress : {
        address1 : 'Address1',
        address2 : 'Address2',
        city : 1,
        state : 1,
        pincode : 910989
      },
      currentAddress : {
        address1 : 'Address1',
        address2 : 'Address2',
        city : 1,
        state : 1,
        pincode : 910989
      },
      vehicleType : 1,
      vehicleNumber : "kjhkjhjk9",
      drivingLicenseNo : "DL12345",
      aadharNo : "AAdhar123",
      panNumber : "PAN123",
      agentStoreMapping : [{
         clientId : 2,
         storeId : [2]
      }],
      geolocation : {
        latitude : '76.76868787',
        longitude : '98.980980980'        
      },
      bankDetails : [
        {
          accountName : 'Account name',
          accountNumber : '8768768767867',
          accBankName : 1,
          accBranch : 2,
          ifsc : 'IFSCI1234567'
        }
      ],
      kycDocuments : [
        {
          document : 1,
          fileName : "ABC",
          base64String : "",
          filePath : ""
        }
      ],
      createdDate : new Date(),
      imeiDetails: ["hgsfsafakfhakjfhaskf"]
    }
  ];


  getAll() : Observable<Agent[]>{
     //return this.http.get<Agent[]>('/api/agents');                     
     return of(this.agentData);
  }

  add(agent : Agent) : Observable<Agent>{
    //this.storeData.push(store);
    return of(agent);
  }

  update(update : Update<Agent>): Observable<Agent>{
    let updatedEntity = null;
    this.entities = this.entities.map((e, i) => {
      if ((e as any).id === update.id) {
        updatedEntity = {
          ...e,
          ...update.changes
        };
        return updatedEntity;
      }
      return e;
    });
    return of(updatedEntity);
  }

  delete(id: number): Observable<number> {
    this.entities = this.entities.filter(e => (e as any).id !== id);    
    return of(id);
  }
  

}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.ResponseModels
{
    public class AuthorityResponseModel : BaseResponseModel
    {
        public List<AuthorityModel> AuthorityDetails { get; set; }
    }
}

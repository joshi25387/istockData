import { EntityCollectionServiceBase, EntityCollectionServiceElementsFactory } from '@ngrx/data';
import { StoreModel } from '../models/store.model';
import { Injectable } from '@angular/core';

@Injectable({providedIn : "root"})
export class StoreEntityService extends EntityCollectionServiceBase<StoreModel>{
    constructor(serviceElementsFactory : EntityCollectionServiceElementsFactory){
        super('Store',serviceElementsFactory);
    }
}
import { Component, OnInit, forwardRef, Input, ChangeDetectorRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, FormGroup, FormBuilder, Validators, FormArray, ControlValueAccessor, FormControl } from '@angular/forms';
import { KycDocument } from '../models/kycDocument.model';
import { SharedService } from '../service/shared.service';


@Component({
  selector: 'kyc-document',
  templateUrl: './kyc-document.component.html',
  styleUrls: ['./kyc-document.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => KycDocumentComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => KycDocumentComponent),
      multi: true
    }
  ]
})
export class KycDocumentComponent implements OnInit,ControlValueAccessor {

  kycDocumentForm : FormGroup;

  constructor(private fb : FormBuilder, private cd : ChangeDetectorRef, 
    private sharedService : SharedService) { }  
  
  public onTouched: () => void = () => {};

  writeValue(val: any): void {
    val && this.kycDocumentForm.setValue(val, { emitEvent: false });
  }
  registerOnChange(fn: any): void {
    this.kycDocumentForm.valueChanges.subscribe(fn);
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    isDisabled ? this.kycDocumentForm.disable() : this.kycDocumentForm.enable();
  }

  validate(control: import("@angular/forms").AbstractControl): import("@angular/forms").ValidationErrors {
    return this.kycDocumentForm.valid ? null : { invalidForm: {valid: false, message: "kycDocumentForm fields are invalid"}};
  }
  
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {  
      const control = formGroup.get(field);             
      if (control instanceof FormControl) {             
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {        
        this.validateAllFormFields(control);            
      } 
    });
  }

  ngOnInit(): void {    
    this.kycDocumentForm = this.fb.group({
        id : [''],
        document : ['',Validators.required],
        fileName : ['',Validators.required],
        base64String : [''],
        filePath : ['']
    });

    this.sharedService.validateKycDetails$.subscribe(validateKycDetails => {
      if(validateKycDetails){
          this.validateAllFormFields(this.kycDocumentForm);
      }
    });

    setTimeout(()=>{

      let documentValue = +this.kycDocumentForm.get('document').value;

      if(documentValue <= 0){
        this.kycDocumentForm.patchValue({
          document : '',        
        });
      }
    },0)
  }  

  ngOnDestroy(){
    this.sharedService.setValidateKycDetails(false);
  }

  get f() { return this.kycDocumentForm.controls; }

  onFileChange(evt: any) {
    const file = evt.target.files[0];
  
    if (file) {
      //console.log('file : ',file);
      this.kycDocumentForm.patchValue({
        fileName : file.name
      });    
  
      const reader = new FileReader();
  
      reader.onload = this.handleReaderLoaded.bind(this);
      reader.readAsDataURL(file);
    }
  }
  
  handleReaderLoaded(e) {
    this.kycDocumentForm.patchValue({
      base64String : e.target.result
    });    
  }  
}

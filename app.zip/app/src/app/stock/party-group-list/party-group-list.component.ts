import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { UserDetail } from 'src/app/auth/models/user.model';
import { PartyGroupModel } from '../model/master-data.model';
import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { MasterDataService } from '../services/master-data.service';
import { AuthService } from 'src/app/auth/auth.service';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';

@Component({
  selector: 'party-group-list',
  templateUrl: './party-group-list.component.html',
  styleUrls: ['./party-group-list.component.css']
})
export class PartyGroupListComponent implements OnInit {

  confirmMessage: string = null;  

  partyGroupList$: Observable<PartyGroupModel[]>;
  filter = new FormControl('');

  partyGroupToUpdate: number = -1;

  showAckDialog : boolean = false;
  
  alertMessage:string =null;
  frameworkComponents: any;

  partyGroupIdToDelete : number = -1;

  orderStatusFilter : string;
  storeIdFilter : number;
  userDetail : UserDetail;

  
  columnDefs = [    
    {  headerName: 'Id',field: 'id', sortable: true, filter: true,resizable:true,width:110,pinned:'left'},        
    { headerName: 'Party Group', field: 'groupName', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: 'Created Date', field: 'createdDate', sortable : true, filter : true,width : 180 ,
          resizable : true,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
      },  
    { headerName: 'Created By', field: 'createdBy', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: '', cellRenderer: 'editDeleteButtonRenderer', 
    cellRendererParams: {
        onEditClick: this.editPartyGroup.bind(this),
        onDeleteClick: this.deletePartyGroup.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private masterDataService : MasterDataService,
    private authService : AuthService) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }

    this.authService.userDetail.subscribe(userDet => {      
      this.userDetail = userDet
    });
    this.partyGroupList$ = this.masterDataService.getPartyGroupList();        
  }

  onConfirmOk(){
    if(this.partyGroupIdToDelete > -1){

      this.masterDataService.deletePartyGroup(this.partyGroupIdToDelete).subscribe(res=>{
        if(res){
          this.alertMessage = res['statusMessage'];
          this.partyGroupList$ = this.masterDataService.getPartyGroupList();
        }
      });
    }
    this.confirmMessage = null;
  }

  onConfirmCancel(){
    this.partyGroupIdToDelete = -1;
    this.confirmMessage = null;
  }

  editPartyGroup(partyGroupRow){
    let partyGroupId : number = +partyGroupRow.rowData.id;
    this.router.navigate([partyGroupId,'edit'],{relativeTo:this.route});
  }

  deletePartyGroup(partyGroupRow){
    this.partyGroupIdToDelete = +partyGroupRow.rowData.id;
    this.confirmMessage = "Are you sure to delete party group " + partyGroupRow.rowData.groupName + " ?";
  }
  
  closeAlert() {
    this.alertMessage = null;    
  }

}

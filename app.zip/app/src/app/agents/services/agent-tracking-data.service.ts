import { DefaultDataService, HttpUrlGenerator } from '@ngrx/data';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { AgentTrackingModel } from '../models/agent-tracking.model';


@Injectable({providedIn:'root'})
export class AgentTrackingDataService extends DefaultDataService<AgentTrackingModel>{


  entities: AgentTrackingModel[] = [];

  constructor(http: HttpClient, httpUrlGenerator: HttpUrlGenerator) {
    super('AgentTracking', http, httpUrlGenerator);
  
}
  getAll() : Observable<AgentTrackingModel[]>{
    
    return this.http.get(environment.apiUrl + "AgentTracking/GetAgentTrackingDetails").pipe(map(response => response['agentTrackingData']));
  }  
  
}
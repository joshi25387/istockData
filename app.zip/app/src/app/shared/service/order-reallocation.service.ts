import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { ProjectStoreAgentModel, OrderReallocationModel, ProjectStoreModel } from '../models/order-reallocation.model';

@Injectable({'providedIn' : 'root'})
export class OrderReallocationService {

    constructor(private http : HttpClient){}
    
    GetProjectStoreAgentList(){
        return this.http.get<ProjectStoreAgentModel[]>(environment.apiUrl + 'order/GetProjectStoreAgentList')
                                .pipe(map(res=>res['projectStoreAgentDetails']));
    }

    GetProjectStoreList(){
        return this.http.get<ProjectStoreModel[]>(environment.apiUrl + 'order/GetProjectStoreList')
                                .pipe(map(res=>res['projectStoreDetails']));
    }

    GetOrdersForReallocation(storeId : number){
        return this.http.get<OrderReallocationModel[]>(environment.apiUrl + 'order/GetOrdersForReallocation/' + storeId.toString())
                                .pipe(map(res=>res['orderReallocationDetails']));
    }

    ReallocateOrders(orderList : OrderReallocationModel[]){
        return this.http.put<OrderReallocationModel[]>(environment.apiUrl + 'order/ReallocateOrders' , orderList)
                        .pipe(map(res=>res['orderReallocationDetails']));
    }
}
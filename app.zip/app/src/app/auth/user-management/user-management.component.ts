import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Observable } from 'rxjs';
import { UserManagementRendererComponent } from 'src/app/shared/ag-grid-renderers/user-management-renderer';
import { AuthService } from '../auth.service';
import { UserCreationModel, UserInfoModel } from '../models/user.model';
import { UserDataStorage } from '../services/user-data-storage.service';
import { UserListEntityService } from '../services/user-entity-service';

@Component({
  selector: 'user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {


  
  usersList$: Observable<UserInfoModel[]>;
  filter = new FormControl('');

  userIdToUpdate: number = -1;

  showAckDialog : boolean = false;
  showStoreMappings : boolean = false;

  selectedUserCode : string = '';
  alertMessage:string =null;
  frameworkComponents: any;  
  
  userToEdit : UserInfoModel;
  userToDelete : UserCreationModel;

  confirmMessage: string = null;

  userIdFilter : number;
    
  columnDefs = [    
    {  headerName: 'User Id',field: 'userId', sortable: true, filter: true,resizable:true,width:110,pinned:'left'},        
    { headerName: 'User Name', field: 'userName', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },        
    { headerName: 'Role', field: 'roleName', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' }, 
    { headerName: 'Email Id', field: 'emailId', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' }, 
    { headerName: 'Contact No.', field: 'contactNo', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' }, 
    { headerName: 'Active Status', field: 'isActive', valueFormatter : params => params.data.isActive == true ? 'Yes' : 'No', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },

    //valueFormatter: params => params.data.number.toFixed(2),

    {
      headerName: '', cellRenderer: 'userManagementRenderer',pinned : 'right',
      cellRendererParams: {
        onStoreMappingClick: this.onStoreMapping.bind(this),
        onEditUserClick : this.onEditUser.bind(this),
        onDeleteUserClick : this.onDeleteUser.bind(this),
      },
      type: 'rightAligned'
    }
  ];

  constructor(private userListEntityService: UserListEntityService,
              private router: Router,
              private route: ActivatedRoute,
              private userDataStorage : UserDataStorage,
              private authService : AuthService,
              private spinner: NgxSpinnerService
    ) { }

  ngOnInit(): void {

    this.frameworkComponents = {
      userManagementRenderer: UserManagementRendererComponent      
    }
    //this.usersList$ = this.userListEntityService.entities$;
    this.usersList$ = this.userListEntityService.getAll();
  }  

  onStoreMapping(userRow) {    
    this.selectedUserCode = userRow.rowData.userId;

    if(userRow.rowData.isActive == true){
      this.showStoreMappings = true;
    }
    else{
      this.alertMessage = "Mappings not allowed for inactive users";
    }    
    console.log(userRow.rowData.userId);      
  }

  onEditUser(userRow){
    let _rowData = userRow.rowData;

    this.userToEdit = {
      id : _rowData.id,
      userId : _rowData.userId,
      userName : _rowData.userName,
      firstName : _rowData.firstName,
      lastName : _rowData.lastName,
      contactNo : _rowData.contactNo,
      emailId : _rowData.emailId,
      roleId : _rowData.roleId,
      isActive : _rowData.isActive,
      roleName : _rowData.roleName,
      clientId : _rowData.clientId,
      storeId : _rowData.storeId,
      isAdmin : _rowData.isAdmin,
      isClientAdmin : _rowData.isClientAdmin,
      isClient : _rowData.isClient,
      clientStoreMappings : _rowData.clientStoreMappings
    };

    console.log('editing user : ',this.userToEdit);

    this.userDataStorage.userToEdit = this.userToEdit;
    

    this.router.navigate(['/user/user-management/edit'],{ queryParams : { id : _rowData.userId} }); 

        
  }
  onDeleteUser(userRow){
    console.log('deleting user : ',userRow);
    let _rowData = userRow.rowData;

    this.userToDelete = {
      id : _rowData.id,      
      userName : _rowData.userId,
      firstName : _rowData.firstName,
      lastName : _rowData.lastName,
      mobileNumber : _rowData.contactNo,
      email : _rowData.emailId,
      roleId : _rowData.roleId,
      isActive : false,      
      clientId : _rowData.clientId,
      storeId : _rowData.storeId,
      isAdmin : _rowData.isAdmin,
      isClientAdmin : _rowData.isClientAdmin,
      isClient : _rowData.isClient      
    };
    this.confirmMessage = "Are you sure to delete user " + _rowData.userId + " ?";
  }
  showAllUserList(){
    this.showStoreMappings = false;
  }

  onCancelConfirmOk() {
    if (this.userToDelete && this.userToDelete.userName) {
      this.spinner.show();
      this.authService.updateUser(this.userToDelete).subscribe(response => {
        this.alertMessage = "User deleted successfully";
        this.usersList$ = this.userListEntityService.getAll();
        this.spinner.hide();
      },
      error => {
        this.spinner.hide();
      });
      
    }    
    this.confirmMessage = null;
  }
  onCancelConfirmCancel() {
    this.userToEdit = null;
    this.confirmMessage = null;
  }

  closeAlert() {
    this.alertMessage = null;    
  }
}

import { createAction, props, createFeatureSelector } from '@ngrx/store';
import { User } from './models/user.model';
import { AuthState } from './reducers';


export const loginState = createFeatureSelector<AuthState>("auth");

export const authenticateUser = createAction(
    "[Login Page] Authenticate User",
    props<{userId : string,password : string}>()
);


export const login = createAction(
    "[Login Effect] User Login",
    props<{user : User}>()
)

export const logout = createAction(
    "[Menu] Logout"
)

export const setUser = createAction(
    "[Auth Guard] Set User",
    props<{user : User}>()
)



export const loginFailed = createAction(
    "[Login Effect] Login Failed",
    props<{error : string}>()
)

export const resetErrorMessage = createAction(
    "[Login Controller] Reset Error message"
)


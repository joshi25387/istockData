import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArrivalPortListComponent } from './arrival-port-list.component';

describe('ArrivalPortListComponent', () => {
  let component: ArrivalPortListComponent;
  let fixture: ComponentFixture<ArrivalPortListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArrivalPortListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArrivalPortListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

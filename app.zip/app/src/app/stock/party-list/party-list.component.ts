import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { UserDetail } from 'src/app/auth/models/user.model';
import { PartyModel } from '../model/master-data.model';
import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { MasterDataService } from '../services/master-data.service';
import { AuthService } from 'src/app/auth/auth.service';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';

@Component({
  selector: 'party-list',
  templateUrl: './party-list.component.html',
  styleUrls: ['./party-list.component.css']
})
export class PartyListComponent implements OnInit {

  confirmMessage: string = null;  

  partyList$: Observable<PartyModel[]>;
  filter = new FormControl('');

  partyToUpdate: number = -1;

  showAckDialog : boolean = false;
  
  alertMessage:string =null;
  frameworkComponents: any;

  partyIdToUpdate : number = -1;

  orderStatusFilter : string;
  storeIdFilter : number;
  userDetail : UserDetail;

  
  columnDefs = [    
    {  headerName: 'Id',field: 'id', sortable: true, filter: true,resizable:true,width:110},        
    { headerName: 'Party Name', field: 'partyName', sortable: true, filter: true,resizable:true,width:130 },
    { headerName: 'PAN', field: 'panNo', sortable: true, filter: true,resizable:true,width:130 },
    { headerName: 'Party Group Name', field: 'partyGroupName', sortable: true, filter: true,resizable:true,width:130},
    { headerName: 'Party Address', field: 'partyAddress', sortable: true, filter: true,resizable:true,width:130},
    { headerName: 'State', field: 'stateName', sortable: true, filter: true,resizable:true,width:130},
    { headerName: 'City', field: 'cityName', sortable: true, filter: true,resizable:true,width:130},
    { headerName: 'Contact No.', field: 'contactNo', sortable: true, filter: true,resizable:true,width:130 },
    { headerName: 'Email', field: 'email', sortable: true, filter: true,resizable:true,width:130 },
    { headerName: 'Credit Limit', field: 'creditLimit', sortable: true, filter: true,resizable:true,width:130 },
    { headerName: 'Payment Terms', field: 'paymentTerms', sortable: true, filter: true,resizable:true,width:130 },
    { headerName: 'Created Date', field: 'createdDate', sortable : true, filter : true,width : 180 ,
          resizable : true,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
      },  
    { headerName: 'Created By', field: 'createdBy', sortable: true, filter: true,resizable:true,width:130 },
    { headerName: '', cellRenderer: 'editDeleteButtonRenderer',pinned : 'right',
    cellRendererParams: {
        onEditClick: this.editParty.bind(this),
        onDeleteClick: this.deleteParty.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private masterDataService : MasterDataService,
    private authService : AuthService) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }

    this.authService.userDetail.subscribe(userDet => {      
      this.userDetail = userDet
    });
    this.partyList$ = this.masterDataService.getPartyList();        
  }

  onConfirmOk(){
    if(this.partyIdToUpdate > -1){

      this.masterDataService.deletePartyGroup(this.partyIdToUpdate).subscribe(res=>{
        if(res){
          this.alertMessage = res['statusMessage'];
          this.partyList$ = this.masterDataService.getPartyList();
        }
      });
    }
    this.confirmMessage = null;
  }

  onConfirmCancel(){
    this.partyIdToUpdate = -1;
    this.confirmMessage = null;
  }

  editParty(partyRow){
    let partyId : number = +partyRow.rowData.id;
    this.router.navigate([partyId,'edit'],{relativeTo:this.route});
  }

  deleteParty(partyRow){
    this.partyIdToUpdate = +partyRow.rowData.id;
    this.confirmMessage = "Are you sure to delete party " + partyRow.rowData.partyName + " ?";
  }
  
  closeAlert() {
    this.alertMessage = null;    
  }

}

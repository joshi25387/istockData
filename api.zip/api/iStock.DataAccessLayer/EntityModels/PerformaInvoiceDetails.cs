﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class PerformaInvoiceDetails
    {
        public int Id { get; set; }
        public string PerformaInvoiceNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public int VendorId { get; set; }
        public decimal Amount { get; set; }
        public string InvoiceStatus { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual PartyMaster Vendor { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.ResponseModels
{
    public class IncomingOrderResponseModel : BaseResponseModel
    {
        public List<IncomingOrderModel> IncomingOrderDetails { get; set; }
    }
    public class IncomingOrderSingleResponseModel : BaseResponseModel
    {
        public IncomingOrderModel IncomingOrderDetails { get; set; }
    }
    public class PerformaInvoiceResponseModel : BaseResponseModel
    {
        public List<PerformaInvoiceModel> PerformaInvoiceDetails { get; set; }
    }

    public class PerformaInvoiceSingleResponseModel : BaseResponseModel
    {
        public PerformaInvoiceModel PerformaInvoiceDetails { get; set; }
    }
}

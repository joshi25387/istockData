import { DefaultDataService, HttpUrlGenerator } from '@ngrx/data';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { ClientModel } from '../models/client.model';
import { Update } from '@ngrx/entity';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({providedIn : 'platform'})
export class ClientsDataService extends DefaultDataService<ClientModel>{

  entities: ClientModel[] = [];

  constructor(http : HttpClient, httpUrlGenerator : HttpUrlGenerator){
      super('Client',http,httpUrlGenerator);
  }
  
  getAll() : Observable<ClientModel[]>{
    return this.http.get(environment.apiUrl + "client").pipe(map(response => response['clientList']));
  }
  
  add(client : ClientModel)  : Observable<ClientModel>{    
    return this.http
      .post<ClientModel>(environment.apiUrl + 'client/', client).pipe(map(res=>res['clientData']));
  }
  update(update : Update<ClientModel>): Observable<ClientModel>{   
    return this.http.put<ClientModel>(environment.apiUrl+ 'client/'+update.id, update.changes);
  }

  delete(id: number): Observable<number> {    
  return this.http.delete(environment.apiUrl+ 'client/' + id).pipe(map(res=>id));        
  }
}
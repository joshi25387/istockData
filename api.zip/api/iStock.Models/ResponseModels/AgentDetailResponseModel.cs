﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.ResponseModels
{
    public class AgentDetailResponseModel : BaseResponseModel
    {
        public FieldAgentDetailModel AgentDetails { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace iStock.ApiLayer
{
    public class AuthDbContext : IdentityDbContext
    {
        public AuthDbContext([NotNullAttribute] DbContextOptions options) : base(options)
        {

        }
    }
}

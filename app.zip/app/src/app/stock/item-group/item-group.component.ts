import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { UserDetail } from 'src/app/auth/models/user.model';
import { ItemGroupModel } from '../model/master-data.model';
import * as moment from 'moment';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MasterDataService } from '../services/master-data.service';
import { AuthService } from 'src/app/auth/auth.service';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'item-group',
  templateUrl: './item-group.component.html',
  styleUrls: ['./item-group.component.css']
})
export class ItemGroupComponent implements OnInit {

  itemGroupForm: FormGroup;
  alertMessage: string = null;
  editMode: boolean = false;
  viewMode: boolean = false;
  
  cardText : string = "Add Item Group";
  buttonText: string = "Submit";

  errorAlertMessage : string = '';
  
  itemGroup: ItemGroupModel;

  constructor(private fb: FormBuilder,
    private router: Router,
    private masterDataService : MasterDataService,
    private route: ActivatedRoute,    
    private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.itemGroupForm = this.fb.group({
      id: [''],
      itemGroupName: ['', Validators.required],      
    });

    this.route.params.subscribe(
      (params: Params) => {
        this.editMode = !!params['id'];
        this.buttonText = this.editMode ? "Update" : "Submit";
        if (this.editMode) {
          this.cardText = "Update Item Group";
          const itemGroupIdToEdit = +params['id'];

          this.masterDataService.getItemGroupById(itemGroupIdToEdit).subscribe(res=>{
              this.PopulateForm(res);
          });
        }
      }
    );

    this.itemGroupForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.itemGroupForm);
    });
         
  }

  validationMessages = {
    'itemGroupName' : {
      'required' : 'Item group is required'
    }
  };

  formErrors = {
    'itemGroupName' : ''
  }

  get f() { return this.itemGroupForm.controls; }

  PopulateForm(itemGroup: ItemGroupModel) {
    if (itemGroup) {      
      this.itemGroupForm.patchValue({
        id: itemGroup.id,
        itemGroup: itemGroup.itemGroupName        
      });
    }
  }


  onSubmit() {
    

    this.logValidationErrorsOnSubmit();
   
    if(this.errorAlertMessage!=''){
      this.alertMessage = this.errorAlertMessage;
      return;
    }

    if (!this.itemGroupForm.valid) {
      this.alertMessage = "Please enter valid details";      
      return;
    }

    

    let formValue = this.itemGroupForm.getRawValue();
    let itemGroupData: ItemGroupModel = {
      ...this.itemGroup,
      ...formValue
    };
    

    if (!this.editMode) {   
      this.spinner.show();
      itemGroupData.id = 0;
      this.masterDataService.createItemGroup(itemGroupData).subscribe(res=>{
        console.log('res : ',res);
        if(res){
          if(res['statusCode'] == 200){
            this.itemGroupForm.reset();
          }
          this.alertMessage = res['statusMessage']          
        }
        this.spinner.hide();
      });
    }
    else {
      this.spinner.show();
      this.masterDataService.updateItemGroup(itemGroupData).subscribe(res=>{
        console.log('res : ',res);
        this.spinner.hide();
      });
    }
  }

  closeAlert() {
    this.alertMessage = null;    
  }

  logValidationErrors(group : FormGroup = this.itemGroupForm) : void {
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid &&
          (abstractControl.touched || abstractControl.dirty)){
            const messages = this.validationMessages[key];

            for(const errorKey in abstractControl.errors){
              if(errorKey){
                this.formErrors[key] += messages[errorKey] + ' ';                
              }
            }
          }
      }
    });
  }

  logValidationErrorsOnSubmit(group : FormGroup = this.itemGroupForm) : void {
    this.errorAlertMessage ='';
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid ){
            const messages = this.validationMessages[key];
            for(const errorKey in abstractControl.errors){
              if(errorKey){
                abstractControl.markAsTouched({ onlySelf: true });
                this.formErrors[key] += messages[errorKey] + ' ';
                if(this.errorAlertMessage == ''){
                  this.errorAlertMessage = messages[errorKey];
                }
              }
            }
          }
      }
    });
  }

}

﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class UserInfo
    {
        public int Id { get; set; }
        public string UserCode { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailId { get; set; }
        public string ContactNo { get; set; }
        public string DeviceId { get; set; }
        public string FirebaseId { get; set; }
        public string RoleId { get; set; }
        public string RoleName { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}

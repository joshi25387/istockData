﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models
{
    public class CustomerModel
    {
        public int Id { get; set; }
        public string MobileNo { get; set; }
        public string DocumentType { get; set; }
        public string DocumentPaths { get; set; }
        public string NameMatchedWithPoi { get; set; }
        public string SignatureMatchedWithPoi { get; set; }
        public string PhotoMatchedWithPoi { get; set; }
        public string Status { get; set; }
        public int? RejectionReasonId { get; set; }
        public string Remarks { get; set; }
    }
}

﻿using iStock.CrudBusinessLayer.Interfaces;
using iStock.DataAccessLayer;
using Microsoft.Extensions.DependencyInjection;

namespace iStock.CrudBusinessLayer
{
    public static class IServiceCollectionExtension
    {
        public static IServiceCollection AddCrudBusinessLayerDependencies(this IServiceCollection services)
        {           
            services.AddTransient<IApplicationCrudLogics, ApplicationCrudLogics>();           
            services.AddTransient<IUserCrudLogics,UserCrudLogics>();
            services.AddTransient<IMasterDataCrudLogics,MasterDataCrudLogics>();
            services.AddTransient<IStockCrudLogics,StockCrudLogics>();


            services.AddDataAccessLayerDependencies();
            return services;
        }
    }
}

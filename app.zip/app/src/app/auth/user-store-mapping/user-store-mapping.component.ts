import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ProjectStoreModel } from 'src/app/shared/models/order-reallocation.model';
import { OrderReallocationService } from 'src/app/shared/service/order-reallocation.service';
import { UserInfoModel } from '../models/user.model';
import { UserClientStoreMappingEntityService } from '../services/user-management-entity-service';

@Component({
  selector: 'user-store-mapping',
  templateUrl: './user-store-mapping.component.html',
  styleUrls: ['./user-store-mapping.component.css']
})
export class UserStoreMappingComponent implements OnInit {

  alertMessage: string = null;
  @Input() selectedUserId : string;

  @Output() showUserList = new EventEmitter<any>();

  userInfo : UserInfoModel = {
    id:0,
    userId : '',
    userName : '',
    roleId : '',
    roleName : '',
    emailId : '',
    contactNo : '',
    isActive : false,
    clientStoreMappings : []
  };
  

  projectStoreList : ProjectStoreModel[] = [];
  

  constructor(private orderReallocationService : OrderReallocationService, private fb : FormBuilder,
    private spinner : NgxSpinnerService,
    private userClientStoreMappingEntityService : UserClientStoreMappingEntityService) { }

  ngOnInit(): void {
    
    this.spinner.show();
    this.orderReallocationService.GetProjectStoreList().subscribe(res => {
      this.projectStoreList = res;
      this.userClientStoreMappingEntityService.getWithQuery(this.selectedUserId).subscribe(response => {
        this.userInfo = response[0];
        this.userInfo.clientStoreMappings.forEach(mapping => {
          var _storeRecordArray = this.projectStoreList.filter(p=>p.id == mapping.id)[0].storeList;          
          mapping.storeList.forEach(_store => {           
            var _storeRecord = _storeRecordArray.filter(s=>s.id == _store.id)[0];
            _storeRecord.selected = _store.selected;
          });                    
        });        
        this.spinner.hide();
      },
      error=>{
        this.spinner.hide();
      });
    });    
  } 

  onStoreSelected(event,projectId : number,storeId : number){    
    var _projectRecord = this.projectStoreList.filter(p=>p.id == projectId)[0];    
    var _storeRecord = _projectRecord.storeList.filter(s=>s.id == storeId)[0];
    _storeRecord.selected = event.target.checked;    
  }

  onShowUserList(){
    this.showUserList.emit();
  }

  onSubmit(){

    var _updatedUserInfo = {
      ...this.userInfo,
      clientStoreMappings : this.projectStoreList
    };

    //this.userInfo.clientStoreMappings = this.projectStoreList;
    this.spinner.show();
    this.userClientStoreMappingEntityService.update(_updatedUserInfo).subscribe(res => {
      this.spinner.hide();
      this.alertMessage = "Mappings updated successfully";
    },
      error => {
        console.log('error : ', error);
        this.spinner.hide();
        this.alertMessage = error.error.error.statusMessage;
      });
    
  }
  closeAlert() {
    this.alertMessage = null;    
  }

}

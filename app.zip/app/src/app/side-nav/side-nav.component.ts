import { Component, OnInit } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { AppState } from '../reducers';
import { isLoggedIn } from '../auth/auth.selectors';
import { logout } from '../auth/auth.actions';
import { isVisible } from './side-nav-selectors';
import { UserDetailDataService } from '../shared/service/user-data.service';
import { UserDetail, User, AuthorityModel } from '../auth/models/user.model';
import { map } from 'rxjs/operators';
import { AuthService } from '../auth/auth.service';


@Component({
  selector: 'side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit {

  isLoggedIn$ : Observable<boolean>;

  isVisible$  :Observable<boolean>;

  userDetail : UserDetail = {
    isLoaded : false,                    
    name : "",
    role : ""
  };

  userDet$ : Observable<UserDetail>;


  authorities : AuthorityModel[] = [];

  constructor(private store : Store<AppState>,    
    private authService  : AuthService) { }

  ngOnInit(): void {            
    this.isLoggedIn$ = this.store.pipe(select(isLoggedIn));
    this.isVisible$ = this.store.pipe(select(isVisible));


    this.authService.userDetail.subscribe(userDet => {   
    
      
      if(userDet){
        this.userDetail = userDet;
        this.authService.getAuthority().subscribe(res=>{    
          this.authorities = res;

          let _authorisedPaths = [];
          res.forEach(element => {
            _authorisedPaths.push(element['routePath']);
          });

          localStorage.setItem('userAuthorities',_authorisedPaths.join());
        });
      }            
    });        
  }

  

}

export interface OrderReallocationModel{
    id : number,
    orderNo : number,
    orderDate : Date,
    billId : string,
    orderStatus : string,
    clientName : string,
    pickupStore : string,
    agentId  : number,
    agentName : string
}

export interface ProjectStoreAgentModel{
    id:number,
    projectName : string,
    storeAgentList : StoreAgentMappingModel[]
}

export interface StoreAgentMappingModel{
    id : number,
    storeName : string,
    agentList : AgentModel[]
}

export interface AgentModel{
    id : number,
    agentCode : string,
    agentName : string
} 

export interface ProjectStoreModel{
    id:number,
    projectName : string,
    storeList : StoreMappingModel[]
}
export interface StoreMappingModel{
    id:number,
    storeName : string,
    selected : boolean
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.DALModels
{
    public class ArrivalPortMasterDALModel : BaseDALStatus
    {
        public List<ArrivalPortMasterModel> ArrivalPortDetails { get; set; }
    }

    public class ArrivalPortSingleDALModel : BaseDALStatus
    {
        public ArrivalPortMasterModel ArrivalPortDetails { get; set; }
    }

    public class CountryMasterDALModel : BaseDALStatus
    {
        public List<CountryMasterModel> CountryDetails { get; set; }
    }
    public class StateMasterDALModel : BaseDALStatus
    {
        public List<StateMasterModel> StateDetails { get; set; }
    }
    public class CityMasterDALModel : BaseDALStatus
    {
        public List<CityMasterModel> CityDetails { get; set; }
    }
    public class CountrySingleDALModel : BaseDALStatus
    {
        public CountryMasterModel CountryDetails { get; set; }
    }

    public class DocumentStatusMasterDALModel : BaseDALStatus
    {
        public List<DocumentStatusMasterModel> DocumentStatusDetails { get; set; }
    }

    public class PartyGroupMasterDALModel : BaseDALStatus
    {
        public List<PartyGroupMasterModel> PartyGroupDetails { get; set; }
    }
    public class PartyGroupSingleDALModel : BaseDALStatus
    {
        public PartyGroupMasterModel PartyGroupDetails { get; set; }
    }

    public class PartyMasterDALModel : BaseDALStatus
    {
        public List<PartyMasterModel> PartyDetails { get; set; }
    }
    public class PartySingleDALModel : BaseDALStatus
    {
        public PartyMasterModel PartyDetails { get; set; }
    }

    public class ShippingLineMasterDALModel : BaseDALStatus
    {
        public List<ShippingLineMasterModel> ShippingLineDetails { get; set; }
    }

    public class ItemGroupMasterDALModel : BaseDALStatus
    {
        public List<ItemGroupMasterModel> ItemGroupDetails { get; set; }
    }
    public class ItemGroupSingleDALModel : BaseDALStatus
    {
        public ItemGroupMasterModel ItemGroupDetails { get; set; }
    }

    public class ItemMasterDALModel : BaseDALStatus
    {
        public List<ItemMasterModel> ItemDetails { get; set; }
    }
    public class ItemSingleDALModel : BaseDALStatus
    {
        public ItemMasterModel ItemDetails { get; set; }
    }
}

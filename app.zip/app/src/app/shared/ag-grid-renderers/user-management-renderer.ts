import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';


@Component({
  selector: 'user-management-renderer',
  template: `
  <div class="btn-group btn-group-sm" role="group">
  <button type="button" class="btn btn-primary btn-sm" (click)="onDeleteUserClick($event)"  title="Delete User">&nbsp;<i class="fa fa-minus"></i></button>
  <span style="width: 5px;"></span> 
  <button type="button" class="btn btn-primary btn-sm" (click)="onEditUserClick($event)"  title="Edit User">&nbsp;<i class="fa fa-edit"></i></button>
  <span style="width: 5px;"></span> 
    <button type="button" class="btn btn-primary btn-sm" (click)="onStoreMappingClick($event)"  title="Store Mapping">&nbsp;<i class="fa fa-user"></i></button>
    </div>
    `
})

export class UserManagementRendererComponent implements ICellRendererAngularComp {

  params;
  label: string;

  agInit(params): void {
    this.params = params;
    this.label = this.params.label || null;
  }

  refresh(params?: any): boolean {
    return true;
  }

  onStoreMappingClick($event) {
    if (this.params.onStoreMappingClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onStoreMappingClick(params);
    }
  }

  onEditUserClick($event) {
    if (this.params.onEditUserClick instanceof Function) {
      // put anything into params u want pass into parents component
      console.log('edit button clicked');
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onEditUserClick(params);
    }
  }

  onDeleteUserClick($event) {
    if (this.params.onDeleteUserClick instanceof Function) {
      // put anything into params u want pass into parents component

      console.log('delete button clicked');
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onDeleteUserClick(params);
    }
  }

}
﻿namespace iStock.Models.ResponseModels
{
    public class BaseResponseModel
    {
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }
    }

    public class ClientBaseResponseModel
    {
        public string Message { get; set; }
        public int AdditionalStatusCode { get; set; }
    }
}

﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;

namespace iStock.Helpers
{
    public static class ExcelDataSetHelper
    {
        public static void ToCSV(this DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            //headers  
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);
            foreach (DataRow dr in dtDataTable.Rows)
            {
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        string value = dr[i].ToString();
                        if (value.Contains(','))
                        {
                            value = String.Format("\"{0}\"", value);
                            sw.Write(value);
                        }
                        else
                        {
                            sw.Write(dr[i].ToString());
                        }
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }

        public static DataTable ToDataTable<T>(this IEnumerable<T> collection)
        {
            DataTable dt = new DataTable("DataTable");
            Type t = typeof(T);
            PropertyInfo[] pia = t.GetProperties();

            //Inspect the properties and create the columns in the DataTable
            foreach (PropertyInfo pi in pia)
            {
                Type ColumnType = pi.PropertyType;
                if ((ColumnType.IsGenericType))
                {
                    ColumnType = ColumnType.GetGenericArguments()[0];
                }
                dt.Columns.Add(pi.Name, ColumnType);
            }

            //Populate the data table
            foreach (T item in collection)
            {
                DataRow dr = dt.NewRow();
                dr.BeginEdit();
                foreach (PropertyInfo pi in pia)
                {
                    if (pi.GetValue(item, null) != null)
                    {
                        dr[pi.Name] = pi.GetValue(item, null);
                    }
                }
                dr.EndEdit();
                dt.Rows.Add(dr);
            }
            return dt;
        }

        public static DataSet ReadExcelFileIntoDataSet(string filePath, int sheetIndex)
        {
            if (!File.Exists(filePath))
            {
                return null;
            }
            FileStream stream = File.Open(filePath, FileMode.Open, FileAccess.Read);
            IExcelDataReader excelReader = null;

            if (Path.GetExtension(filePath).Trim().Equals(".XLSX", StringComparison.CurrentCultureIgnoreCase))
            {
                excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);
            }
            else
            {

                excelReader = ExcelReaderFactory.CreateBinaryReader(stream);
            }

            try
            {
                var result = excelReader.AsDataSet(new ExcelDataSetConfiguration()
                {
                    ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                    {
                        UseHeaderRow = true
                    }
                });

                //if (result.Tables[sheetIndex].Rows.Count <= 0)
                //{
                //    return new DataTable();
                //}
                //DataTable filteredRows = result.Tables[sheetIndex].Rows.Cast<DataRow>()
                //                               .Where(row => !row.ItemArray.All(field => field is System.DBNull))
                //                               .CopyToDataTable();

                //DataTable filteredRows = (DataTable)result.Tables[sheetIndex];
                excelReader.Close();
                excelReader.Dispose();
                //return filteredRows;
                //return result.Tables[sheetIndex];
                return result;
            }
            catch (Exception ex)
            {
                excelReader.Dispose();
                throw;
            }
        }

        public static DataTable ReadExcelFileIntoDataTable(string filePath, int sheetIndex)
        {
            if (!File.Exists(filePath))
            {
                return null;
            }
            FileStream stream = File.Open(filePath, FileMode.Open, FileAccess.Read);
            IExcelDataReader excelReader = null;

            if (Path.GetExtension(filePath).Trim().Equals(".XLSX", StringComparison.CurrentCultureIgnoreCase))
            {
                excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);
            }
            else
            {

                excelReader = ExcelReaderFactory.CreateBinaryReader(stream);
            }

            try
            {
                var result = excelReader.AsDataSet(new ExcelDataSetConfiguration()
                {
                    ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                    {
                        UseHeaderRow = true
                    }
                });
                
                
                if (result.Tables[sheetIndex].Rows.Count <= 0)
                {
                    return new DataTable();
                }
                DataTable filteredRows = result.Tables[0];
                //DataTable filteredRows = result.Tables[sheetIndex].Rows.Cast<DataRow>()
                //                               .Where(row => !row.ItemArray.All(field => field is System.DBNull))
                //                               .CopyToDataTable();
                
                excelReader.Close();
                excelReader.Dispose();
                return filteredRows;                
            }
            catch (Exception ex)
            {
                excelReader.Dispose();
                throw;
            }
        }
    }
}

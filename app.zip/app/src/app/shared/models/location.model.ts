export interface LocationCoordinate{
    id? : number;
    latitude : string,
    longitude : string,
    createdBy? : string,
    resolvedAddress? : string,
    createdDate? : Date,
    updatedBy? : string,
    updatedDate? : Date,
    isActive? : boolean
}

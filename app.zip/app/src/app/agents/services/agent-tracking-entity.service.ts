import { EntityCollectionServiceBase, EntityCollectionServiceElementsFactory } from '@ngrx/data';
import { Injectable } from '@angular/core';
import { AgentTrackingModel } from '../models/agent-tracking.model';


@Injectable({providedIn  :'root'})
export class AgentTrackingEntityService extends EntityCollectionServiceBase<AgentTrackingModel> {
  constructor(serviceElementsFactory : EntityCollectionServiceElementsFactory){
      super('AgentTracking',serviceElementsFactory);
  }
}
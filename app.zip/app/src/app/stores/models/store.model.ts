import { Address } from 'src/app/shared/models/address.model';
import { LocationCoordinate } from 'src/app/shared/models/location.model';
import { BankDetail } from 'src/app/shared/models/bankDetail.model';
import { KycDocument } from 'src/app/shared/models/kycDocument.model';


export interface StoreModel{
    id? :number;
    storeName : string;
    clientId : number;    
    clientName? : string;    
    contactName : string;
    phone : string;
    email : string;
    storeUrl? : string;
    pan? : string;
    gstn? : string;
    storeAddress : Address;
    addressResolved? : boolean;
    geoLocationModel : LocationCoordinate;
    bankDetails : BankDetail[];
    kycDocuments : KycDocument[];
    createdBy? : string;
    createdDate? : Date;
    updatedBy? : string;
    updatedDate? : Date;
    isActive? : boolean;
}

import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { UserDetail } from 'src/app/auth/models/user.model';
import { ItemGroupModel } from '../model/master-data.model';
import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { MasterDataService } from '../services/master-data.service';
import { AuthService } from 'src/app/auth/auth.service';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';

@Component({
  selector: 'item-group-list',
  templateUrl: './item-group-list.component.html',
  styleUrls: ['./item-group-list.component.css']
})
export class ItemGroupListComponent implements OnInit {

  confirmMessage: string = null;  

  itemGroupList$: Observable<ItemGroupModel[]>;
  filter = new FormControl('');

  itemGroupToUpdate: number = -1;

  showAckDialog : boolean = false;
  
  alertMessage:string =null;
  frameworkComponents: any;

  itemGroupIdToDelete : number = -1;

  orderStatusFilter : string;
  itemGroupIdFilter : number;
  userDetail : UserDetail;

  
  columnDefs = [    
    {  headerName: 'Id',field: 'id', sortable: true, filter: true,resizable:true,width:110,pinned:'left'},        
    { headerName: 'Item Group', field: 'itemGroupName', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: 'Created Date', field: 'createdDate', sortable : true, filter : true,width : 180 ,
          resizable : true,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
      },  
    { headerName: 'Created By', field: 'createdBy', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: '', cellRenderer: 'editDeleteButtonRenderer', 
    cellRendererParams: {
        onEditClick: this.editItemGroup.bind(this),
        onDeleteClick: this.deleteItemGroup.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private masterDataService : MasterDataService,
    private authService : AuthService) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }

    this.authService.userDetail.subscribe(userDet => {      
      this.userDetail = userDet
    });
    this.itemGroupList$ = this.masterDataService.getItemGroupList();        
  }

  onConfirmOk(){
    if(this.itemGroupIdToDelete > -1){

      this.masterDataService.deleteItemGroup(this.itemGroupIdToDelete).subscribe(res=>{
        if(res){
          this.alertMessage = res['statusMessage'];
          this.itemGroupList$ = this.masterDataService.getItemGroupList();
        }
      });
    }
    this.confirmMessage = null;
  }

  onConfirmCancel(){
    this.itemGroupIdToDelete = -1;
    this.confirmMessage = null;
  }

  editItemGroup(itemGroupRow){
    let itemGroupId : number = +itemGroupRow.rowData.id;
    this.router.navigate([itemGroupId,'edit'],{relativeTo:this.route});
  }

  deleteItemGroup(itemGroupRow){
    this.itemGroupIdToDelete = +itemGroupRow.rowData.id;
    this.confirmMessage = "Are you sure to delete item group " + itemGroupRow.rowData.itemGroupName + " ?";
  }
  
  closeAlert() {
    this.alertMessage = null;    
  }

}

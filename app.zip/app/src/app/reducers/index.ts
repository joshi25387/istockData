import {
    ActionReducer,
    ActionReducerMap,    
    MetaReducer
    
  } from '@ngrx/store';
  import { environment } from '../../environments/environment';
  import {routerReducer} from '@ngrx/router-store';
import { AuthActions } from '../auth/action-types';
import { User } from '../auth/models/user.model';
import { sideNavReducer } from '../side-nav/side-nav.reducer';

  
  export interface AppState {
  
  }
  
  export const reducers: ActionReducerMap<AppState> = {
      router: routerReducer,
      sideNav : sideNavReducer
  };
  

  

  export function logger(reducer:ActionReducer<any>)
      : ActionReducer<any> {
      return (state, action) => {           
          return reducer(state, action);
      }
  
  }
  

  export function setAuthStateFromStorage(reducer : ActionReducer<AppState>) : ActionReducer<AppState>{
    return(state,action) => {
  
      if(action.type == AuthActions.setUser.type){          
          if(localStorage.getItem('user')){      
              const user : User = JSON.parse(localStorage.getItem('user'));                   
              return reducer({
                auth : {
                  user
                }
              },action)                            
          }
      }    
        return reducer(state,action);
    }
  }

  export function clearState(reducer) {
    return function (state, action) {
      
      if (action.type === AuthActions.logout.type) {     
                 
        state = undefined;
      }
 
      return reducer(state, action);
    };
  }
  
  export const metaReducers: MetaReducer<AppState>[] =
      !environment.production ? [logger,setAuthStateFromStorage,clearState] : [];
  
  
  
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.ResponseModels
{
    public class RoleResponseModel : BaseResponseModel
    {
        public List<RoleModel> RoleList { get; set; }
    }
}

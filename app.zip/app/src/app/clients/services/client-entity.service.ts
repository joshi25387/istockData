import { EntityCollectionServiceBase, EntityCollectionServiceElementsFactory } from '@ngrx/data';
import { ClientModel } from '../models/client.model';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ClientEntityService extends EntityCollectionServiceBase<ClientModel>{
    constructor(serviceElementsFactory : EntityCollectionServiceElementsFactory){
        super('Client',serviceElementsFactory);
    }    
}
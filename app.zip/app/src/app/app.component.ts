import { Component, OnInit } from '@angular/core';
import { Event, Router,NavigationStart, NavigationEnd } from '@angular/router';

import { Store, select } from '@ngrx/store';
import { AppState } from './reducers';

import { Observable } from 'rxjs';
import { isVisible } from './side-nav/side-nav-selectors';
import { NgxSpinnerService } from "ngx-spinner";
import { hideSideNav } from './side-nav/side-nav.actions';
import { UserDetailEntityService } from './shared/service/user-entity.service';
import { AuthService } from './auth/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'control-panel-app';

  isNavVisible$  :Observable<boolean>;

  constructor(private router  :Router, private store : Store<AppState>,
    private spinner: NgxSpinnerService,
    private authService : AuthService,
    private userDetailEntityService : UserDetailEntityService
    ){
      
  }
  ngOnInit(): void {    

    this.router.events.subscribe((routerEvent : Event) => {
      this.store.dispatch(hideSideNav());
    
      if(routerEvent instanceof NavigationStart){
        this.spinner.show();
      }

      if(routerEvent instanceof NavigationEnd){
        this.spinner.hide();
      }
    });


    this.userDetailEntityService.getAll().subscribe(data => {  
      console.log('data : ',data);  
      this.authService.setUserDetail(data[0]);
    });
    
    this.isNavVisible$ = this.store.pipe(select(isVisible));    
  }  
}

import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';


@Component({
  selector: 'acknowledge-cancel-button-renderer',
  template: `
  <div class="btn-group btn-group-sm float-right" role="group">
        <button type="button" [ngStyle]="{'background-color': disableAckButton ? 'green' : '#FFC900' }" [disabled] = "disableAckButton" class="btn btn-success btn-sm" (click)="onAcknowledgeClick($event)"  title="{{disableAckButton ? 'No Action Required' : 'Acknowledge Payment'}}">&nbsp;<i class="fa fa-check"></i></button>         
        <span style="width: 5px;"></span> 
        <button type="button" [disabled] = "disableOrderButton" class="btn btn-danger btn-sm" (click)="onCancelOrderClick($event)"  title="Cancel Order">&nbsp;<i class="fa fa-ban"></i></button> 
       
    </div>
    `
})
//*ngIf="params.data.orderStatus == 'Delivered' && params.data.paymentAcknowledged == false && params.data.paymentDoneByCash == true"
//*ngIf="params.data.orderStatus == 'Pending'"


// <span style="width: 5px;"></span>                                                           
// <button type="button" class="btn btn-info btn-sm" (click) = "onViewClick($event)" title="View">&nbsp;<i class="fa fa-eye"></i></button>
export class AcknowledgeCancelButtonRendererComponent implements ICellRendererAngularComp {

  params;
  label: string;

  disableAckButton : boolean = true;
  disableOrderButton : boolean = true;


  agInit(params): void {
    this.params = params;
    console.log('this.params : ',this.params)
    this.label = this.params.label || null;


    if(params.data.orderStatus == 'Delivered' && params.data.paymentAcknowledged == false && params.data.paymentDoneByCash == true){
      this.disableAckButton = false;
    }
    if(params.data.orderStatus == 'Pending'){
      this.disableOrderButton = false;
    }

  }

  refresh(params?: any): boolean {
    return true;
  }

  onAcknowledgeClick($event) {
    if (this.params.onAcknowledgeClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onAcknowledgeClick(params);
    }
  }

  onReschduleOrderClick($event) {
    if (this.params.onReschduleOrderClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onReschduleOrderClick(params);
    }
  }

  onCancelOrderClick($event) {
    if (this.params.onCancelOrderClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onCancelOrderClick(params);
    }
  }
}
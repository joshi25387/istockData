import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { UserDetail } from 'src/app/auth/models/user.model';
import { PerformaInvoiceModel } from '../model/order.model';
import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { MasterDataService } from '../services/master-data.service';
import { AuthService } from 'src/app/auth/auth.service';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';
import { StockService } from '../services/stock.service';

@Component({
  selector: 'performa-invoice-list',
  templateUrl: './performa-invoice-list.component.html',
  styleUrls: ['./performa-invoice-list.component.css']
})
export class PerformaInvoiceListComponent implements OnInit {

  confirmMessage: string = null;  

  performaInvoiceList$: Observable<PerformaInvoiceModel[]>;
  filter = new FormControl('');

  performaInvoiceToUpdate: number = -1;

  showAckDialog : boolean = false;
  
  alertMessage:string =null;
  frameworkComponents: any;

  performaInvoiceIdToUpdate : number = -1;
  
  userDetail : UserDetail;

  
  columnDefs = [    
    {  headerName: 'Id',field: 'id', sortable: true, filter: true,resizable:true,width:110},        
    { headerName: 'Performa Invoice No.', field: 'performaInvoiceNo', sortable: true, filter: true,resizable:true,width:130 },    
    { headerName: 'Invoice Date', field: 'invoiceDate', sortable : true, filter : true,width : 180 ,
          resizable : true,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
    },  
    { headerName: 'Vendor', field: 'vendorName', sortable: true, filter: true,resizable:true,width:130},
    { headerName: 'Amount', field: 'amount', sortable: true, filter: true,resizable:true,width:130},    
    { headerName: 'Created By', field: 'createdBy', sortable: true, filter: true,resizable:true,width:130 },
    { headerName: 'Created Date', field: 'createdDate', sortable : true, filter : true,width : 180 ,
          resizable : true,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
    },  
    { headerName: '', cellRenderer: 'editDeleteButtonRenderer',pinned : 'right',
    cellRendererParams: {
        onEditClick: this.editPerformaInvoice.bind(this),
        onDeleteClick: this.deletePerformaInvoice.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private stockService : StockService,
    private authService : AuthService) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }

    this.authService.userDetail.subscribe(userDet => {      
      this.userDetail = userDet
    });
    this.performaInvoiceList$ = this.stockService.getPerformaInvoiceList();
  }

  onConfirmOk(){
    if(this.performaInvoiceIdToUpdate > -1){

      this.stockService.deletePerformaInvoice(this.performaInvoiceIdToUpdate).subscribe(res=>{
        if(res){
          this.alertMessage = res['statusMessage'];
          this.performaInvoiceList$ = this.stockService.getPerformaInvoiceList();
        }
      });
    }
    this.confirmMessage = null;
  }

  onConfirmCancel(){
    this.performaInvoiceIdToUpdate = -1;
    this.confirmMessage = null;
  }

  editPerformaInvoice(partyRow){
    let partyId : number = +partyRow.rowData.id;
    this.router.navigate([partyId,'edit'],{relativeTo:this.route});
  }

  deletePerformaInvoice(partyRow){
    this.performaInvoiceIdToUpdate = +partyRow.rowData.id;
    this.confirmMessage = "Are you sure to delete performa invoice " + partyRow.rowData.performaInvoiceNo + " ?";
  }
  
  closeAlert() {
    this.alertMessage = null;    
  }

}

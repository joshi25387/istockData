export interface ManualReachActionModel{
    orderNo : string,
    agentName : string,
    agentNumber : string,
    manualReachRequestDate : string,
    storeId : number,
    storeLat : string,
    storeLong : string,
    agentGeoAddress : string,
    agentLat : string,
    agentLong : string,
    customerAddress : string,
    customerLat : string,
    customerLong : string,
    customerDistance : number,
    lastLocationLat : number,
    lastLocationLong : number,
    lastLocationAddress : string,
    distanceFromLastLocation : number,
    lastActionTimestamp : string,
    customerNumber : string
}

export interface ManualReachMasterModel{
    rejectionReasons : ManualReachRejectionReasonModel[],
    approverRemarks : ApproverRemarkModel[],
    maxDistanceConfig : string
}

export interface ManualReachRejectionReasonModel{
    reasonId : number,
    rejectionReason : string
}
export interface ApproverRemarkModel{
    id : number,
    remarks : string
}


export const environment = {
  production: true,
  // apiUrl  :'http://172.43.44.71/LastLapAPI/api/'
  // apiUrl  :'http://14.142.226.172/LastLapAPI/api/'
  

   //-----------LIVE-------------------------
  // apiUrl  :'https://www.softageteledocm.com/LastLapAPI/api/',
  // firstMileApiUrl :'https://www.softageteledocm.com/LastLapFMAPI/api/',
  // fileDownloadBaseUrl : 'https://www.softageteledocm.com/LastLapAPI/',
  // reportingApiUrl : 'https://www.softageteledocm.com/SoftAgeReporting/api/',
  // reportingSsrsUrl : 'https://www.softageteledocm.com/SoftAgeReporting/SSRS_Reports/ReportPage.aspx'

  // //-----------LIVE PILOT-------------------------
  // apiUrl  :'https://www.softageteledocm.com/LastLapPilotAPI/api/',
  // fileDownloadBaseUrl : 'https://www.softageteledocm.com/LastLapPilotAPI/',
  // reportingApiUrl : 'https://www.softageteledocm.com/SoftAgeReporting/api/',
  // reportingSsrsUrl : 'https://www.softageteledocm.com/SoftAgeReporting/SSRS_Reports/ReportPage.aspx'



  //-----------DEV SERVER-------------------------
  
  // apiUrl  : 'http://14.142.226.172/LastLapDevAPI/api/',
  // fileDownloadBaseUrl : 'http://14.142.226.172/LastLapDevAPI/',
  // reportingApiUrl : 'https://www.softageteledocm.com/SoftAgeReporting/api/',
  // reportingSsrsUrl : 'https://www.softageteledocm.com/SoftAgeReporting/SSRS_Reports/ReportPage.aspx'


  //-----------TESTING-------------------------
  apiUrl  :'https://www.softageahm.com/LastLapTestAPI/api/',
  firstMileApiUrl :'https://www.softageahm.com/FirstMileTestApi/api/',
  fileDownloadBaseUrl : 'https://www.softageahm.com/LastLapTestAPI/',
  reportingApiUrl : 'https://www.softageteledocm.com/SoftAgeReporting/api/',
  reportingSsrsUrl : 'https://www.softageteledocm.com/SoftAgeReporting/SSRS_Reports/ReportPage.aspx'


  //-----------DEV TESTING-------------------------
  // apiUrl  :'https://www.softageahm.com/LastLapDevAPI/api/',
  // firstMileApiUrl :'https://www.softageahm.com/FirstMileApi/api/',
  // fileDownloadBaseUrl : 'https://www.softageahm.com/LastLapDevAPI/',
  // reportingApiUrl : 'https://www.softageteledocm.com/SoftAgeReporting/api/',
  // reportingSsrsUrl : 'https://www.softageteledocm.com/SoftAgeReporting/SSRS_Reports/ReportPage.aspx'



  // apiUrl  :'http://14.142.226.172/LastLapDevAPI/api/'
  // apiUrl  :'http://14.142.226.172/LastLapTestAPI/api/',
  // fileDownloadBaseUrl : 'http://14.142.226.172/LastLapTestAPI/'


  // apiUrl  :'http://14.142.226.172/LastLapDevAPI/api/',
  // fileDownloadBaseUrl : 'http://14.142.226.172/LastLapDevAPI/'

  // apiUrl  :'http://14.142.226.172/LastLapTestAPI/api/',
  // fileDownloadBaseUrl : 'http://14.142.226.172/LastLapTestAPI/'

  // apiUrl  :'https://www.softageteledocm.com/LastLapPilotAPI/api/',
  // fileDownloadBaseUrl : 'https://www.softageteledocm.com/LastLapPilotAPI/'
  
};

﻿using iStock.Models;
using iStock.Models.DALModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace iStock.DataAccessLayer.IDataOperations
{
    public interface IStockDataOperations
    {
        Task<IncomingOrderDALModel> GetIncomingOrders(string requestor);
        Task<IncomingOrderSingleDALModel> GetIncomingOrderById(string requestor, int id);
        Task<BaseDALStatus> CreateIncomingOrder(string requestor, IncomingOrderModel model);
        Task<BaseDALStatus> UpdateIncomingOrder(string requestor, IncomingOrderModel model);
        Task<BaseDALStatus> DeleteIncomingOrder(string requestor, int id);



        Task<PerformaInvoiceDALModel> GetPerformaInvoices(string requestor);
        Task<PerformaInvoiceSingleDALModel> GetPerformaInvoiceById(string requestor, int id);
        Task<BaseDALStatus> CreatePerformaInvoice(string requestor, PerformaInvoiceModel model);
        Task<BaseDALStatus> UpdatePerformaInvoice(string requestor, PerformaInvoiceModel model);
        Task<BaseDALStatus> DeletePerformaInvoice(string requestor, int id);
    }
}

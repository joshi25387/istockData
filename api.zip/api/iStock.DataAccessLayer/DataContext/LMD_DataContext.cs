﻿using Audit.EntityFramework;
using Audit.EntityFramework.Providers;
using iStock.DataAccessLayer.EntityModels;
using iStock.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace iStock.DataAccessLayer.DataContext
{
    public partial class LMD_DataContext : DbContext
    {
        /// <summary>
        /// This class allows us to initiate our connection to database along with it's entities
        /// </summary>
        public class OptionsBuild
        {
            /// <summary>
            /// This is an API that allows us to configure our connection to DB
            /// </summary>
            public DbContextOptionsBuilder<LMD_DataContext> OptionsBuilder { get; set; }

            /// <summary>
            /// This allows us to obtain and hold Db information
            /// </summary>
            public DbContextOptions<LMD_DataContext> Options { get; set; }

            private ConnectionConfigurationClass ConnectionConfiguration { get; set; }

            public OptionsBuild()
            {
                ConnectionConfiguration = new ConnectionConfigurationClass();
                OptionsBuilder = new DbContextOptionsBuilder<LMD_DataContext>();
                OptionsBuilder.UseSqlServer(ConnectionConfiguration.DbConnectionString);
                Options = OptionsBuilder.Options;
            }
        }

        ///Audit.Net elements used to implement Auto Audit trails
        private static readonly DbContextHelper _helper = new DbContextHelper();
        private readonly IAuditDbContext _auditContext;

        public static OptionsBuild option = new OptionsBuild();

        #region Constructors
        public LMD_DataContext(DbContextOptions<LMD_DataContext> options, string requestUser): base(options) 
        {            
            //registering Audit.Net classes to extend auto audit functionality
            _auditContext = new DefaultAuditContext(this);            
            _helper.SetConfig(_auditContext);
        }

        //To restrict default constructor
        private LMD_DataContext() { }
        #endregion
       
        /// Intercepting calls to SaveChanges() / SaveChangesAsync() on DbContext, to generate Audit.NET events with the affected entities information.
        /// Each call to SaveChanges generates an audit event that includes information of all the entities affected by the save operation.

        #region Overrides
        public override int SaveChanges()
        {
            SaveUpdateTrail();
            return _helper.SaveChanges(_auditContext, () => base.SaveChanges());
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            SaveUpdateTrail();
            return await _helper.SaveChangesAsync(_auditContext, () => base.SaveChangesAsync(cancellationToken));
        }

        public string RequestUser { get; set; }
        private void SaveUpdateTrail()
        {
            var updatedEntityList = ChangeTracker.Entries().Where(x => x.State == EntityState.Modified);

            List<AuditTrailLog> _auditTrailLogs = new List<AuditTrailLog>();

            foreach (var entity in updatedEntityList)
            {
                var entityPrimaryKey = entity.Metadata.FindPrimaryKey().GetName();
                var entityPrimaryKeyValue = entity.Metadata.FindPrimaryKey().Properties.Select(p => entity.Property(p.Name).CurrentValue).FirstOrDefault();
                foreach (var entityProperty in entity.Properties)
                {
                    if (entityProperty.IsModified)
                    {
                        var originalValue = entityProperty.OriginalValue ?? "";
                        var currentValue = entityProperty.CurrentValue ?? "";

                        if (originalValue.ToString() != currentValue.ToString())
                        {
                            _auditTrailLogs.Add(new AuditTrailLog()
                            {
                                EntityName = entity.Entity.GetType().Name,
                                PrimaryKeyValue = entityPrimaryKeyValue.ToString(),
                                ActionType = "Update",
                                OldValue = originalValue.ToString(),
                                NewValue = currentValue.ToString(),
                                PropertyName = entityProperty.Metadata.Name,
                                ChangedBy = RequestUser,
                                ChangedDate = DateTime.Now
                            });
                        }

                    }
                }
            }
            if (_auditTrailLogs.Count > 0)
            {
                this.AuditTrailLog.AddRange(_auditTrailLogs);
            }
        }

        #endregion

        public virtual DbSet<ArrivalPortMaster> ArrivalPortMaster { get; set; }
        public virtual DbSet<AspNetRoleClaims> AspNetRoleClaims { get; set; }
        public virtual DbSet<AspNetRoles> AspNetRoles { get; set; }
        public virtual DbSet<AspNetUserClaims> AspNetUserClaims { get; set; }
        public virtual DbSet<AspNetUserLogins> AspNetUserLogins { get; set; }
        public virtual DbSet<AspNetUserRoles> AspNetUserRoles { get; set; }
        public virtual DbSet<AspNetUserTokens> AspNetUserTokens { get; set; }
        public virtual DbSet<AspNetUsers> AspNetUsers { get; set; }
        public virtual DbSet<AuditTrailLog> AuditTrailLog { get; set; }
        public virtual DbSet<Authority> Authority { get; set; }
        public virtual DbSet<CityMaster> CityMaster { get; set; }
        public virtual DbSet<CountryMaster> CountryMaster { get; set; }
        public virtual DbSet<DocumentStatusMaster> DocumentStatusMaster { get; set; }
        public virtual DbSet<IncomingOrderContainerDetails> IncomingOrderContainerDetails { get; set; }
        public virtual DbSet<IncomingOrderDetails> IncomingOrderDetails { get; set; }
        public virtual DbSet<ItemBrandMaster> ItemBrandMaster { get; set; }
        public virtual DbSet<ItemCountMaster> ItemCountMaster { get; set; }
        public virtual DbSet<ItemGroupMaster> ItemGroupMaster { get; set; }
        public virtual DbSet<ItemMaster> ItemMaster { get; set; }
        public virtual DbSet<ItemPackingMaster> ItemPackingMaster { get; set; }
        public virtual DbSet<PartyGroupMaster> PartyGroupMaster { get; set; }
        public virtual DbSet<PartyMaster> PartyMaster { get; set; }
        public virtual DbSet<PerformaInvoiceDetails> PerformaInvoiceDetails { get; set; }
        public virtual DbSet<ShippingLineMaster> ShippingLineMaster { get; set; }
        public virtual DbSet<StateMaster> StateMaster { get; set; }
        public virtual DbSet<UserInfo> UserInfo { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ArrivalPortMaster>(entity =>
            {
                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<AspNetRoleClaims>(entity =>
            {
                entity.Property(e => e.RoleId)
                    .IsRequired()
                    .HasMaxLength(450);

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.AspNetRoleClaims)
                    .HasForeignKey(d => d.RoleId);
            });

            modelBuilder.Entity<AspNetRoles>(entity =>
            {
                entity.Property(e => e.Name).HasMaxLength(256);

                entity.Property(e => e.NormalizedName).HasMaxLength(256);
            });

            modelBuilder.Entity<AspNetUserClaims>(entity =>
            {
                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);

                entity.HasOne(d => d.User)
                    .WithMany(p => p.AspNetUserClaims)
                    .HasForeignKey(d => d.UserId);
            });

            modelBuilder.Entity<AspNetUserLogins>(entity =>
            {
                entity.HasKey(e => new { e.LoginProvider, e.ProviderKey });

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);

                entity.HasOne(d => d.User)
                    .WithMany(p => p.AspNetUserLogins)
                    .HasForeignKey(d => d.UserId);
            });

            modelBuilder.Entity<AspNetUserRoles>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.RoleId });

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.AspNetUserRoles)
                    .HasForeignKey(d => d.RoleId);

                entity.HasOne(d => d.User)
                    .WithMany(p => p.AspNetUserRoles)
                    .HasForeignKey(d => d.UserId);
            });

            modelBuilder.Entity<AspNetUserTokens>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.LoginProvider, e.Name });

                entity.HasOne(d => d.User)
                    .WithMany(p => p.AspNetUserTokens)
                    .HasForeignKey(d => d.UserId);
            });

            modelBuilder.Entity<AspNetUsers>(entity =>
            {
                entity.Property(e => e.Email).HasMaxLength(256);

                entity.Property(e => e.NormalizedEmail).HasMaxLength(256);

                entity.Property(e => e.NormalizedUserName).HasMaxLength(256);

                entity.Property(e => e.UserName).HasMaxLength(256);
            });

            modelBuilder.Entity<AuditTrailLog>(entity =>
            {
                entity.Property(e => e.ActionType)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ChangedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ChangedDate).HasColumnType("datetime");

                entity.Property(e => e.EntityName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NewValue)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.OldValue)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.PrimaryKeyValue)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Authority>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MenuName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Roles)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RoutePath)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.Users)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CityMaster>(entity =>
            {
                entity.Property(e => e.CityName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.State)
                    .WithMany(p => p.CityMaster)
                    .HasForeignKey(d => d.StateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__CityMaste__State__0E391C95");
            });

            modelBuilder.Entity<CountryMaster>(entity =>
            {
                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<DocumentStatusMaster>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DocStatus)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<IncomingOrderContainerDetails>(entity =>
            {
                entity.Property(e => e.ContainerNo)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Rate).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.SelfAllocated)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.AllocatedParty)
                    .WithMany(p => p.IncomingOrderContainerDetails)
                    .HasForeignKey(d => d.AllocatedPartyId)
                    .HasConstraintName("FK__IncomingO__Alloc__7FEAFD3E");

                entity.HasOne(d => d.Brand)
                    .WithMany(p => p.IncomingOrderContainerDetails)
                    .HasForeignKey(d => d.BrandId)
                    .HasConstraintName("FK__IncomingO__Brand__7E02B4CC");

                entity.HasOne(d => d.Count)
                    .WithMany(p => p.IncomingOrderContainerDetails)
                    .HasForeignKey(d => d.CountId)
                    .HasConstraintName("FK_IncomingOrderContainerDetails_ItemCountMaster");

                entity.HasOne(d => d.IncomingOrder)
                    .WithMany(p => p.IncomingOrderContainerDetails)
                    .HasForeignKey(d => d.IncomingOrderId)
                    .HasConstraintName("FK__IncomingO__Incom__7C1A6C5A");

                entity.HasOne(d => d.Item)
                    .WithMany(p => p.IncomingOrderContainerDetails)
                    .HasForeignKey(d => d.ItemId)
                    .HasConstraintName("FK__IncomingO__ItemI__7D0E9093");

                entity.HasOne(d => d.Packing)
                    .WithMany(p => p.IncomingOrderContainerDetails)
                    .HasForeignKey(d => d.PackingId)
                    .HasConstraintName("FK__IncomingO__Packi__7EF6D905");
            });

            modelBuilder.Entity<IncomingOrderDetails>(entity =>
            {
                entity.Property(e => e.ActualArrivalDate).HasColumnType("datetime");

                entity.Property(e => e.Blno)
                    .IsRequired()
                    .HasColumnName("BLNo")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CertificateOfOrigin)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CleaningExpense).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.ConversionRate).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Currency)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CustomDuty).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.EstDateOfArrival).HasColumnType("datetime");

                entity.Property(e => e.EstDateOfLoading).HasColumnType("datetime");

                entity.Property(e => e.ExchangeRate).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Freight).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.InvoiceNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InwardingBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.InwardingDate).HasColumnType("datetime");

                entity.Property(e => e.NetWeight).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.NonGmoCertificate)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OtherExpenses).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.PaymentTermsAdv)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PaymentTermsAfterArr)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PaymentTermsOnDoc)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PerformaInvoiceNo)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PhytoNo)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ShippingTerms)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.TotalGrossWeight).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.VesselNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.ArrivalPort)
                    .WithMany(p => p.IncomingOrderDetails)
                    .HasForeignKey(d => d.ArrivalPortId)
                    .HasConstraintName("FK__IncomingO__Arriv__756D6ECB");

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.IncomingOrderDetails)
                    .HasForeignKey(d => d.CountryId)
                    .HasConstraintName("FK__IncomingO__Count__76619304");

                entity.HasOne(d => d.DocumentStatus)
                    .WithMany(p => p.IncomingOrderDetails)
                    .HasForeignKey(d => d.DocumentStatusId)
                    .HasConstraintName("FK__IncomingO__Docum__7849DB76");

                entity.HasOne(d => d.Shipper)
                    .WithMany(p => p.IncomingOrderDetailsShipper)
                    .HasForeignKey(d => d.ShipperId)
                    .HasConstraintName("FK__IncomingO__Shipp__7755B73D");

                entity.HasOne(d => d.ShippingLine)
                    .WithMany(p => p.IncomingOrderDetailsShippingLine)
                    .HasForeignKey(d => d.ShippingLineId)
                    .HasConstraintName("FK__IncomingO__Shipp__793DFFAF");
            });

            modelBuilder.Entity<ItemBrandMaster>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ItemBrandName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Item)
                    .WithMany(p => p.ItemBrandMaster)
                    .HasForeignKey(d => d.ItemId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__ItemBrand__ItemI__236943A5");
            });

            modelBuilder.Entity<ItemCountMaster>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ItemCount)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Item)
                    .WithMany(p => p.ItemCountMaster)
                    .HasForeignKey(d => d.ItemId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__ItemCount__ItemI__41B8C09B");
            });

            modelBuilder.Entity<ItemGroupMaster>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ItemGroupName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<ItemMaster>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ItemName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.ItemGroup)
                    .WithMany(p => p.ItemMaster)
                    .HasForeignKey(d => d.ItemGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ItemMaster_ItemGroupMaster");
            });

            modelBuilder.Entity<ItemPackingMaster>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ItemPacking)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Item)
                    .WithMany(p => p.ItemPackingMaster)
                    .HasForeignKey(d => d.ItemId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__ItemPacki__ItemI__1EA48E88");
            });

            modelBuilder.Entity<PartyGroupMaster>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.GroupName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<PartyMaster>(entity =>
            {
                entity.Property(e => e.ContactNo)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CreditLimit).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Panno)
                    .HasColumnName("PANNo")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PartyAddress)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.PartyName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Pincode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.StoreRentCalculationType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.City)
                    .WithMany(p => p.PartyMaster)
                    .HasForeignKey(d => d.CityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PartyMast__CityI__11158940");

                entity.HasOne(d => d.PartyGroup)
                    .WithMany(p => p.PartyMaster)
                    .HasForeignKey(d => d.PartyGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PartyMast__Party__59063A47");

                entity.HasOne(d => d.State)
                    .WithMany(p => p.PartyMaster)
                    .HasForeignKey(d => d.StateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PartyMast__State__10216507");
            });

            modelBuilder.Entity<PerformaInvoiceDetails>(entity =>
            {
                entity.Property(e => e.Amount).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.InvoiceDate).HasColumnType("datetime");

                entity.Property(e => e.InvoiceStatus)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.PerformaInvoiceNo)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Vendor)
                    .WithMany(p => p.PerformaInvoiceDetails)
                    .HasForeignKey(d => d.VendorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PerformaI__Vendo__54CB950F");
            });

            modelBuilder.Entity<ShippingLineMaster>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ShippingLine)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<StateMaster>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StateName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<UserInfo>(entity =>
            {
                entity.Property(e => e.ContactNo)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.DeviceId)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.EmailId)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FirebaseId)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RoleId)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.RoleName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.UserCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

﻿using iStock.CrudBusinessLayer.Interfaces;
using iStock.DataAccessLayer.IDataOperations;

using iStock.Models.ResponseModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace iStock.CrudBusinessLayer
{
    public class ApplicationCrudLogics : IApplicationCrudLogics
    {
        private readonly IApplicationDataOperations applicationDataOperations;

        public ApplicationCrudLogics(IApplicationDataOperations applicationDataOperations)
        {
            this.applicationDataOperations = applicationDataOperations;
        }

        public async Task<IActionResult> GetApplicationVersion()
        {
            try
            {                
                var dataLayerResponse = await applicationDataOperations.GetApplicationVersion();
                if (string.IsNullOrWhiteSpace(dataLayerResponse))
                {
                    return new ObjectResult(new { Message = "Application version not found" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }                
                else
                {
                    return new ObjectResult(dataLayerResponse);
                }
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }        
    }
}

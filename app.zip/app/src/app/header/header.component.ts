import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { AppState } from '../reducers';
import { isLoggedIn, authState } from '../auth/auth.selectors';
import { map } from 'rxjs/operators';
import { toggleSideNav } from '../side-nav/side-nav.actions';
import { logout } from '../auth/auth.actions';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {


  newNotificationAlert : boolean = false;
  showNotificationContainer : boolean = false;
  manualReachCount : number = 0;
  userName$ : Observable<string>;
  isLoggedIn$ : Observable<boolean>;

  isAdmin : boolean = false;
  isOperation : boolean = false;

  constructor(private store : Store<AppState>,
            private router : Router,            
            private authService : AuthService) { }

  ngOnInit(): void {
    
   
    this.store.pipe(select(isLoggedIn)).subscribe(data=>{
      
    //  console.log('data is logged in: ',data);
     
    });

    this.isLoggedIn$ = this.store.pipe(select(isLoggedIn));
    
    this.isLoggedIn$.subscribe(loggedIn => {
      if(loggedIn){
        this.checkNotifications();
      }
    });

    
  }

  toggleNotificationContainer(){
    this.showNotificationContainer = !this.showNotificationContainer;
    this.newNotificationAlert = false;
  }

  toggleSideNav(){
    this.store.dispatch(toggleSideNav())
  }

  logout(){    
    this.store.dispatch(logout());
  }

  onAdminActionClick(url,notificationType){
    if(notificationType == 'manualReach'){
      this.manualReachCount = 0;
    }
    this.showNotificationContainer = false;
    this.router.navigateByUrl(url);
  }

  checkNotifications(){
    
  }
  

}

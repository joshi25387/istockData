import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualReachActionComponent } from './manual-reach-action.component';

describe('ManualReachActionComponent', () => {
  let component: ManualReachActionComponent;
  let fixture: ComponentFixture<ManualReachActionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualReachActionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualReachActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

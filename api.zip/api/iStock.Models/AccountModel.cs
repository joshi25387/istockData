﻿using System.ComponentModel.DataAnnotations;

namespace iStock.Models
{
    public class AccountModel
    {
        public int Id { get; set; }
        [Required]
        public string AccountName { get; set; }
        [Required]
        public string AccountNumber { get; set; }
        [Required]
        public string Ifsc { get; set; }
        [Required]
        public string AccBranch { get; set; }
        [Required]
        public string AccBankName { get; set; }
        
        public bool IsActive { get; set; }
    }
}

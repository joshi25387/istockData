import { DefaultDataService, HttpUrlGenerator } from '@ngrx/data';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Update } from '@ngrx/entity';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { PincodeModel } from '../../models/address.model';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn : 'root'})
export class PincodeDataService extends DefaultDataService<PincodeModel>{

  entities: PincodeModel[] = [];

  constructor(http : HttpClient, httpUrlGenerator : HttpUrlGenerator){
      super('Pincode',http,httpUrlGenerator);
  }
  
  getWithQuery(pincode) : Observable<PincodeModel[]>{
    return this.http.get(environment.apiUrl + "application/GetPincodeById/" + pincode).pipe(map(response => response['pincodeDetails']));
  }
  
//   add(pincode : PincodeModel)  : Observable<PincodeModel>{    
//     return this.http
//       .post<PincodeModel>(environment.apiUrl + 'pincode/', pincode).pipe(map(res=>res['pincodeDetails']));
//   }
//   update(update : Update<PincodeModel>): Observable<PincodeModel>{   
//     return this.http.put<PincodeModel>(environment.apiUrl+ 'pincode/'+update.id, update.changes);
//   }

//   delete(id: number): Observable<number> {    
//   return this.http.delete(environment.apiUrl+ 'pincode/' + id).pipe(map(res=>id));        
//   }
}
﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace iStock.CrudBusinessLayer.Interfaces
{
    public interface IApplicationCrudLogics
    {
        Task<IActionResult> GetApplicationVersion();
        
    }
}

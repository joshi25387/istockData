import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ReportUrlmodel, ReportNameModel } from '../models/reportUrl.model';
import { map } from 'rxjs/operators';

@Injectable({'providedIn' : 'root'})
export class ReportService {

    constructor(private http : HttpClient){}

    getSparBIReportUrl(){
        return this.http.get<ReportUrlmodel>(environment.apiUrl + 'application/GetSparBIReportUrl').pipe(map(res => res['reportUrlDetail']));
    }

    getSSRSReportNames(userRole,projectName,storeName){
        return this.http.get<ReportNameModel[]>(environment.reportingApiUrl + 'Report/GetReportNames?projectName='+projectName+'&projectLocation='+storeName+'&userRole='+userRole);        
    }
}
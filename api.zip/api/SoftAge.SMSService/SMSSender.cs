﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace SoftAge.SMSService
{
    public class SMSSender : ISMSSender
    {
        private readonly SMSConfiguration _smsConfig;

        public SMSSender(SMSConfiguration smsConfig)
        {
            _smsConfig = smsConfig;
        }

        public bool SendSMS(string mobileNo, string textMessage)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(_smsConfig.BaseUrl);

                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));                

                var apiUrl = string.Format(_smsConfig.ApiUrl, _smsConfig.ApiKey, _smsConfig.Sender, mobileNo, textMessage);
                var response = client.GetAsync(apiUrl);
                response.Wait();
                var result = response.Result;

                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}

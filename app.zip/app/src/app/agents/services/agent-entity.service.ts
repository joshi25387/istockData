import { EntityCollectionServiceBase, EntityCollectionServiceElementsFactory } from '@ngrx/data';
import { Agent } from '../models/agent.model';
import { Injectable } from '@angular/core';

@Injectable()
export class AgentEntityService extends EntityCollectionServiceBase<Agent> {
  constructor(serviceElementsFactory : EntityCollectionServiceElementsFactory){
      super('Agent',serviceElementsFactory);
  }
}
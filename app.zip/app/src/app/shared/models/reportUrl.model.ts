export interface ReportUrlmodel{
    reportUrl : string;
}

export interface ReportNameModel{
    id : number;
    reportName : string;
}
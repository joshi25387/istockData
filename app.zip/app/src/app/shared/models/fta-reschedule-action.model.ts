export interface FtaRescheduleActionModel{
    orderNo : string,
    registrationNo : string,    
}

export interface FtaTimeslotModel{
    id : number,
    slot : string
}

export interface FtaRescheduleUpdateModel{
    orderNo? : string,
    registrationNo? : string,
    deliveryDate?  :Date,
    timeSlotId? : number
}
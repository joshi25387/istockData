import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';


@Component({
  selector: 'view-link-renderer',
  template: `
  <div class="btn-group btn-group-sm" role="group">
        <button type="button" class="btn btn-link" style="color : #F26222;" (click)="onViewClick($event)"  title="View">View Order</button>         
    </div>
    `
})

export class ViewLinkRendererComponent implements ICellRendererAngularComp {

  params;
  label: string;

  agInit(params): void {
    this.params = params;
    this.label = this.params.label || null;
  }

  refresh(params?: any): boolean {
    return true;
  }

  onViewClick($event) {
    if (this.params.onViewClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onViewClick(params);
    }
  }

}
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { Routes, RouterModule } from '@angular/router';
import { AgentComponent } from './agent/agent.component';
import { AgentListComponent } from './agent-list/agent-list.component';
import { AgentsResolver } from './services/agents.resolver';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule } from '@angular/forms';
import { AgentTrackingComponent } from './agent-tracking/agent-tracking.component';


const agentRoutes: Routes = [
    {
        path: '',
        component: AgentListComponent,
        resolve: {
            agents: AgentsResolver
        }
    },
    {
        path: "new",
        component: AgentComponent
    },
    {
        path: ":id/edit",
        component: AgentComponent
    },
    {
        path: "agent-tracking",
        component: AgentTrackingComponent
    }
];

@NgModule({
    declarations: [AgentComponent, AgentListComponent, AgentTrackingComponent],
    imports: [
        SharedModule,
        RouterModule.forChild(agentRoutes),
        NgSelectModule,
        FormsModule
    ],
    providers: [
         AgentsResolver
    ]
})
export class AgentModule { }
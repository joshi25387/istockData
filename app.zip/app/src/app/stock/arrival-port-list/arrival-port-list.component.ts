import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/auth/auth.service';
import { UserDetail } from 'src/app/auth/models/user.model';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';
import { ArrivalPortModel } from '../model/master-data.model';
import { MasterDataService } from '../services/master-data.service';
import * as moment from 'moment';

@Component({
  selector: 'arrival-port-list',
  templateUrl: './arrival-port-list.component.html',
  styleUrls: ['./arrival-port-list.component.css']
})
export class ArrivalPortListComponent implements OnInit {

  confirmMessage: string = null;  

  arrivalPortList$: Observable<ArrivalPortModel[]>;
  filter = new FormControl('');

  arrivalPortToUpdate: number = -1;

  showAckDialog : boolean = false;
  
  alertMessage:string =null;
  frameworkComponents: any;

  arrivalPortIdToDelete : number = -1;

  orderStatusFilter : string;
  storeIdFilter : number;
  userDetail : UserDetail;

  
  columnDefs = [    
    {  headerName: 'Id',field: 'id', sortable: true, filter: true,resizable:true,width:110,pinned:'left'},        
    { headerName: 'Arrival Port', field: 'city', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: 'Created Date', field: 'createdDate', sortable : true, filter : true,width : 180 ,
          resizable : true,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
      },  
    { headerName: 'Created By', field: 'createdBy', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: '', cellRenderer: 'editDeleteButtonRenderer', 
    cellRendererParams: {
        onEditClick: this.editArrivalPort.bind(this),
        onDeleteClick: this.deleteArrivalPort.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private masterDataService : MasterDataService,
    private authService : AuthService) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }

    this.authService.userDetail.subscribe(userDet => {      
      this.userDetail = userDet
    });
    this.arrivalPortList$ = this.masterDataService.getArrivalPortList();
 
        
  }

  onConfirmOk(){
    if(this.arrivalPortIdToDelete > -1){

      this.masterDataService.deleteArrivalPort(this.arrivalPortIdToDelete).subscribe(res=>{
        if(res){
          this.alertMessage = res['statusMessage'];
          this.arrivalPortList$ = this.masterDataService.getArrivalPortList();
        }
      });
    }
    this.confirmMessage = null;
  }

  onConfirmCancel(){
    this.arrivalPortIdToDelete = -1;
    this.confirmMessage = null;
  }

  editArrivalPort(arrivalPortRow){
    let arrivalPortId : number = +arrivalPortRow.rowData.id;
    this.router.navigate([arrivalPortId,'edit'],{relativeTo:this.route});
  }

  deleteArrivalPort(arrivalPortRow){
    this.arrivalPortIdToDelete = +arrivalPortRow.rowData.id;
    this.confirmMessage = "Are you sure to delete arrival port " + arrivalPortRow.rowData.city + " ?";
  }


  
  closeAlert() {
    this.alertMessage = null;    
  }

}

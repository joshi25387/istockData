﻿using Microsoft.Extensions.Configuration;
using System;
using System.Buffers.Text;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace iStock.Helpers
{
    public static class DocumentHandler
    {
        private static string GetDocumentsBasePath()
        {
            var configBuilder = new ConfigurationBuilder();
            var settingsFilePath = Path.Combine(Directory.GetCurrentDirectory(), "appSettings.json");
            configBuilder.AddJsonFile(settingsFilePath, false);

            var root = configBuilder.Build();
            var documentsBasePathConfig = root.GetSection("AppSettings").GetSection("documentsBasePath");

            if (documentsBasePathConfig.Exists())
            {
                return documentsBasePathConfig.Value;
            }
            else
            {
                return string.Empty;
            }            
        }


        public static string GetFileFromBase64AndSave(string fileName,string folderName,string base64String)
        {

            base64String = base64String.Substring(base64String.LastIndexOf(',') + 1);

            string basePath = GetDocumentsBasePath();

            string fileFolderPath = Path.Combine(basePath, folderName);

            string newGuid = Guid.NewGuid().ToString();

            string fileFolderGuidPath = Path.Combine(fileFolderPath, newGuid);
            string filePath = Path.Combine(fileFolderGuidPath, fileName);

            if (!Directory.Exists(basePath))
            {
                Directory.CreateDirectory(basePath);
            }
            if (!Directory.Exists(fileFolderPath))
            {
                Directory.CreateDirectory(fileFolderPath);
            }
            if (!Directory.Exists(fileFolderGuidPath))
            {
                Directory.CreateDirectory(fileFolderGuidPath);
            }

            byte[] imageBytes = Convert.FromBase64String(base64String);

            File.WriteAllBytes(filePath, imageBytes);


            return filePath;
        }


        public static string GetBase64StringFromFile(string filePath)
        {
            byte[] imageBytes = File.ReadAllBytes(filePath);
            string base64String = Convert.ToBase64String(imageBytes);
            return base64String;
        }

    }

    
}

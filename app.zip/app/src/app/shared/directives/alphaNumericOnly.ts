import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: 'input[alphaNumericOnly]'
})
export class AlphaNumericDirective {

  constructor(private _el: ElementRef) { }

  @HostListener('input', ['$event']) onInputChange(event) {
    const initialValue = this._el.nativeElement.value;
    this._el.nativeElement.value = initialValue.replace(/[^0-9a-zA-Z ]*/g, '');
    if ( initialValue !== this._el.nativeElement.value) {
      event.stopPropagation();
    }
  }

}
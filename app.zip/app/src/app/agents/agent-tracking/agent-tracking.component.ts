import { Component, OnInit } from '@angular/core';
import { AgentTrackingModel, AgentTrackingProjectModel, AgentWiseTrackingDataModel } from '../models/agent-tracking.model';
import { AgentTrackingEntityService } from '../services/agent-tracking-entity.service';

@Component({
  selector: 'agent-tracking',
  templateUrl: './agent-tracking.component.html',
  styleUrls: ['./agent-tracking.component.css']
})
export class AgentTrackingComponent implements OnInit {

  projectAgentTrackingModel : AgentTrackingProjectModel ;

  projectList : string[] = [];
  stateList : string[] = [];
  cityList : string[] = [];
  slotList : string[] = [];

  selectedProject : string;
  selectedState : string;
  selectedCity : string;


  agentTrackingData : AgentTrackingModel;

  agentWiseTrackingDataModel : AgentWiseTrackingDataModel[] = [];
  constructor(private agentTrackingEntityService : AgentTrackingEntityService) { }

  ngOnInit(): void {
    this.projectAgentTrackingModel = {
      projectName : '',
      agentTrackingDetails : []
    }

    this.agentTrackingEntityService.getAll().subscribe(data=>{
      let agentTrackData = data[0];
      this.agentTrackingData = agentTrackData;


      
      agentTrackData.projects.forEach(project => {
        this.projectList.push(project.projectName);
      });

      if(agentTrackData.projects.length == 1){
        let projectRecord = agentTrackData.projects[0];
        
        if(this.agentTrackingData.projects.filter(p=>p.projectName.toLowerCase() == projectRecord.projectName.toLowerCase())[0].agentTrackingDetails){
          this.agentTrackingData.projects.filter(p=>p.projectName.toLowerCase() == projectRecord.projectName.toLowerCase())[0].agentTrackingDetails.forEach(detail => {
            if(this.stateList.indexOf(detail.stateName) < 0){
              this.stateList.push(detail.stateName);
            }      
          });
        } 

        if(projectRecord.agentTrackingDetails){
          this.setOrderTrackingData(projectRecord.projectName,'All','All');
        }
      }
      else{
        let projectRecord = agentTrackData.projects.filter(p=>p.projectName.toLowerCase() == this.projectList[0].toLowerCase())[0];
        

        if(this.agentTrackingData.projects.filter(p=>p.projectName.toLowerCase() == projectRecord.projectName.toLowerCase())[0].agentTrackingDetails){
          this.agentTrackingData.projects.filter(p=>p.projectName.toLowerCase() == projectRecord.projectName.toLowerCase())[0].agentTrackingDetails.forEach(detail => {
            if(this.stateList.indexOf(detail.stateName) < 0){
              this.stateList.push(detail.stateName);
            }      
          });
        } 

        if(projectRecord.agentTrackingDetails){
          this.setOrderTrackingData(projectRecord.projectName,'All','All');
        }
      }


    });
  }

  setOrderTrackingData(project:string,state : string,city: string){
    // project =  "Spar";
    this.selectedProject = project;
    this.selectedState = state;
    this.selectedCity = city;

    this.agentWiseTrackingDataModel = [];
    let overallProjectData = this.agentTrackingData.projects.filter(p=>p.projectName.toLowerCase()==project.toLowerCase())[0];

    if(state.toLowerCase() == 'all'){
      this.projectAgentTrackingModel.projectName = project;      
      this.projectAgentTrackingModel.agentTrackingDetails = overallProjectData.agentTrackingDetails;     
         
      

      if(this.projectAgentTrackingModel.agentTrackingDetails){
        this.projectAgentTrackingModel.agentTrackingDetails.forEach(record => {        
          let agentDisplayName = record.agentName + ' [' + record.storeName+'] (' + record.agentMobileNo + ')';
          if(this.agentWiseTrackingDataModel.filter(x=>x.agentName.toLowerCase() == agentDisplayName.toLowerCase()).length == 0){          
            
            let _agentWiseTrackingDataModel : AgentWiseTrackingDataModel = {
              agentName : agentDisplayName,              
              isLoggedIn : record.isLoggedIn,
              storeRadius : record.storeRadius,
              loginTimestamp : record.loginTimestamp,
              lastUpdatedTimestamp : record.lastUpdatedTimestamp,
              lastUpdatedLatitude : record.lastUpdatedLatitude,
              lastUpdatedLongitude : record.lastUpdatedLongitude,
              lastUpdatedAddress : record.lastUpdatedAddress
            };
            this.agentWiseTrackingDataModel.push(_agentWiseTrackingDataModel);
          }       
        });
      }
      
      
                                                            //trackingAgentWiseOrderModel

    }
    else{
      if(city.toLowerCase() == 'all'){        
        this.projectAgentTrackingModel.projectName = project;        
        this.projectAgentTrackingModel.agentTrackingDetails =overallProjectData.agentTrackingDetails
                                                              .filter(o=>o.stateName.toLowerCase() == state.toLowerCase()
                                                                        );           
                              

        if(this.projectAgentTrackingModel.agentTrackingDetails){
          this.projectAgentTrackingModel.agentTrackingDetails.forEach(record => {        
            let agentDisplayName = record.agentName + ' [' + record.storeName+'] (' + record.agentMobileNo + ')';
            if(this.agentWiseTrackingDataModel.filter(x=>x.agentName.toLowerCase() == agentDisplayName.toLowerCase()).length == 0){          
              
              let _agentWiseTrackingDataModel : AgentWiseTrackingDataModel = {
                agentName : agentDisplayName,                
                isLoggedIn : record.isLoggedIn,
                storeRadius : record.storeRadius,
                loginTimestamp : record.loginTimestamp,
                lastUpdatedTimestamp : record.lastUpdatedTimestamp,
                lastUpdatedLatitude : record.lastUpdatedLatitude,
                lastUpdatedLongitude : record.lastUpdatedLongitude,
                lastUpdatedAddress : record.lastUpdatedAddress
              };
              this.agentWiseTrackingDataModel.push(_agentWiseTrackingDataModel);
            }     
          });
        }
        
      }
      else{
        this.projectAgentTrackingModel.projectName = project;        
        this.projectAgentTrackingModel.agentTrackingDetails = overallProjectData.agentTrackingDetails
        .filter(o=>o.stateName.toLowerCase() == state.toLowerCase()
                  && o.cityName.toLowerCase() == city.toLowerCase());   


        if(this.projectAgentTrackingModel.agentTrackingDetails){
          this.projectAgentTrackingModel.agentTrackingDetails.forEach(record => {        
            let agentDisplayName = record.agentName + ' [' + record.storeName+'] (' + record.agentMobileNo + ')';
            if(this.agentWiseTrackingDataModel.filter(x=>x.agentName.toLowerCase() == agentDisplayName.toLowerCase()).length == 0){          
             
              let _agentWiseTrackingDataModel : AgentWiseTrackingDataModel = {
                agentName : agentDisplayName,
                isLoggedIn : record.isLoggedIn,
                storeRadius : record.storeRadius,
                loginTimestamp : record.loginTimestamp,
                lastUpdatedTimestamp : record.lastUpdatedTimestamp,
                lastUpdatedLatitude : record.lastUpdatedLatitude,
                lastUpdatedLongitude : record.lastUpdatedLongitude,
                lastUpdatedAddress : record.lastUpdatedAddress
              };
              this.agentWiseTrackingDataModel.push(_agentWiseTrackingDataModel);
            }
                    
          });
        }        
      }
    }    
  }


  onProjectChange(event){    
    let project = event.target.value;
    this.selectedProject = project;
    this.stateList = [];
  

    if(this.agentTrackingData.projects.filter(p=>p.projectName.toLowerCase() == project.toLowerCase())[0].agentTrackingDetails){
      this.agentTrackingData.projects.filter(p=>p.projectName.toLowerCase() == project.toLowerCase())[0].agentTrackingDetails.forEach(detail => {
        if(this.stateList.indexOf(detail.stateName) < 0){
          this.stateList.push(detail.stateName);
        }      
      });
    }      
    this.setOrderTrackingData(project,'all','all'); 
  }

  onStateChange(event){
    let state : string = event.target.value;
    this.selectedState = state;
    let project = this.projectAgentTrackingModel.projectName;
    this.cityList = [];


    let projectDt = this.agentTrackingData.projects.filter(p=>p.projectName.toLowerCase() == project.toLowerCase())[0];
    if(projectDt){
      let stateFilteredRecord = projectDt.agentTrackingDetails.filter(o=>o.stateName.toLowerCase() == state.toLowerCase());
      if(stateFilteredRecord){
        stateFilteredRecord.forEach(record => {
          if( this.cityList.indexOf(record.cityName) < 0 ){
            this.cityList.push(record.cityName);
          }          
      });
      }      
    }                
    this.setOrderTrackingData(project,state,'all'); 
  }

  onCityChange(event){
    let city : string = event.target.value;
    this.selectedCity = city;
    this.setOrderTrackingData(this.selectedProject,this.selectedState,this.selectedCity); 
  }

}

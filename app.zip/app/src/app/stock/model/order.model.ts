
export interface IncomingOrderModel{
    id? : number,
    blNo : string,
    arrivalPortId? : number,
    arrivalPort? : string,
    loadingWeekNo? : number,
    estDateOfLoading? : Date,
    estDateOfArrival? : Date,
    countryId? : number,
    country? : string,
    shipperId? : number,
    shipperName? : string,
    invoiceNo? :  string,
    noOfContainer? : number,
    packingListQty? : number,
    totalGrossWeight? : number,
    netWeight? : number,
    documentStatusId? : number,
    documentStatus? : string,
    vesselNo? : string,
    shippingLineId? : number,
    shippingLine? : string,
    shippingTerms? : string,
    paymentTermsAdv?  : string,
    paymentTermsOnDoc?  : string,   
    paymentTermsAfterArr? : string,
    freight : number,
    currency : string,
    exchangeRate : number,
    phytoNo : string,
    certificateOfOrigin : string,
    nonGmoCertificate : string,
    performaInvoiceNo : string,
    createdBy? : string,
    createdDate? : Date,
    containerDetails : IncomingOrderContainerDetailModel[]
}

export interface IncomingOrderContainerDetailModel{
    containerNo? : string,
    totalQty? : number,
    containerItemDetails : IncomingOrderContainerItemDetailModel[]
}

export interface IncomingOrderContainerItemDetailModel{
    itemId? : number,
    brandId? : number,
    packingId? : number,
    countId? : number,
    qty? : number,
    rate? : number,
    selfAllocated? : string,
    allocatedPartyId? : number
}

export interface PerformaInvoiceModel{
    id? : number,
    performaInvoiceNo? : string,
    invoiceDate? : Date,
    vendorId? : number,
    vendorName? : string,
    amount? : number,
    createdBy? : string,
    createdDate? : Date
}
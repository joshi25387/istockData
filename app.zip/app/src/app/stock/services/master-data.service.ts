import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { ArrivalPortModel, CityModel, CountryModel, DocumentStatusModel, ItemGroupModel, ItemModel, PartyGroupModel, PartyModel, StateModel } from '../model/master-data.model';

@Injectable({'providedIn' : 'root'})
export class MasterDataService {

    constructor(private http : HttpClient){}

    getArrivalPortList(){
        return this.http.get<ArrivalPortModel[]>(environment.apiUrl + 'masterData/GetArrivalPortMaster').pipe(map(res => res['arrivalPortDetails']));
    }
    getArrivalPortById(id : number){
        return this.http.get<ArrivalPortModel>(environment.apiUrl + 'masterData/GetArrivalPortById/' + id).pipe(map(res => res['arrivalPortDetails']));
    }

    createArrivalPort(model : ArrivalPortModel){
        return this.http.post(environment.apiUrl + 'masterData/CreateArrivalPort',model);
    }
    updateArrivalPort(model : ArrivalPortModel){
        return this.http.post(environment.apiUrl + 'masterData/UpdateArrivalPort',model);
    }
    deleteArrivalPort(id : number){
        return this.http.delete(environment.apiUrl + 'masterData/DeleteArrivalPort/'+id.toString());
    }


    getCountryList(){
        return this.http.get<CountryModel[]>(environment.apiUrl + 'masterData/GetCountryMaster').pipe(map(res => res['countryDetails']));
    }
    getCountryById(id : number){
        return this.http.get<CountryModel>(environment.apiUrl + 'masterData/GetCountryById/' + id).pipe(map(res => res['countryDetails']));
    }

    createCountry(model : CountryModel){
        return this.http.post(environment.apiUrl + 'masterData/CreateCountry',model);
    }
    updateCountry(model : CountryModel){
        return this.http.post(environment.apiUrl + 'masterData/UpdateCountry',model);
    }
    deleteCountry(id : number){
        return this.http.delete(environment.apiUrl + 'masterData/DeleteCountry/'+id.toString());
    }


    getStateList(){
        return this.http.get<StateModel[]>(environment.apiUrl + 'masterData/GetStateMaster').pipe(map(res => res['stateDetails']));
    }
    getCityList(stateId : number){
        return this.http.get<CityModel[]>(environment.apiUrl + 'masterData/GetCityMaster/' + stateId).pipe(map(res => res['cityDetails']));
    }

    getPartyGroupList(){
        return this.http.get<PartyGroupModel[]>(environment.apiUrl + 'masterData/GetPartyGroupMaster').pipe(map(res => res['partyGroupDetails']));
    }
    getPartyGroupById(id : number){
        return this.http.get<PartyGroupModel>(environment.apiUrl + 'masterData/GetPartyGroupById/' + id).pipe(map(res => res['partyGroupDetails']));
    }

    createPartyGroup(model : PartyGroupModel){
        return this.http.post(environment.apiUrl + 'masterData/CreatePartyGroup',model);
    }
    updatePartyGroup(model : PartyGroupModel){
        return this.http.post(environment.apiUrl + 'masterData/UpdatePartyGroup',model);
    }
    deletePartyGroup(id : number){
        return this.http.delete(environment.apiUrl + 'masterData/DeletePartyGroup/'+id.toString());
    }



    getPartyList(){
        return this.http.get<PartyModel[]>(environment.apiUrl + 'masterData/GetPartyMaster').pipe(map(res => res['partyDetails']));
    }
    getPartyById(id : number){
        return this.http.get<PartyModel>(environment.apiUrl + 'masterData/GetPartyById/' + id).pipe(map(res => res['partyDetails']));
    }

    createParty(model : PartyModel){
        return this.http.post(environment.apiUrl + 'masterData/CreateParty',model);
    }
    updateParty(model : PartyModel){
        return this.http.post(environment.apiUrl + 'masterData/UpdateParty',model);
    }
    deleteParty(id : number){
        return this.http.delete(environment.apiUrl + 'masterData/DeleteParty/'+id.toString());
    }



    getItemGroupList(){
        return this.http.get<ItemGroupModel[]>(environment.apiUrl + 'masterData/GetItemGroupMaster').pipe(map(res => res['itemGroupDetails']));
    }
    getItemGroupById(id : number){
        return this.http.get<ItemGroupModel>(environment.apiUrl + 'masterData/GetItemGroupById/' + id).pipe(map(res => res['itemGroupDetails']));
    }

    createItemGroup(model : ItemGroupModel){
        return this.http.post(environment.apiUrl + 'masterData/CreateItemGroup',model);
    }
    updateItemGroup(model : ItemGroupModel){
        return this.http.post(environment.apiUrl + 'masterData/UpdateItemGroup',model);
    }
    deleteItemGroup(id : number){
        return this.http.delete(environment.apiUrl + 'masterData/DeleteItemGroup/'+id.toString());
    }




    getItemList(){
        return this.http.get<ItemModel[]>(environment.apiUrl + 'masterData/GetItemMaster').pipe(map(res => res['itemDetails']));
    }
    getItemById(id : number){
        return this.http.get<ItemModel>(environment.apiUrl + 'masterData/GetItemById/' + id).pipe(map(res => res['itemDetails']));
    }

    createItem(model : ItemModel){
        return this.http.post(environment.apiUrl + 'masterData/CreateItem',model);
    }
    updateItem(model : ItemModel){
        return this.http.post(environment.apiUrl + 'masterData/UpdateItem',model);
    }
    deleteItem(id : number){
        return this.http.delete(environment.apiUrl + 'masterData/DeleteItem/'+id.toString());
    }

    getDocumentStatusList(){
        return this.http.get<DocumentStatusModel[]>(environment.apiUrl + 'masterData/GetDocumentStatusMaster').pipe(map(res => res['documentStatusDetails']));
    }

}
﻿using iStock.CrudBusinessLayer.Interfaces;
using iStock.Models;
using iStock.Models.DALModels;
using iStock.Models.ResponseModels;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
//using SoftAge.EmailService;
//using SoftAge.SMSService;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace iStock.ApiLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly IUserCrudLogics _userCrudOps;
        //private readonly IEmailSender _emailSender;
        //private readonly ISMSSender _smsSender;
        
        private readonly IConfiguration _configuration;

        public AccountController(
            UserManager<IdentityUser> userManager,
            RoleManager<IdentityRole> roleManager,
            SignInManager<IdentityUser> signInManager,
            IUserCrudLogics userCrudOps,
            //IEmailSender emailSender,
            //ISMSSender smsSender,
            IConfiguration configuration
            )
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _signInManager = signInManager;
            _configuration = configuration;
           // _emailSender = emailSender;
            _userCrudOps = userCrudOps;
           // _smsSender = smsSender;
         
        }


        [HttpPost("CreateRole")]
        public async Task<IActionResult> CreateRole([FromBody] string roleName)
        {
            if (string.IsNullOrWhiteSpace(roleName))
            {
                return BadRequest("Invalid Role Name");
            }

            var existingRole = await _roleManager.FindByNameAsync(roleName.Trim());
            if (existingRole != null && string.IsNullOrWhiteSpace(existingRole.Id))
            {
                return new ObjectResult("Role already Exists") { StatusCode = (int)HttpStatusCode.Conflict };
            }

            var result = await _roleManager.CreateAsync(new IdentityRole(roleName.Trim()));
            if (result == null || !result.Succeeded)
            {
                return UnprocessableEntity(result?.Errors);
            }
            else
            {
                return new ObjectResult("Created") { StatusCode = (int)HttpStatusCode.Created };
            }
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetRoles")]
        public async Task<IActionResult> GetRoles()
        {
            var requestor = string.Empty;
            var requestorRole = string.Empty;

            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                var roleClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
                if (roleClaim != null && !string.IsNullOrWhiteSpace(roleClaim.Value))
                {
                    requestorRole = roleClaim.Value;
                }
            }
            return await _userCrudOps.GetRoles(requestor);
        }

        [HttpPost("CreateUser")]
        public async Task<IActionResult> CreateUser([FromBody] UserModel model)
        {
            if (model is null || string.IsNullOrWhiteSpace(model.UserName)
                || string.IsNullOrWhiteSpace(model.RoleId))
            {
                return BadRequest("Require All the mandatory feilds");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var identityRole = await _roleManager.FindByIdAsync(model.RoleId.Trim());
            if (identityRole is null || string.IsNullOrWhiteSpace(identityRole.Id))
            {
                return BadRequest("Invalid Role Id");
            }

            var user = new IdentityUser(model.UserName.Trim())
            {
                Email = model.Email.Trim(),
                PhoneNumber = model.MobileNumber.Trim()
            };

            string _fullName = model.FirstName.Trim() + model.LastName.Trim();


            string _defaultPassword = _fullName.Length >= 4 ? (_fullName.Substring(0, 1).ToUpper() + _fullName.Substring(1, 3).ToLower() + "@12345")
                                                     : (_fullName.Substring(0, 1).ToUpper() + _fullName.Substring(1).ToLower() + "@12345");


            var result = await _userManager.CreateAsync(user, _defaultPassword);
            if (result == null || !result.Succeeded)
            {
                return UnprocessableEntity(result?.Errors);
            }
            else
            {
                var createdUser = await _userManager.FindByNameAsync(user.UserName);
                if (createdUser == null || string.IsNullOrWhiteSpace(user.Id) || string.IsNullOrWhiteSpace(user.UserName))
                {
                    return new ObjectResult("User not created") { StatusCode = (int)HttpStatusCode.InternalServerError };
                }

                var roleresult = await _userManager.AddToRoleAsync(createdUser, identityRole.Name);

                if (result == null || !result.Succeeded)
                {
                    await _userManager.DeleteAsync(createdUser);
                    return UnprocessableEntity(roleresult.Errors);
                }
                else
                {
                    await _userCrudOps.CreateUser("System", model);
                    //  _smsSender.SendSMS(model.MobileNumber, "Congratulations! You are successfully registered with Last Lap. Your login credentials are : Username : " + model.UserName + " Password : " + _defaultPassword + " URL : https://www.softageteledocm.com/LastLap/login");
                    return new ObjectResult(createdUser) { StatusCode = (int)HttpStatusCode.Created };
                }
            }
        }
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("UpdateUser")]
        public async Task<IActionResult> UpdateUser([FromBody] UserModel model)
        {
            var requestor = string.Empty;
            var requestorRole = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                var roleClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
                if (roleClaim != null && !string.IsNullOrWhiteSpace(roleClaim.Value))
                {
                    requestorRole = roleClaim.Value;
                }
            }
            if (model is null || string.IsNullOrWhiteSpace(model.UserName)
               || string.IsNullOrWhiteSpace(model.RoleId) || string.IsNullOrWhiteSpace(model.UserName))
            {
                return BadRequest("Missing Id fields");
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //var result = await _signInManager.PasswordSignInAsync(credentials.UserName, credentials.Password, isPersistent: false, lockoutOnFailure: false);
            var identityRole = await _roleManager.FindByIdAsync(model.RoleId.Trim());
            if (identityRole is null || string.IsNullOrWhiteSpace(identityRole.Id))
            {
                return BadRequest("Invalid Role Id");
            }
            /*identityRole.Name = model.UserName;
            identityRole.Id = model.RoleId;
            var res = await _roleManager.UpdateAsync(identityRole);*/

            model.UserName = model.UserName.Trim();
            model.FirstName = model.FirstName.Trim();
            model.LastName = model.LastName.Trim();
            model.Email = model.Email.Trim();

            var user = await _userManager.FindByNameAsync(model.UserName);
            if (user != null)
            {
                //user.UserName = model.UserName;
                user.Email = model.Email.Trim();
                user.PhoneNumber = model.MobileNumber.Trim();
                //user.Id = model.RoleId.Trim();
                var result = await _userManager.UpdateAsync(user);
                string existingRole = _userManager.GetRolesAsync(user).Result.Single();
                string existingRoleId = _roleManager.Roles.Single(r => r.Name == existingRole).Id;
                if (result.Succeeded)
                {
                    if (existingRoleId != model.RoleId)
                    {
                        IdentityResult roleResult = await _userManager.RemoveFromRoleAsync(user, existingRole);
                        if (roleResult.Succeeded)
                        {
                            var applicationRole = await _roleManager.FindByIdAsync(model.RoleId);
                            if (applicationRole != null)
                            {
                                IdentityResult newRoleResult = await _userManager.AddToRoleAsync(user, applicationRole.Name);
                            }
                        }
                    }
                    
                    return new ObjectResult(user) { StatusCode = (int)HttpStatusCode.OK };
                }
                return UnprocessableEntity(result?.Errors);
            }
            else
            {
                return BadRequest("Invalid User");
            }
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody]UserCredentials credentials)
        {
            var result = await _signInManager.PasswordSignInAsync(credentials.UserName, credentials.Password, isPersistent: false, lockoutOnFailure: false);
            if (result.Succeeded && !result.IsNotAllowed && !result.IsLockedOut)
            {
                var token = await BuildToken(credentials);
                if (token == null)
                {
                    return NotFound("User and role not found");
                }
                else
                {
                    return Ok(token);
                }
            }
            else
            {
                return BadRequest("Invalid Credentials");
            }
        }


        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetUserDetails")]
        public async Task<IActionResult> GetUserDetails()
        {
            var requestor = string.Empty;

            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await _userCrudOps.GetUserDetails(requestor);
        }


        private async Task<UserTokenModel> BuildToken(UserCredentials userInfo)
        {
            if (userInfo == null)
            {
                return null;
            }

            var identityUser = await _userManager.FindByNameAsync(userInfo.UserName);
            if (identityUser == null)
            {
                return null;
            }

            var userRoles = await _userManager.GetRolesAsync(identityUser);
            if (userRoles == null && userRoles.Count <= 0)
            {
                return null;
            }
            var roleName = userRoles.FirstOrDefault();
            var claims = new List<Claim>()
            {
                new Claim(ClaimTypes.Name, userInfo.UserName),
                new Claim(ClaimTypes.Role, roleName)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["jwt:key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);


            


            var expiration = DateTime.Now.AddDays(1).Date;
            //var expiration = DateTime.UtcNow.AddMinutes(1);


            
            JwtSecurityToken token = new JwtSecurityToken(
                issuer: null,
                audience: null,
                claims: claims,
                expires: expiration,
                signingCredentials: creds);

            return new UserTokenModel()
            {
                Token = new JwtSecurityTokenHandler().WriteToken(token),
                Expiration = expiration,
                Role = roleName,
                Name = userInfo.UserName,
                UserCode = userInfo.UserName
            };
        }
    }



}
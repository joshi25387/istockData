﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Helpers
{
    public enum OrderStatusEnum
    {
        Pending,
        Assigned,
        Started,
        Picked,
        Dispatched,
        Delivered,
        Cancelled,
        Reached,
        Rescheduled
    }

    public enum RoleEnum
    {
        CLIENT,
        ADMIN,
        AGENT,
        CLIENTADMIN,
        OPERATION
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftAge.SMSService
{
    public interface ISMSSender
    {
        bool SendSMS(string mobileNo, string textMessage);
    }
}

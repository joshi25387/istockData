﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.DALModels
{
    public class DocumentViewDALModel : BaseDALStatus
    {
        public List<DocumentViewModel> CustomerDetails { get; set; }
    }

    public class SingleDocumentViewDALModel : BaseDALStatus
    {
        public DocumentViewModel CustomerDetails { get; set; }
    }


    public class RejectionReasonDALModel : BaseDALStatus
    {
        public List<RejectionReasonModel> RejectionReasonDetails { get; set; }
    }

    public class SearchDALModel : BaseDALStatus
    {
        public SearchModel DocumentDetails { get; set; }
    }

    public class DownloadFileDALModel : BaseDALStatus
    {
        public DownloadFileModel FileDetails { get; set; }
    }

    public class DocumentTypeDALModel : BaseDALStatus
    {
        public List<DocumentTypeModel> DocumentTypeDetails { get; set; }
    }
}

﻿using iStock.CrudBusinessLayer.Interfaces;
using iStock.DataAccessLayer.IDataOperations;
using iStock.Models;
using iStock.Models.ResponseModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace iStock.CrudBusinessLayer
{
    public class MasterDataCrudLogics : IMasterDataCrudLogics
    {
        private readonly IMasterDataDataOperations masterDataDataOperations;

        public MasterDataCrudLogics(IMasterDataDataOperations masterDataDataOperations)
        {
            this.masterDataDataOperations = masterDataDataOperations;
        }

        public async Task<IActionResult> CreateArrivalPort(string requestor, ArrivalPortMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model==null || string.IsNullOrWhiteSpace(model.City))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.CreateArrivalPort(requestor,model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> CreateCountry(string requestor, CountryMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model == null || string.IsNullOrWhiteSpace(model.Country))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.CreateCountry(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> CreateDocumentStatus(string requestor, DocumentStatusMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model == null || string.IsNullOrWhiteSpace(model.DocStatus))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.CreateDocumentStatus(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> CreateItem(string requestor, ItemMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model == null || string.IsNullOrWhiteSpace(model.ItemName))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.CreateItem(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> CreateParty(string requestor, PartyMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model == null || string.IsNullOrWhiteSpace(model.PartyName) || model.PartyGroupId <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.CreateParty(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> CreatePartyGroup(string requestor, PartyGroupMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model == null || string.IsNullOrWhiteSpace(model.GroupName))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.CreatePartyGroup(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> DeleteArrivalPort(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.DeleteArrivalPort(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> DeleteCountry(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.DeleteCountry(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> DeleteDocumentStatus(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.DeleteDocumentStatus(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> DeleteItem(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.DeleteItem(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> DeleteParty(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.DeleteParty(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> DeletePartyGroup(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.DeletePartyGroup(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetArrivalPortMaster(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetArrivalPortMaster(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new ArrivalPortMasterResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, ArrivalPortDetails = dataLayerResponse.ArrivalPortDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetArrivalPortById(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetArrivalPortById(requestor,id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new ArrivalPortSingleResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, ArrivalPortDetails = dataLayerResponse.ArrivalPortDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetCountryMaster(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetCountryMaster(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new CountryMasterResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, CountryDetails = dataLayerResponse.CountryDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetStateMaster(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetStateMaster(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new StateMasterResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, StateDetails = dataLayerResponse.StateDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetCityMaster(string requestor,int stateId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetCityMaster(requestor,stateId);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new CityMasterResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, CityDetails = dataLayerResponse.CityDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetCountryById(string requestor,int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetCountryById(requestor,id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new CountrySingleResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, CountryDetails = dataLayerResponse.CountryDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetDocumentStatusMaster(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetDocumentStatusMaster(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new DocumentStatusMasterResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, DocumentStatusDetails = dataLayerResponse.DocumentStatusDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetItemMaster(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetItemMaster(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new ItemMasterResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, ItemDetails = dataLayerResponse.ItemDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
        public async Task<IActionResult> GetItemById(string requestor,int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetItemById(requestor,id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new ItemSingleResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, ItemDetails = dataLayerResponse.ItemDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetPartyGroupMaster(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetPartyGroupMaster(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new PartyGroupMasterResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, PartyGroupDetails = dataLayerResponse.PartyGroupDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
        public async Task<IActionResult> GetPartyGroupById(string requestor,int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetPartyGroupById(requestor,id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new PartyGroupSingleResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, PartyGroupDetails = dataLayerResponse.PartyGroupDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetPartyMaster(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetPartyMaster(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new PartyMasterResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, PartyDetails = dataLayerResponse.PartyDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
        public async Task<IActionResult> GetPartyById(string requestor,int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetPartyById(requestor,id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new PartySingleResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, PartyDetails = dataLayerResponse.PartyDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> UpdateArrivalPort(string requestor, ArrivalPortMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if ( string.IsNullOrWhiteSpace(model.City) || model.Id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.UpdateArrivalPort(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> UpdateCountry(string requestor, CountryMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (string.IsNullOrWhiteSpace(model.Country) || model.Id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.UpdateCountry(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> UpdateDocumentStatus(string requestor, DocumentStatusMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (string.IsNullOrWhiteSpace(model.DocStatus) || model.Id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.UpdateDocumentStatus(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> UpdateItem(string requestor, ItemMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (string.IsNullOrWhiteSpace(model.ItemName) || model.Id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.UpdateItem(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> UpdateParty(string requestor, PartyMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (string.IsNullOrWhiteSpace(model.PartyName) || model.Id <= 0 || model.PartyGroupId <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.UpdateParty(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> UpdatePartyGroup(string requestor, PartyGroupMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (string.IsNullOrWhiteSpace(model.GroupName) || model.Id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.UpdatePartyGroup(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetItemGroupMaster(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetItemGroupMaster(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new ItemGroupMasterResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, ItemGroupDetails = dataLayerResponse.ItemGroupDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetItemGroupById(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.GetItemGroupById(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new ItemGroupSingleResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, ItemGroupDetails = dataLayerResponse.ItemGroupDetails })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> CreateItemGroup(string requestor, ItemGroupMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model == null || string.IsNullOrWhiteSpace(model.ItemGroupName))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.CreateItemGroup(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> UpdateItemGroup(string requestor, ItemGroupMasterModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (string.IsNullOrWhiteSpace(model.ItemGroupName) || model.Id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.UpdateItemGroup(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> DeleteItemGroup(string requestor, int id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (id <= 0)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid Request" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await masterDataDataOperations.DeleteItemGroup(requestor, id);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
    }
}

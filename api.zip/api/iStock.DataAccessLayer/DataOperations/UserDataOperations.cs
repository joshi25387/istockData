﻿using Microsoft.EntityFrameworkCore;
using iStock.DataAccessLayer.DataContext;
using iStock.DataAccessLayer.IDataOperations;
using iStock.Models;
using iStock.Models.DALModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using iStock.DataAccessLayer.EntityModels;

namespace iStock.DataAccessLayer.DataOperations
{
    public class UserDataOperations : IUserDataOperations
    {
        public async Task<RoleDALModel> GetRoles(string requestor)
        {
            if (string.IsNullOrWhiteSpace(requestor))
            {
                return new RoleDALModel() { HttpStatus = HttpStatusCode.MethodNotAllowed, Message = "No requestor Id found" };
            }

            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var roleList = await dbContext.AspNetRoles.Select(r => new RoleModel()
                    {
                        Id = r.Id,
                        Role = r.Name
                    }).ToListAsync();

                    return new RoleDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = HttpStatusCode.OK,
                        Message = "Success",
                        RoleList = roleList
                    };
                }
                catch (Exception ex)
                {
                    var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                    return new RoleDALModel
                    {
                        HttpStatus = HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<UserDetailDALModel> CreateUser(string requestor, UserModel model)
        {
            if (string.IsNullOrWhiteSpace(requestor))
            {
                return new UserDetailDALModel() { HttpStatus = HttpStatusCode.MethodNotAllowed, Message = "No requestor Id found" };
            }
            if (model == null)
            {
                return new UserDetailDALModel() { HttpStatus = HttpStatusCode.MethodNotAllowed, Message = "Invalid input" };
            }


            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {

                    return new UserDetailDALModel()
                    {
                        HttpStatus = HttpStatusCode.OK,
                        Message = "Created successfully",
                        AdditionalStatusCode = 200
                    };

                    //var userDet = await dbContext.UserInfo.Where(e => e.UserCode.ToLower() == model.UserName.ToLower()
                    //                                                && e.IsActive == true).FirstOrDefaultAsync();

                    //if (userDet == null)
                    //{
                    //    var _roleRecord = await dbContext.AspNetRoles.Where(r => r.Id == model.RoleId).FirstOrDefaultAsync();

                    //    dbContext.UserInfo.Add(new UserInfo()
                    //    {
                    //        UserCode = model.UserName,
                    //        FirstName = model.FirstName,
                    //        LastName = model.LastName,
                    //        EmailId = model.Email,
                    //        ContactNo = model.MobileNumber,
                    //        CircleId = model.CircleId,
                    //        IsActive = true,
                    //        RoleId = model.RoleId,
                    //        RoleName = _roleRecord.Name,
                    //        //DeviceId = model.DeviceId
                    //    });
                    //    dbContext.SaveChanges();
                    //    return new UserDetailDALModel()
                    //    {
                    //        HttpStatus = HttpStatusCode.OK,
                    //        Message = "Created successfully",
                    //        AdditionalStatusCode = 200
                    //    };
                    //}
                    //else
                    //{
                    //    return new UserDetailDALModel()
                    //    {
                    //        HttpStatus = HttpStatusCode.OK,
                    //        Message = "User already exists",
                    //        AdditionalStatusCode = 202
                    //    };
                    //}

                }
                catch (Exception ex)
                {
                    var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;

                    return new UserDetailDALModel
                    {
                        HttpStatus = HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<AuthorityDALModel> GetUserAuthority(string requestor)
        {
            try
            {
                using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
                {
                    List<AuthorityModel> _authorities = new List<AuthorityModel>();
                    var _userRecord = await dbContext.UserInfo
                                                            .Where(u => u.UserCode.ToLower() == requestor.ToLower())
                                                            .FirstOrDefaultAsync();
                    if (_userRecord != null)
                    {
                        var _allAuthorities = await dbContext.Authority.Where(a => a.IsActive == true).ToListAsync();

                        foreach (var _menuRecord in _allAuthorities)
                        {
                            if (_menuRecord.RoleWise == false && _menuRecord.UserWise == false)
                            {
                                _authorities.Add(new AuthorityModel()
                                {
                                    MenuName = _menuRecord.MenuName,
                                    RoutePath = _menuRecord.RoutePath
                                });
                            }
                            else if (_menuRecord.RoleWise == false && _menuRecord.UserWise == true)
                            {
                                var _userList = _menuRecord.Users.Split(',').ToList();
                                //if (_menuRecord.Users.ToLower().Contains(requestor.ToLower()))
                                if (_userList.Any(u => u.ToLower() == requestor.ToLower()))
                                {
                                    _authorities.Add(new AuthorityModel()
                                    {
                                        MenuName = _menuRecord.MenuName,
                                        RoutePath = _menuRecord.RoutePath
                                    });
                                }
                            }
                            
                            else if (_menuRecord.RoleWise == true && _menuRecord.UserWise == false)
                            {
                                var _roleList = _menuRecord.Roles.Split(',').ToList();
                                //if (_menuRecord.Roles.ToLower().Contains(_userRecord.RoleName.ToLower()))
                                if (_roleList.Any(r => r.ToLower() == _userRecord.RoleName.ToLower()))
                                {
                                    _authorities.Add(new AuthorityModel()
                                    {
                                        MenuName = _menuRecord.MenuName,
                                        RoutePath = _menuRecord.RoutePath
                                    });
                                }
                            }
                            else if (_menuRecord.RoleWise == true && _menuRecord.UserWise == true)
                            {
                                var _roleList = _menuRecord.Roles.Split(',').ToList();
                                var _userList = _menuRecord.Users.Split(',').ToList();
                                //if (_menuRecord.Roles.ToLower().Contains(_userRecord.RoleName.ToLower()) 
                                //            && _menuRecord.Users.ToLower().Contains(requestor.ToLower()))
                                if (_roleList.Any(r => r.ToLower() == _userRecord.RoleName.ToLower()) && _userList.Any(u => u.ToLower() == requestor.ToLower()))
                                {
                                    _authorities.Add(new AuthorityModel()
                                    {
                                        MenuName = _menuRecord.MenuName,
                                        RoutePath = _menuRecord.RoutePath
                                    });
                                }
                            }                                                       
                        }
                    }
                    return new AuthorityDALModel()
                    {
                        Message = "Success",
                        AuthorityDetails = _authorities,
                        AdditionalStatusCode = 200,
                        HttpStatus = HttpStatusCode.OK
                    };
                }
            }
            catch (Exception ex)
            {
                return new AuthorityDALModel()
                {
                    AdditionalStatusCode = 500,
                    HttpStatus = HttpStatusCode.InternalServerError,
                    AuthorityDetails = null,
                    Message = ex.Message
                };
            }
        }
        public async Task<UserDetailDALModel> GetUserDetails(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new UserDetailDALModel() { HttpStatus = HttpStatusCode.MethodNotAllowed, Message = "No requestor Id found" };
                }

                using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
                {

                    var userDetails = await dbContext.UserInfo
                                                        .Where(u => u.UserCode.ToLower() == requestor.ToLower() && u.IsActive == true)
                                                        .FirstOrDefaultAsync();

                    if (userDetails != null)
                    {
                        List<UserDetailModel> userDet = new List<UserDetailModel>();

                        userDet.Add(new UserDetailModel()
                        {
                            IsLoaded = true,
                            Name = (userDetails.FirstName.Trim() + " " + userDetails.LastName.Trim()).Trim(),                           
                            Role = userDetails.RoleName == null ? "" : userDetails.RoleName.ToLower(),
                            UserCode = userDetails.UserCode                            
                        });

                        return new UserDetailDALModel()
                        {
                            AdditionalStatusCode = 200,
                            HttpStatus = HttpStatusCode.OK,
                            UserDetails = userDet,
                            Message = "Success"
                        };
                    }
                    return new UserDetailDALModel()
                    {
                        AdditionalStatusCode = 201,
                        HttpStatus = HttpStatusCode.OK,
                        UserDetails = null,
                        Message = "User not found"
                    };
                }

            }
            catch (Exception ex)
            {
                return new UserDetailDALModel()
                {
                    AdditionalStatusCode = 500,
                    HttpStatus = HttpStatusCode.InternalServerError,
                    UserDetails = null,
                    Message = ex.Message
                };
            }
        }
    }
}

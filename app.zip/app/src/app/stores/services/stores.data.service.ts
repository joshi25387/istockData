import { DefaultDataService, HttpUrlGenerator } from '@ngrx/data';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { StoreModel } from '../models/store.model';
import { Update } from '@ngrx/entity';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable()
export class StoresDataService extends DefaultDataService<StoreModel>{
  
  entities: StoreModel[] = [];
  
  
  constructor(http : HttpClient, httpUrlGenerator : HttpUrlGenerator){
      super('Store',http,httpUrlGenerator);
  }

  storeData : StoreModel[] = [
    {
      id  :  1,
      clientId : 1,
      storeName : 'Store 1',
      contactName : 'Account Manager Name',
      phone : '9876767676',
      email : 'email.gmail.com',
      isActive: true,
      storeAddress : {
        address1 : 'Address1',
        address2 : 'Address2',
        city : 1,
        state : 1,
        pincode : 910989
      },
      geoLocationModel : {
        latitude : '7676868787',
        longitude : '98980980980'        
      },
      bankDetails : [
        {
          accountName : 'Account name',
          accountNumber : '8768768767867',
          accBankName : 1,
          accBranch : 2,
          ifsc : 'IFSC123'
        }
      ],
      kycDocuments : [
        {
          document : 1,
          fileName : "",
          base64String : "",
          filePath : ""
        }
      ],
      createdDate : new Date()
      
    },
    {
      id  :  2,
      clientId : 2,
      storeName : 'Store 2',
      contactName : 'Account Manager Name2',
      phone : '9876767677',
      email : 'email.gmail.com',
      isActive: true,
      storeAddress : {
        address1 : 'Address1',
        address2 : 'Address2',
        city : 1,
        state : 1,
        pincode : 910989
      },
      geoLocationModel : {
        latitude : '7676868787',
        longitude : '98980980980'        
      },
      bankDetails : [
        {
          accountName : 'Account name',
          accountNumber : '8768768767867',
          accBankName : 1,
          accBranch : 2,
          ifsc : 'IFSC123'
        }
      ],
      kycDocuments : [
        {
          document : 1,
          fileName : "",
          base64String : "",
          filePath : ""
        }
      ],
      createdDate : new Date()
    }
  ];


  getAll() : Observable<StoreModel[]>{
    return this.http.get(environment.apiUrl + "store").pipe(map(response => response['storeList']));
  }
  
  add(client : StoreModel)  : Observable<StoreModel>{    
    return this.http
      .post<StoreModel>(environment.apiUrl + 'store/', client).pipe(map(res=>res['storeData']));
  }
  update(update : Update<StoreModel>): Observable<StoreModel>{   
    return this.http.put<StoreModel>(environment.apiUrl+ 'store/'+update.id, update.changes);
  }

  delete(id: number): Observable<number> {    
  return this.http.delete(environment.apiUrl+ 'store/' + id).pipe(map(res=>id));        
  }

  // getAll() : Observable<StoreModel[]>{    
  //    //return this.http.get<StoreModel[]>('/api/storess');                     
  //    return of(this.storeData);
  // }
  

  // add(store : StoreModel) : Observable<StoreModel>{
  //   //this.storeData.push(store);
  //   return of(store);
  // }

  // update(update : Update<StoreModel>): Observable<StoreModel>{
  //   let updatedEntity = null;
  //   this.entities = this.entities.map((e, i) => {
  //     if ((e as any).id === update.id) {
  //       updatedEntity = {
  //         ...e,
  //         ...update.changes
  //       };
  //       return updatedEntity;
  //     }
  //     return e;
  //   });
  //   return of(updatedEntity);
  // }

  // delete(id: number): Observable<number> {
  //   this.entities = this.entities.filter(e => (e as any).id !== id);    
  //   return of(id);
  // }

 

}
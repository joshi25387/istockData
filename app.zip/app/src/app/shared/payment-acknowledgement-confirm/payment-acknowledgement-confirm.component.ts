import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'paymentConfirm',
  templateUrl: './payment-acknowledgement-confirm.component.html',
  styleUrls: ['./payment-acknowledgement-confirm.component.css']
})
export class PaymentAcknowledgementConfirmComponent implements OnInit {

  @Input() message : string;
  @Input() billAmount : number;

  @Output() ok = new EventEmitter<any>();
  @Output() cancel = new EventEmitter<any>();

  showAmountAlert : boolean = false;
  labelText : string = "";

  acknowledgementForm : FormGroup;

  constructor(private fb : FormBuilder) { }

  ngOnInit(): void {
console.log(this.billAmount);
    this.acknowledgementForm = this.fb.group({
      amount : ['',Validators.required],
      remarks : ['']
    });
  }

  get f() { return this.acknowledgementForm.controls; }


  checkAmount(){
    this.showAmountAlert=false;
    let amount = +this.acknowledgementForm.get('amount').value;
    if(amount < this.billAmount){
      this.labelText = "Received amount is less than actual bill amount !";
      this.showAmountAlert = true;
    }        
  }

  onOk(){
    let amount = +this.acknowledgementForm.get('amount').value;
    if(amount > this.billAmount){
      //this.labelText = "Received amount is less than actual bill amount !"
      this.labelText = "Received amount cannot be more than actual bill amount !";
      this.showAmountAlert = true;
      return;
    }
    this.ok.emit({amount : this.acknowledgementForm.get('amount').value , remarks : this.acknowledgementForm.get('remarks').value});
  }
  onCancel(){
    this.cancel.emit();
  }


}

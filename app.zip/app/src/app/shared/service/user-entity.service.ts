import { EntityCollectionServiceBase, EntityCollectionServiceElementsFactory } from '@ngrx/data';
import { Injectable } from '@angular/core';
import { UserDetail } from 'src/app/auth/models/user.model';


@Injectable({providedIn  :'root'})
export class UserDetailEntityService extends EntityCollectionServiceBase<UserDetail> {
  constructor(serviceElementsFactory : EntityCollectionServiceElementsFactory){
      super('UserDetail',serviceElementsFactory);
  }
}
﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class Ftpdetails
    {
        public long Id { get; set; }
        public string FtpIp { get; set; }
        public string FtpPassword { get; set; }
        public string FtpUser { get; set; }
        public int? FtpPort { get; set; }
        public string FtpStaticIp { get; set; }
        public string FtpStaticPassword { get; set; }
        public string FtpStaticUser { get; set; }
        public int? FtpStaticPort { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}

import {
  ActionReducer,
  ActionReducerMap,
  createFeatureSelector,
  createSelector,
  MetaReducer,
  createReducer,
  on
} from '@ngrx/store';
import { User } from '../models/user.model';
import { AuthActions } from '../action-types';
import { AppState } from 'src/app/reducers';



export const authFeatureKey = 'auth';

export interface AuthState {
  user : User,
  errorMessage : string
}
export const initialAuthState : AuthState = {
  user : undefined,
  errorMessage : ""  
}

export const authReducer = createReducer(
  initialAuthState,

  on(AuthActions.authenticateUser, (state,action) => {
    return {
      user : undefined,
      errorMessage : ""      
    }
  }),
  
  on(AuthActions.login, (state,action) => {
    return {
      user : action.user,
      errorMessage : ""      
    }
  }),
  
  on(AuthActions.loginFailed ,(state,action) => {
    return {
      user : undefined,
      errorMessage : action.error  
    }
  }),
  on(AuthActions.logout, (state,action) => {    
    return {
      user : undefined,
      errorMessage : ""      
    }
  }),
  on(AuthActions.setUser, (state,action) => {
    return {
      user : action.user,
      errorMessage : ""      
    }
  }),
  on(AuthActions.resetErrorMessage, (state,action) => {
    return {      
      errorMessage : ""      
    }
  })
  
)



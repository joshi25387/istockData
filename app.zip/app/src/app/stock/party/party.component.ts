import { state } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { CityModel, PartyGroupModel, PartyModel, StateModel } from '../model/master-data.model';
import { MasterDataService } from '../services/master-data.service';

@Component({
  selector: 'party',
  templateUrl: './party.component.html',
  styleUrls: ['./party.component.css']
})
export class PartyComponent implements OnInit {

  partyForm: FormGroup;

  partyGroupList : PartyGroupModel[] = [];

  stateList : StateModel[]= [];
  cityList : CityModel[]= [];

  alertMessage: string = null;
  editMode: boolean = false;
  viewMode: boolean = false;
  
  cardText : string = "Add Party";
  buttonText: string = "Submit";

  errorAlertMessage : string = '';
  
  party: PartyModel;

  constructor(private fb: FormBuilder,
    private router: Router,
    private masterDataService : MasterDataService,
    private route: ActivatedRoute,    
    private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.partyForm = this.fb.group({
      id: [''],
      partyName : ['',Validators.required],
      partyGroupId: ['', Validators.required],
      partyGroupName : [''],
      partyAddress : ['',Validators.required],
      stateId : ['',Validators.required],
      cityId : ['',Validators.required],
      pincode : [''],
      panNo : ['',Validators.required],
      creditLimit : [''],
      paymentTerms : [''],
      contactNo : ['',Validators.required],
      email : ['']
    });

    this.partyForm.get('stateId').valueChanges.subscribe(stateId => {
      let _stateId = +stateId;
      if(_stateId > 0){
        this.masterDataService.getCityList(_stateId).subscribe(res=>{
          this.cityList = res;
        });
      }
    });


    this.masterDataService.getPartyGroupList().subscribe(res=>{
      if(res){
        this.partyGroupList = res;
      }      
    });

    this.masterDataService.getStateList().subscribe(res=>{
      if(res){
        this.stateList = res;
      }
    });

    this.route.params.subscribe(
      (params: Params) => {
        this.editMode = !!params['id'];
        this.buttonText = this.editMode ? "Update" : "Submit";
        if (this.editMode) {
          this.cardText = "Update Party";
          const partyIdToEdit = +params['id'];

          this.masterDataService.getPartyById(partyIdToEdit).subscribe(res=>{
              this.PopulateForm(res);
          });
        }
      }
    );

    this.partyForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.partyForm);
    });
         
  }



  
  validationMessages = {
    'partyName' : {
      'required' : 'Party name is required'
    },
    'partyGroupId' : {
      'required' : 'Party group is required'
    },
    'panNo' : {
      'required' : 'PAN is required'
    },
    'partyAddress' : {
      'required' : 'Party address is required'
    },
    'stateId' : {
      'required' : 'State is required'
    },
    'cityId' : {
      'required' : 'City is required'
    },
    'contactNo' : {
      'required' : 'Contact no. is required'
    }
  };

  formErrors = {
    'partyName' : '',
    'partyGroupId' : '',
    'panNo' : '',
    'partyAddress' : '',
    'stateId' : '',
    'cityId' : '',
    'contactNo' : ''
  }

  get f() { return this.partyForm.controls; }

  PopulateForm(party: PartyModel) {
    if (party) {      
      this.partyForm.patchValue({
        id: party.id,
        partyName: party.partyName,
        panNo : party.panNo,
        partyGroupId : party.partyGroupId,
        partyGroupName : party.partyGroupName,
        partyAddress : party.partyAddress,
        stateId : party.stateId,
        cityId : party.cityId,
        creditLimit : party.creditLimit,
        paymentTerms : party.paymentTerms,
        contactNo : party.contactNo,
        email : party.email
      });
    }
  }


  onSubmit() {
    this.logValidationErrorsOnSubmit();

    console.log(this.partyForm);
   
    if(this.errorAlertMessage!=''){
      this.alertMessage = this.errorAlertMessage;
      return;
    }
   
    
    if (!this.partyForm.valid) {
      this.alertMessage = "Please enter valid details";      
      return;
    }

    

    let formValue = this.partyForm.getRawValue();
    let partyData: PartyModel = {
      ...this.party,
      ...formValue
    };
    console.log('partyData : ', partyData);

    if (!this.editMode) {   
      this.spinner.show();
      partyData.id = 0;
      this.masterDataService.createParty(partyData).subscribe(res=>{
        console.log('res : ',res);
        if(res){
          if(res['statusCode'] == 200){
            this.partyForm.reset();
          }
          this.alertMessage = res['statusMessage']          
        }
        this.spinner.hide();
      });
    }
    else {
      this.spinner.show();
      this.masterDataService.updateParty(partyData).subscribe(res=>{
        console.log('res : ',res);
        if(res){          
          this.alertMessage = res['statusMessage']          
        }
        this.spinner.hide();
      });
    }
  }

  closeAlert() {
    this.alertMessage = null;    
  }

  logValidationErrors(group : FormGroup = this.partyForm) : void {
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else if(abstractControl instanceof FormArray){
        abstractControl.controls.forEach(control => {
          if(control instanceof FormGroup){
            this.logValidationErrors(control);
          }
        });              
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid &&
          (abstractControl.touched || abstractControl.dirty)){
            const messages = this.validationMessages[key];

            for(const errorKey in abstractControl.errors){
              if(errorKey){
                this.formErrors[key] += messages[errorKey] + ' ';                
              }
            }
          }
      }
    });
  }

  logValidationErrorsOnSubmit(group : FormGroup = this.partyForm) : void {
    this.errorAlertMessage ='';
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else if(abstractControl instanceof FormArray){
        abstractControl.controls.forEach(control => {
          if(control instanceof FormGroup){
            this.logValidationErrors(control);
          }
        });              
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid ){
            const messages = this.validationMessages[key];
            for(const errorKey in abstractControl.errors){
              if(errorKey){
                abstractControl.markAsTouched({ onlySelf: true });
                this.formErrors[key] += messages[errorKey] + ' ';
                if(this.errorAlertMessage == ''){
                  this.errorAlertMessage = messages[errorKey];
                }
              }
            }
          }
      }
    });
  }

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientComponent } from './client/client.component';
import { SharedModule } from '../shared/shared.module';
import { ClientListComponent } from './client-list/client-list.component';
import { ClientsResolver } from './services/clients.resolver';

const clientRoutes  :Routes = [

    {
        path : "" , 
        component : ClientListComponent,
        resolve : {
            clients : ClientsResolver
           }
    },
    {
        path : "new",
        component : ClientComponent
    },
    {
        path : ":id/edit",
        component : ClientComponent
    }
];

@NgModule({
    declarations : [ClientComponent, ClientListComponent],    
    imports : [
        SharedModule,
        RouterModule.forChild(clientRoutes)
    ],
    providers : [
        ClientsResolver
    ],
})
export class ClientsModule { }
import { AgmCoreModule } from '@agm/core';
import { NgModule  } from '@angular/core';
import { ValidationCssDirective } from './directives/validation-css.directive';
import { CommonModule } from '@angular/common';
import { AddressComponent } from './address/address.component';
import { BankDetailComponent } from './bank-detail/bank-detail.component';
import { KycDocumentComponent } from './kyc-document/kyc-document.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgbModule, NgbDateAdapter, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { AlertComponent } from './alert/alert.component';
import { ConfirmComponent } from './confirm/confirm.component';
import { AlphaNumericDirective } from './directives/alphaNumericOnly';
import { AlphaDirective } from './directives/alphaOnly';
import { DecimalDirective } from './directives/decimalOnly';
import { NumberDirective } from './directives/numericOnly';
import { LabelControl } from './directives/labelControl';
import { GeolocationComponent } from './geolocation/geolocation.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { ClientEntityService } from '../clients/services/client-entity.service';
import { ClientsDataService } from '../clients/services/clients.data.service';
import { StoresDataService } from '../stores/services/stores.data.service';
import { StoreEntityService } from '../stores/services/store-entity.service';
import { EntityMetadataMap, EntityDefinitionService, EntityDataService } from '@ngrx/data';
import { AgentEntityService } from '../agents/services/agent-entity.service';
import { AgentsDataService } from '../agents/services/agents.data.service';
import { AgGridModule } from 'ag-grid-angular';
import { EditDeleteButtonRendererComponent } from './ag-grid-renderers/edit-delete-button-renderer';


import { SafePipe } from './pipes/safe-pipe';

import { NgxSpinnerModule } from "ngx-spinner";

import { CustomAdapter, CustomDateParserFormatter } from './service/datepicker.adapter';

import { PincodeDataService } from './address/services/pincode-data.service';

import { AddPOViewButtonRendererComponent } from './ag-grid-renderers/addPo-view-button-renderer';

import { UserDetailDataService } from './service/user-data.service';

import { AcknowledgeCancelButtonRendererComponent } from './ag-grid-renderers/acknowledge-cancel-button-renderer';
import { ViewLinkRendererComponent } from './ag-grid-renderers/view-link-renderer';
import { PaymentAcknowledgementConfirmComponent } from './payment-acknowledgement-confirm/payment-acknowledgement-confirm.component';

import { AcknowledgeRescheduleCancelButtonRendererComponent } from './ag-grid-renderers/acknowledge-reschedule-cancel-button-renderer';


import { ManualReachActionComponent } from './manual-reach-action/manual-reach-action.component';
import { AdminActionsRendererComponent } from './ag-grid-renderers/admin-action-rendered';


import { UserClientStoreMappingDataService } from '../auth/services/user-management-data-service';
import { UserListDataService } from '../auth/services/user-data-service';

import { FtaRescheduleActionComponent } from './fta-reschedule-action/fta-reschedule-action.component';


import { AgentTrackingDataService } from '../agents/services/agent-tracking-data.service';



const entityMetaData : EntityMetadataMap = {
    Store : { },
    Client : { },
    Agent : { },
    Order : { },
    OrderDashboard : { },
    OrderSnapdealDashboard : { },
    OrderJubilant : { },
    Pincode : { },
    OrderJubilantMasters : { },
    OrderJubilantList : { },
    OrderSpar : { },
    OrderSparMasters : { },
    OrderAdani : { },
    OrderAdaniMasters : { },
    OrderBurberry : { },
    OrderBurberryMasters : { },
    UserDetail : { },
    OrderTracking : { },
    AgentTracking : { },
    OrderDelicious : { },
    ManualReach : { },
    OrderBBQ : { },
    OrderBBQMasters : { },
    OrderIGP : { },
    OrderIGPMasters : { },
    OrderSnapdeal : { },
    OrderFTAHSRP : { },
    OrderFTAReschedule : { },
    OrderSearch : { },

    OrderBikanerwala : { },
    OrderBikanerwalaMasters : { },

    UserClientStoreMapping : { },
    UserList : {},
}

@NgModule({
    imports: [
        CommonModule,                
        FormsModule,
        ReactiveFormsModule,        
        AgGridModule.withComponents([EditDeleteButtonRendererComponent]),
        NgbModule,
        NgSelectModule,
        NgxSpinnerModule,
        AgmCoreModule.forRoot({
            // apiKey: 'AIzaSyDGfJVCbFk58qp-dYjGbkZYMCeRIG6odMg'
            //apiKey: 'AIzaSyDZNjew5t-gBKa5ddbumJN5ai8vm0O40kE',
            apiKey: 'AIzaSyAZxwzLAaV7jtqF4Gq9tMU24jRNzORCrJM'
            
          })
    ],
    providers: [
        DatePipe,
        ClientEntityService,
        ClientsDataService,
        StoreEntityService,
        StoresDataService,
        AgentEntityService,
        AgentsDataService,
        AddressComponent,
        BankDetailComponent,
        KycDocumentComponent,
        GeolocationComponent,
        {provide: NgbDateAdapter, useClass: CustomAdapter},
        {provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter}
    ],
    declarations: [
        ValidationCssDirective,
        AddressComponent,
        BankDetailComponent,
        KycDocumentComponent,
        AlertComponent,
        ConfirmComponent,
        AlphaNumericDirective,
        AlphaDirective,
        DecimalDirective,
        NumberDirective,
        LabelControl,
        GeolocationComponent,
        EditDeleteButtonRendererComponent,
        AddPOViewButtonRendererComponent,
        AcknowledgeCancelButtonRendererComponent,
        FtaRescheduleActionComponent,
        AcknowledgeRescheduleCancelButtonRendererComponent,
        AdminActionsRendererComponent,
        ViewLinkRendererComponent,
        SafePipe,
        PaymentAcknowledgementConfirmComponent,        
        ManualReachActionComponent,
        FtaRescheduleActionComponent        
    ],
    exports: [
        CommonModule,        
        FormsModule,
        ReactiveFormsModule,
        ValidationCssDirective,
        AddressComponent,
        BankDetailComponent,
        KycDocumentComponent,
        NgbModule,
        AlertComponent,
        ConfirmComponent,
        AlphaNumericDirective,
        AlphaDirective,
        DecimalDirective,
        NumberDirective,
        LabelControl,
        GeolocationComponent,
        EditDeleteButtonRendererComponent,
        AcknowledgeCancelButtonRendererComponent,
        AcknowledgeRescheduleCancelButtonRendererComponent,
        FtaRescheduleActionComponent,
        ViewLinkRendererComponent,
        AgGridModule,
        SafePipe,
        NgxSpinnerModule,
        PaymentAcknowledgementConfirmComponent,
        ManualReachActionComponent,
        FtaRescheduleActionComponent       
    ]
})
export class SharedModule {
    constructor(private eds : EntityDefinitionService, 
        private entityDataService  : EntityDataService,
        private storesDataService : StoresDataService,
        private clientsDataService : ClientsDataService,
        private agentsDataService : AgentsDataService,        
        private pincodeDataService : PincodeDataService,        
        private userDetailDataService : UserDetailDataService,        
        private agentTrackingDataService : AgentTrackingDataService,                           
        private userClientStoreMapping : UserClientStoreMappingDataService,
        private userListMapping : UserListDataService,            
        ){

        eds.registerMetadataMap(entityMetaData);

        entityDataService.registerService('Store', storesDataService);
        entityDataService.registerService('Client', clientsDataService);
        entityDataService.registerService('Agent', agentsDataService);        
        entityDataService.registerService('Pincode', pincodeDataService);            
        entityDataService.registerService('UserDetail', userDetailDataService);            
        entityDataService.registerService('AgentTracking', agentTrackingDataService);                    
        entityDataService.registerService('UserClientStoreMapping', userClientStoreMapping);    
        entityDataService.registerService('UserList', userListMapping);    
    }
}
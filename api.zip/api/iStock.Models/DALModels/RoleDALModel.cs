﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.DALModels
{
   public class RoleDALModel : BaseDALStatus
    {
        public List<RoleModel> RoleList { get; set; }
    }
}

﻿using iStock.CrudBusinessLayer.Interfaces;
using iStock.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace iStock.ApiLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StockController : ControllerBase
    {
        private readonly IStockCrudLogics stockDataCrudOps;

        public StockController(IStockCrudLogics stockDataCrudOps)
        {
            this.stockDataCrudOps = stockDataCrudOps;
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetIncomingOrders")]
        public async Task<IActionResult> GetIncomingOrders()
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await stockDataCrudOps.GetIncomingOrders(requestor);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetIncomingOrderById/{id}")]
        public async Task<IActionResult> GetIncomingOrderById(int id)
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await stockDataCrudOps.GetIncomingOrderById(requestor, id);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("CreateIncomingOrder")]
        public async Task<IActionResult> CreateIncomingOrder([FromBody] IncomingOrderModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await stockDataCrudOps.CreateIncomingOrder(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("UpdateIncomingOrder")]
        public async Task<IActionResult> UpdateIncomingOrder([FromBody] IncomingOrderModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await stockDataCrudOps.UpdateIncomingOrder(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeleteIncomingOrder/{id}")]
        public async Task<IActionResult> DeleteIncomingOrder(int id)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await stockDataCrudOps.DeleteIncomingOrder(requestor, id);
        }





        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetPerformaInvoices")]
        public async Task<IActionResult> GetPerformaInvoices()
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await stockDataCrudOps.GetPerformaInvoices(requestor);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetPerformaInvoiceById/{id}")]
        public async Task<IActionResult> GetPerformaInvoiceId(int id)
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await stockDataCrudOps.GetPerformaInvoiceById(requestor, id);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("CreatePerformaInvoice")]
        public async Task<IActionResult> CreatePerformaInvoice([FromBody] PerformaInvoiceModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await stockDataCrudOps.CreatePerformaInvoice(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("UpdatePerformaInvoice")]
        public async Task<IActionResult> UpdatePerformaInvoice([FromBody] PerformaInvoiceModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await stockDataCrudOps.UpdatePerformaInvoice(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeletePerformaInvoice/{id}")]
        public async Task<IActionResult> DeletePerformaInvoice(int id)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await stockDataCrudOps.DeletePerformaInvoice(requestor, id);
        }
    }
}

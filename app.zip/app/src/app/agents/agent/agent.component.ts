import { Component, OnInit,Input,Output,EventEmitter} from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormsModule, FormControl } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AgentEntityService } from '../services/agent-entity.service';
import { map } from 'rxjs/operators';
import { Agent } from '../models/agent.model';
import { BankDetail } from 'src/app/shared/models/bankDetail.model';
import { KycDocument } from 'src/app/shared/models/kycDocument.model';
import { AgentStoreMapDetails } from '../models/agentStoreMapDet';
import { NgSelectModule } from '@ng-select/ng-select';
import { ClientModel } from 'src/app/clients/models/client.model';
import { Observable } from 'rxjs';
import { StoreModel } from 'src/app/stores/models/store.model';
import { ClientEntityService } from 'src/app/clients/services/client-entity.service';
import { StoreEntityService } from 'src/app/stores/services/store-entity.service';
import { Store } from '@ngrx/store';
import { SharedService } from 'src/app/shared/service/shared.service';


@Component({
  selector: 'agent',
  templateUrl: './agent.component.html',
  styleUrls: ['./agent.component.css']
})
export class AgentComponent implements OnInit {
 
  agentForm: FormGroup;
  alertMessage: string = null;
  editMode: boolean = false;
  
  agentStoreMapping: FormArray;
  agentIMEIDetails: FormArray;
  
  buttonText: string = "Submit";
  totalAgentCount: number = -1;

  clients$: Observable<ClientModel[]>;
  clientStores$ : Observable<StoreModel[]>;

  constructor(private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private agentEntityService: AgentEntityService,
    private clientEntityService: ClientEntityService,
    private storeEntityService: StoreEntityService,
    private sharedService: SharedService) { }

  ngOnInit(): void {
    this.agentForm = this.fb.group({
      id: [''],
      agentName: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.pattern("^(?:(?:\\+|0{0,2})91(\\s*[\\-]\\s*)?|[0]?)?[6789]\\d{9}$")]],
      email: ['', [Validators.required, Validators.email]],
      vehicleType: ['', Validators.required],
      vehicleNumber: ['', Validators.required],
      drivingLicenseNo: ['', Validators.required],
      aadharNo: ['', Validators.required, Validators.pattern("/[0-9]{12}/")],
      panNumber: ['', Validators.required, Validators.pattern("^([A-Z]){5}([0-9]){4}([A-Z]){1}$")],
      agentStoreMapping: this.fb.array([this.createMapping()]),
      imeiDetails: this.fb.array([this.createIMEIMapping()]),
      permanentAddress: [],
      currentAddress: [],
      geolocation: [],
      bankDetails: this.fb.array([]),
      kycDocuments: this.fb.array([])
    });

    this.AddBank();
    this.AddKycDocument();

    this.route.params.subscribe(
      (params: Params) => {
        this.editMode = !!params['id'];
        this.buttonText = this.editMode ? "Update" : "Submit";
        if (this.editMode) {

          const agentIdToEdit = +params['id'];

          if (!this.agentEntityService.loaded$) {
            this.agentEntityService.getByKey(agentIdToEdit).subscribe(store => {
              this.PopulateForm(store);
            });
          }
          else {
            this.agentEntityService.entities$.pipe(
              map(agents => agents.find(agent => agent.id == agentIdToEdit))
            ).subscribe(agent => {
              this.PopulateForm(agent);
            });
          }

        }
      }
    );

    this.agentEntityService.count$.subscribe(count => {
      this.totalAgentCount = count;
    });

    this.clients$ = this.clientEntityService.entities$;  
    this.clientStores$ = this.storeEntityService.entities$;   

    this.clientEntityService.loaded$.subscribe(loaded => {
      if(!loaded){
        this.clientEntityService.getAll();
      }
    });

    this.storeEntityService.loaded$.subscribe(loaded => {
      if(!loaded){
        this.storeEntityService.getAll();
      }
    });
    
    
  
  }

  get f() { return this.agentForm.controls; }

  PopulateForm(agent: Agent) {
    this.agentForm.patchValue({
      id: agent.id,
      agentName: agent.agentName,
      mobile: agent.mobile,
      email: agent.email,
      vehicleType: agent.vehicleType,
      vehicleNumber: agent.vehicleNumber,
      drivingLicenseNo: agent.drivingLicenseNo,
      aadharNo: agent.aadharNo,
      panNumber: agent.panNumber
    });


    (<FormGroup>this.agentForm.get('permanentAddress')).patchValue({
      address1: agent.permanentAddress.address1,
      address2: agent.permanentAddress.address2,
      state: agent.permanentAddress.state,
      city: agent.permanentAddress.city,
      pincode: agent.permanentAddress.pincode
    });

    (<FormGroup>this.agentForm.get('currentAddress')).patchValue({
      address1: agent.currentAddress.address1,
      address2: agent.currentAddress.address2,
      state: agent.currentAddress.state,
      city: agent.currentAddress.city,
      pincode: agent.currentAddress.pincode
    });

    (<FormGroup>this.agentForm.get('geolocation')).patchValue({
      latitude: agent.geolocation.latitude,
      longitude: agent.geolocation.latitude
    });

    this.agentForm.setControl('agentStoreMapping', this.GetAgentStoreArray(agent.agentStoreMapping));
    this.agentForm.setControl('bankDetails', this.GetBankFormArray(agent.bankDetails));
    this.agentForm.setControl('kycDocuments', this.GetKycDocsFormArray(agent.kycDocuments));
    this.agentForm.setControl('imeiDetails', this.GetImeiArray(agent.imeiDetails));
  }

  GetImeiArray(imeiDetails: string[]) : FormArray{
    const _formArray = this.fb.array([]);
    imeiDetails.forEach(element => {
      _formArray.push(this.fb.group({
        imei : element
        })
      )
    })
    return _formArray;
  }

  GetAgentStoreArray(agentStoreMapping: AgentStoreMapDetails[]): FormArray {
    const _formArray = this.fb.array([]);

    agentStoreMapping.forEach(element => {
      const _formGp = this.fb.group({
        clientId: element.clientId,
        storeId: [element.storeId]
        });

        _formGp.get('clientId').valueChanges.subscribe(clientId => {
          _formGp.get('storeId').setValue('');
          this.clientStores$ = this.storeEntityService.entities$.pipe(
                              map(store => store.filter(st => st.clientId == clientId))
                            ) ;   
        });

      _formArray.push(
        _formGp
      )
    })
    return _formArray;
  }

  GetBankFormArray(bankArray: BankDetail[]): FormArray {
    const _formArray = this.fb.array([]);
    bankArray.forEach(element => {
      
      
      _formArray.push(this.fb.group({
        bankDet: element
      }));
    });

    return _formArray;
  }

  GetKycDocsFormArray(kycDocArray: KycDocument[]): FormArray {
    const _formArray = this.fb.array([]);
    kycDocArray.forEach(element => {
      _formArray.push(this.fb.group({
        kycDet: element
      }));
    });
    return _formArray;
  }

  AddBank() {
    const _fArray = <FormArray>this.agentForm.get('bankDetails');
    const _bankDet: BankDetail = {
      accountName: "",
      accountNumber: "",
      accBankName: -1,
      accBranch: -1,
      ifsc: ""
    };
    const _fgrp = this.fb.group(
      {
        bankDet: _bankDet
      }
    );
    _fArray.push(_fgrp);
  }

  DeleteBank(bankDetIndex: number) {
    (<FormArray>this.agentForm.get('bankDetails')).removeAt(bankDetIndex);
  }

  AddKycDocument() {
    const _fArray = <FormArray>this.agentForm.get('kycDocuments');
    const _kycDet: KycDocument = {
      document: -1,
      fileName: "",
      base64String: "",
      filePath: ""
    };
    const _fgrp = this.fb.group(
      {
        kycDet: _kycDet
      }
    );
    _fArray.push(_fgrp);
  }

  DeleteKycDocument(kycDocIndex: number) {
    (<FormArray>this.agentForm.get('kycDocuments')).removeAt(kycDocIndex);
  }

  createMapping(): FormGroup {
    const _fbGrp = this.fb.group({
      clientId : ['', Validators.required],
      storeId : ['', Validators.required]      
    });

    _fbGrp.get('clientId').valueChanges.subscribe(clientId => {
      
      this.clientStores$ = this.storeEntityService.entities$.pipe(
                          map(store => store.filter(st => st.clientId == clientId))
                        ) ;   
    });

    return _fbGrp;
  }

  addMapping() {
    const _fArray = <FormArray>this.agentForm.get('agentStoreMapping');

    const _fbGrp = this.fb.group({
      clientId : [''],
      storeId : ['']      
    });

    _fbGrp.get('clientId').valueChanges.subscribe(clientId => {
      
      this.clientStores$ = this.storeEntityService.entities$.pipe(
                          map(store => store.filter(st => st.clientId == clientId))
                        ) ;   
    });
    _fArray.push(_fbGrp);
  }

  deleteMapping(agentStoreIndex: number) {
    (<FormArray>this.agentForm.get('agentStoreMapping')).removeAt(agentStoreIndex);
  }

  onSubmit() {
    if (!this.agentForm.valid) {
      
      this.alertMessage = "Please enter valid details";
      this.validateAllFormFields(this.agentForm);
      this.sharedService.setValidateAddress(true);
      this.sharedService.setValidateBankDetails(true);
      this.sharedService.setValidateGeolocation(true);
      this.sharedService.setValidateKycDetails(true); 
      return;
    }
    const formValue = this.agentForm.value;

    const agentData: Agent = this.agentForm.value;

    const _bankDetArray: BankDetail[] = [];
    const _kycDocArray: KycDocument[] = [];

    formValue['bankDetails'].forEach(element => {
      const bankDet: BankDetail = element['bankDet'];
      _bankDetArray.push(bankDet);
    });
    formValue['kycDocuments'].forEach(element => {
      const kycDoc: KycDocument = element['kycDet'];
      _kycDocArray.push(kycDoc);
    });


    agentData.agentStoreMapping = formValue.agentStoreMapping;
    agentData.permanentAddress = formValue.permanentAddress;
    agentData.currentAddress = formValue.currentAddress;
    agentData.bankDetails = _bankDetArray;
    agentData.kycDocuments = _kycDocArray;


    if (!this.editMode) {

      agentData.id = this.totalAgentCount + 1;
      agentData.createdDate = new Date();
      this.agentEntityService.add(agentData);
      this.alertMessage = "Agent added successfully";
      //this.storeForm.reset();
    }
    else {
      this.agentEntityService.update(agentData);
      this.alertMessage = "Agent updated successfully";
    }
  }

  closeAlert() {
    this.alertMessage = null;
    if (this.agentForm.valid) {
      this.router.navigateByUrl('/agents');
    }
  }

  getValues() {
    
  }

  deleteIMEI(imeiIndex: number) {
    (<FormArray>this.agentForm.get('imeiDetails')).removeAt(imeiIndex);
  }

  
  addIMEI() {
    const _fArray = <FormArray>this.agentForm.get('imeiDetails');

    const _fbGrp = this.fb.group({
      imei: [''] 
    });

    _fArray.push(_fbGrp);
  }
  
  createIMEIMapping(): FormGroup {
      return this.fb.group({
        imei: ['', Validators.required]
      })
    }
 
    validateAllFormFields(formGroup: FormGroup) {
      Object.keys(formGroup.controls).forEach(field => {  
        const control = formGroup.get(field);             
        if (control instanceof FormControl) {             
          control.markAsTouched({ onlySelf: true });
        } else if (control instanceof FormGroup) {        
          this.validateAllFormFields(control);            
        } 
      });
    }

}

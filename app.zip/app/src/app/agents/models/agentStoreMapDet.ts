export interface AgentStoreMapDetails {
    clientId: number,
    storeId: number[]
}
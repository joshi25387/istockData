import { EntityCollectionServiceBase, EntityCollectionServiceElementsFactory } from '@ngrx/data';

import { Injectable } from '@angular/core';
import { PincodeModel } from '../../models/address.model';

@Injectable({ providedIn: 'root' })
export class PincodeEntityService extends EntityCollectionServiceBase<PincodeModel>{
    constructor(serviceElementsFactory : EntityCollectionServiceElementsFactory){
        super('Pincode',serviceElementsFactory);
    }    
}
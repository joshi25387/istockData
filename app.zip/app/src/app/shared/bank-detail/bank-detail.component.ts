import { Component, OnInit, OnDestroy, forwardRef, Input, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ControlValueAccessor, Validator, NG_VALUE_ACCESSOR, NG_VALIDATORS, FormArray, FormControl } from '@angular/forms';
import { BankDetail } from '../models/bankDetail.model';
import { BehaviorSubject } from 'rxjs';
import { SharedService } from '../service/shared.service';

@Component({
  selector: 'bank-detail',
  templateUrl: './bank-detail.component.html',
  styleUrls: ['./bank-detail.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => BankDetailComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => BankDetailComponent),
      multi: true
    }
  ]
})
export class BankDetailComponent implements OnInit, ControlValueAccessor, Validator {

  bankDetailForm: FormGroup;
  validateBankDetails$: BehaviorSubject<boolean> = new BehaviorSubject(false);

  constructor(private fb: FormBuilder,
    private sharedService : SharedService) { }

  public onTouched: () => void = () => { };

  writeValue(val: any): void {

    val && this.bankDetailForm.setValue(val, { emitEvent: false });
  }
  registerOnChange(fn: any): void {
    this.bankDetailForm.valueChanges.subscribe(fn);
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    isDisabled ? this.bankDetailForm.disable() : this.bankDetailForm.enable();
  }

  validate(control: import("@angular/forms").AbstractControl): import("@angular/forms").ValidationErrors {
    return this.bankDetailForm.valid ? null : { invalidForm: { valid: false, message: "bankDetailForm fields are invalid" } };
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  ngOnInit(): void {
    this.bankDetailForm = this.fb.group({
      id: [''],
      accountName: ['', Validators.required],
      accountNumber: ['', Validators.required],
      ifsc: ['', [Validators.required, Validators.pattern("^([A-a-z]){5}([0-9]){7}$")]],
      accBankName: ['', Validators.required],
      accBranch: ['', Validators.required],
      isActive: ['']
    });
    
    this.sharedService.validateBankDetails$.subscribe(validateBankDet => {
      if(validateBankDet){
        this.validateAllFormFields(this.bankDetailForm);
      }
    });

    setTimeout(() => {

      let accBankNameValue = +this.bankDetailForm.get('accBankName').value;
      let accBranchValue = +this.bankDetailForm.get('accBranch').value;

      if (accBankNameValue <= 0) {
        this.bankDetailForm.patchValue({
          accBankName: ''
        });
      }
      if (accBranchValue <= 0) {
        this.bankDetailForm.patchValue({
          accBranch: ''
        });
      }
    }, 0)
  }

  ngOnDestroy(){
    this.sharedService.setValidateBankDetails(false);
  }

  get f() { return this.bankDetailForm.controls; }

}

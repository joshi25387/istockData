import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FtaRescheduleActionComponent } from './fta-reschedule-action.component';

describe('FtaRescheduleActionComponent', () => {
  let component: FtaRescheduleActionComponent;
  let fixture: ComponentFixture<FtaRescheduleActionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FtaRescheduleActionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FtaRescheduleActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

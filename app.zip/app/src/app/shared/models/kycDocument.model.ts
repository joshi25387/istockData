

export interface KycDocument{
    id? : number,
    document : number,
    fileName : string,
    base64String? : string;
    filePath? : string;
}
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentTrackingComponent } from './agent-tracking.component';

describe('AgentTrackingComponent', () => {
  let component: AgentTrackingComponent;
  let fixture: ComponentFixture<AgentTrackingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentTrackingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { tap, filter, first } from 'rxjs/operators';
import { StoreEntityService } from './store-entity.service';

@Injectable()
export class StoresResolver implements Resolve<boolean>{
    
    constructor(private storesEntityService : StoreEntityService){}
    
    resolve(
             route : ActivatedRouteSnapshot,
             state : RouterStateSnapshot
        ) : Observable<boolean>{

            return this.storesEntityService.loaded$
                    .pipe(
                        tap(loaded => {
                            if(!loaded){
                                this.storesEntityService.getAll();
                            }
                        }),
                        filter(loaded => !!loaded),
                        first()
                    );
        }
}
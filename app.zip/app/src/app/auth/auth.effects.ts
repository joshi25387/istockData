import { Injectable } from '@angular/core';
import { Actions, ofType, createEffect } from '@ngrx/effects';
import { AuthActions } from './action-types';
import { tap, concatMap, map, catchError } from 'rxjs/operators';
import { login, loginFailed } from './auth.actions';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
import { of, Observable, empty } from 'rxjs';
import { toggleSideNav } from '../side-nav/side-nav.actions';
import { UserDetailEntityService } from '../shared/service/user-entity.service';

@Injectable()
export class AuthEffects {


    authenticateUser$ = createEffect(() =>
                                this.actions$
                                        .pipe(
                                            ofType(AuthActions.authenticateUser),
                                            concatMap(
                                                action => this.authService.authenticateUser(action.userId,action.password)
                                                                    .pipe(
                                                                            map(
                                                                                user => {
                                                                                    if(user.token && user.token!=null){
                                                                                        return login({user})                                                                            
                                                                                    }
                                                                                    else{
                                                                                        return loginFailed({error : "Invalid Credentials"});        
                                                                                    }                                                                                    
                                                                                }
                                                                            ),
                                                                            catchError(err => {
                                                                                console.log('error : ',err);
                                                                                var _errorMessage = "";
                                                                                if(err.error == 'Invalid Credentials'){
                                                                                    _errorMessage = err.error;
                                                                                }
                                                                                else{
                                                                                    _errorMessage = "Application not responding. Please try after sometime";
                                                                                }
                                                                                return of(loginFailed({error : _errorMessage }));
                                                                            })                                                                            
                                                                        )
                                            )
                                        )
                            );

    
    login$ = createEffect(() => 
                        this.actions$
                            .pipe(
                                ofType(AuthActions.login),
                                tap(action => {

                                    
                                    

                                    localStorage.setItem('user', JSON.stringify(action.user));
                                   
                                    
                                    //this.router.navigateByUrl('/orders/dashboard');
                                    this.router.navigateByUrl('/stock/home');
                                })
                            ),{dispatch : false});

            
    logout$ = createEffect(() => 
                            this.actions$
                                .pipe(
                                    ofType(AuthActions.logout),
                                    tap(action => {
                                      
                                        localStorage.removeItem('user');
                                        this.router.navigateByUrl('/login');
                                    })
                                ),{dispatch : false}
                    );

    constructor(private actions$  : Actions, private authService : AuthService, private router : Router
            ){

    }




    
}
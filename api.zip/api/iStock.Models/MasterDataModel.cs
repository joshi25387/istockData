﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models
{
    public class ArrivalPortMasterModel
    {
        public int Id { get; set; }
        public string City { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
    public class CountryMasterModel
    {
        public int Id { get; set; }
        public string Country { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
    public class StateMasterModel
    {
        public int Id { get; set; }
        public string StateName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
    public class CityMasterModel
    {
        public int Id { get; set; }
        public int StateId { get; set; }
        public string StateName { get; set; }
        public string CityName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }

    public class DocumentStatusMasterModel
    {
        public int Id { get; set; }
        public string DocStatus { get; set; }
    }

    public class PartyGroupMasterModel
    {
        public int Id { get; set; }
        public string GroupName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }

    public class PartyMasterModel
    {
        public int Id { get; set; }
        public string PartyName { get; set; }
        public int PartyGroupId { get; set; }
        public string PartyGroupName { get; set; }
        public string PartyAddress { get; set; }
        public int StateId { get; set; }
        public string StateName { get; set; }
        public int CityId { get; set; }
        public string CityName { get; set; }
        public string Pincode { get; set; }
        public string PanNo { get; set; }
        public decimal CreditLimit { get; set; }
        public int PaymentTerms { get; set; }
        public string ContactNo { get; set; }
        public string Email { get; set; }
        public string StoreRentCalculationType { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
    public class ShippingLineMasterModel
    {
        public int Id { get; set; }
        public string ShippingLine { get; set; }
    }

    public class ItemGroupMasterModel
    {
        public int? Id { get; set; }
        public string ItemGroupName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }

    public class ItemMasterModel
    {
        public int? Id { get; set; }
        public int ItemGroupId { get; set; }
        public string ItemGroupName { get; set; }
        public string ItemName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }

        public List<ItemBrandMasterModel> ItemBrandList { get; set; }
        public List<ItemPackingMasterModel> ItemPackingList { get; set; }
        public List<ItemCountMasterModel> ItemCountList { get; set; }
    }

    public class ItemBrandMasterModel
    {
        public int? Id { get; set; }
        public string ItemBrandName { get; set; }
    }

    public class ItemPackingMasterModel
    {
        public int? Id { get; set; }
        public string ItemPacking { get; set; }
    }
    public class ItemCountMasterModel
    {
        public int? Id { get; set; }
        public string ItemCount { get; set; }
    }


}


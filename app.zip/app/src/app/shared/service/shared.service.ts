import { BehaviorSubject } from 'rxjs';
import { OnInit, Injectable } from '@angular/core';

@Injectable({providedIn : 'root'})
export class SharedService implements OnInit{
    validateAddress$ : BehaviorSubject<boolean> = new BehaviorSubject(false);
    validateBankDetails$ : BehaviorSubject<boolean> = new BehaviorSubject(false);
    validateKycDetails$ : BehaviorSubject<boolean> = new BehaviorSubject(false);
    validateGeolocation$ : BehaviorSubject<boolean> = new BehaviorSubject(false);

    ngOnInit(): void {

    }

    setValidateAddress(value : boolean){
        this.validateAddress$.next(value);
    }

    setValidateBankDetails(value : boolean){
        this.validateBankDetails$.next(value);
    }

    setValidateKycDetails(value : boolean){
        this.validateKycDetails$.next(value);
    }

    setValidateGeolocation(value : boolean){
        this.validateGeolocation$.next(value);
    }

}
﻿using iStock.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace iStock.CrudBusinessLayer.Interfaces
{
    public interface IStockCrudLogics
    {
        Task<IActionResult> GetIncomingOrders(string requestor);
        Task<IActionResult> GetIncomingOrderById(string requestor, int id);
        Task<IActionResult> CreateIncomingOrder(string requestor, IncomingOrderModel model);
        Task<IActionResult> UpdateIncomingOrder(string requestor, IncomingOrderModel model);
        Task<IActionResult> DeleteIncomingOrder(string requestor, int id);

        Task<IActionResult> GetPerformaInvoices(string requestor);
        Task<IActionResult> GetPerformaInvoiceById(string requestor, int id);
        Task<IActionResult> CreatePerformaInvoice(string requestor, PerformaInvoiceModel model);
        Task<IActionResult> UpdatePerformaInvoice(string requestor, PerformaInvoiceModel model);
        Task<IActionResult> DeletePerformaInvoice(string requestor, int id);
    }
}

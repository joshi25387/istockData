﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class CityMaster
    {
        public CityMaster()
        {
            PartyMaster = new HashSet<PartyMaster>();
        }

        public int Id { get; set; }
        public int StateId { get; set; }
        public string CityName { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual StateMaster State { get; set; }
        public virtual ICollection<PartyMaster> PartyMaster { get; set; }
    }
}

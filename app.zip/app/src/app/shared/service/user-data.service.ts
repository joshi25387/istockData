import { DefaultDataService, HttpUrlGenerator } from '@ngrx/data';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { UserDetail } from 'src/app/auth/models/user.model';

@Injectable({providedIn:'root'})
export class UserDetailDataService extends DefaultDataService<UserDetail>{


  entities: UserDetail[] = [];

  constructor(http: HttpClient, httpUrlGenerator: HttpUrlGenerator) {
    super('UserDetail', http, httpUrlGenerator);
  }

  getAll() : Observable<UserDetail[]>{
    return this.http.get(environment.apiUrl + "Account/GetUserDetails").pipe(map(response => response['userDetails']));
  } 
}
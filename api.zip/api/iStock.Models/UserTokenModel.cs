﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models
{
    public class UserTokenModel
    {
        public string Token { get; set; }
        public DateTime Expiration { get; set; }
        public string Role { get; set; }
        public string Name { get; set; }
        public string UserCode { get; set; }
    }
}

﻿using iStock.CrudBusinessLayer.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;


namespace iStock.ApiLayer.Controllers
{
    [Route("api/application")]
    [ApiController]
    public class ApplicationController : ControllerBase
    {
        private readonly IApplicationCrudLogics applicationCrudOps;

        public ApplicationController(IApplicationCrudLogics applicationCrudOps)
        {
            this.applicationCrudOps = applicationCrudOps;
        }

        [HttpGet("GetApplicationVersion")]
        public async Task<IActionResult> GetApplicationVersion()
        {          
            return await applicationCrudOps.GetApplicationVersion();
        }


    }
}

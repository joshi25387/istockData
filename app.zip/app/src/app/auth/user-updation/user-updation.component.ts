import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-updation',
  templateUrl: './user-updation.component.html',
  styleUrls: ['./user-updation.component.css']
})
export class UserUpdationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

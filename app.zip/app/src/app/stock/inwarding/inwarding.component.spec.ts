import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InwardingComponent } from './inwarding.component';

describe('InwardingComponent', () => {
  let component: InwardingComponent;
  let fixture: ComponentFixture<InwardingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InwardingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InwardingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

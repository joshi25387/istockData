import { EntityCollectionServiceBase, EntityCollectionServiceElementsFactory } from '@ngrx/data';
import { Injectable } from '@angular/core';
import { UserInfoModel } from '../models/user.model';


@Injectable({providedIn : 'root'})
export class UserClientStoreMappingEntityService extends EntityCollectionServiceBase<UserInfoModel> {
  constructor(serviceElementsFactory : EntityCollectionServiceElementsFactory){
      super('UserClientStoreMapping',serviceElementsFactory);
  }
}
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { IncomingOrderModel, PerformaInvoiceModel } from '../model/order.model';

@Injectable({'providedIn' : 'root'})
export class StockService {

    constructor(private http : HttpClient){}

    getIncomingOrderList(){
        return this.http.get<IncomingOrderModel[]>(environment.apiUrl + 'stock/GetIncomingOrders').pipe(map(res => res['incomingOrderDetails']));
    }
    getIncomingOrderById(id : number){
        return this.http.get<IncomingOrderModel>(environment.apiUrl + 'stock/GetIncomingOrderById/' + id).pipe(map(res => res['incomingOrderDetails']));
    }


    getPerformaInvoiceList(){
        return this.http.get<PerformaInvoiceModel[]>(environment.apiUrl + 'stock/GetPerformaInvoices').pipe(map(res => res['performaInvoiceDetails']));
    }
    getPerformaInvoiceById(id : number){
        return this.http.get<PerformaInvoiceModel>(environment.apiUrl + 'stock/GetPerformaInvoiceById/' + id).pipe(map(res => res['performaInvoiceDetails']));
    }

    createIncomingOrder(model : IncomingOrderModel){
        return this.http.post(environment.apiUrl + 'stock/CreateIncomingOrder',model);
    }
    updateIncomingOrder(model : IncomingOrderModel){
        return this.http.post(environment.apiUrl + 'stock/UpdateIncomingOrder',model);
    }
    deleteIncomingOrder(id : number){
        return this.http.delete(environment.apiUrl + 'stock/DeleteIncomingOrder/'+id.toString());
    }

    createPerformaInvoice(model : PerformaInvoiceModel){
        return this.http.post(environment.apiUrl + 'stock/CreatePerformaInvoice',model);
    }
    updatePerformaInvoice(model : PerformaInvoiceModel){
        return this.http.post(environment.apiUrl + 'stock/UpdatePerformaInvoice',model);
    }
    deletePerformaInvoice(id : number){
        return this.http.delete(environment.apiUrl + 'stock/DeletePerformaInvoice/'+id.toString());
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models
{
    public class DocumentViewModel
    {
        public int Id { get; set; }
        public string MobileNo { get; set; }
        public string DocumentType { get; set; }
        public string Status { get; set; }
        public int StatusId { get; set; }
        public string DocumentPaths { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public List<string> DocumentPathList { get; set; }
        public string NameMatchedWithPoi { get; set; }
        public string SignatureMatchedWithPoi { get; set; }
        public string PhotoMatchedWithPoi { get; set; }
        public string Remarks { get; set; }
        public List<RejectionReasonModel> RejectionReasonId { get; set; }
        public string RejectionReasons { get; set; }
    }

    public class DocumentAuditModel
    {
        public int Id { get; set; }
        public string MobileNo { get; set; }
        public string DocumentType { get; set; }
        public string Status { get; set; }
        public string NameMatchedWithPoi { get; set; }
        public string SignatureMatchedWithPoi { get; set; }
        public string PhotoMatchedWithPoi { get; set; }
        public string Remarks { get; set; }
        public List<RejectionReasonModel> RejectionReasonId { get; set; }        
    }

    public class DocumentModel
    {
        public string MobileNo { get; set; }
        public int DocumentType { get; set; }
        public string DocumentPaths { get; set; }
    }

    public class DocumentCheckModel
    {
        public string MobileNo { get; set; }
        public int DocumentType { get; set; }
    }

    public class SearchModel
    {
        public string MobileNo { get; set; }
        public string DocumentType { get; set; }
        public string Status { get; set; }
        public List<string> RejectionReasonList { get; set; }
        public string Remarks { get; set; }
        public int DocumentCount { get; set; }
        public string CreatedDate { get; set; }
    }

    public class RejectionReasonModel
    {
        public int Id { get; set; }
        public string Reason { get; set; }
    }

    public class FirebaseNotificationModel
    {
        public FirebaseNotificationModel()
        {
            notification = new NotificationModel();
        }

        public string to { get; set; }

        public NotificationModel notification { get; set; }
    }
    public class NotificationModel
    {
        public string body { get; set; }
        public string title { get; set; }
    }

    public class DownloadFileModel
    {
        public FTPDetailModel FtpDetails { get; set; }
        public string FilePath { get; set; }
    }
}

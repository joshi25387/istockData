import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import {NgbDateStruct, NgbCalendar, NgbDateAdapter} from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs';
import { ArrivalPortModel, CountryModel, DocumentStatusModel, ItemBrandModel, ItemCountModel, ItemModel, ItemPackingModel, PartyModel } from '../model/master-data.model';
import { IncomingOrderContainerDetailModel, IncomingOrderContainerItemDetailModel, IncomingOrderModel } from '../model/order.model';
import { MasterDataService } from '../services/master-data.service';
import { StockService } from '../services/stock.service';
import * as moment from 'moment';

@Component({
  selector: 'incoming-order',
  templateUrl: './incoming-order.component.html',
  styleUrls: ['./incoming-order.component.css']
})
export class IncomingOrderComponent implements OnInit {
  orderBookingForm : FormGroup;
  alertMessage: string = null;
  editMode: boolean = false;
  viewMode: boolean = false;

  partyList$ : Observable<PartyModel[]>;
  
  shippingLineList : PartyModel[];
  shipperNameList : PartyModel[];

  customerList : PartyModel[];

  countryList : Observable<CountryModel[]>;
  arrivalPortList : Observable<ArrivalPortModel[]>;

  itemList : ItemModel[];
  brandList : ItemBrandModel[] = [];
  packingList : ItemPackingModel[] = [];
  countList : ItemCountModel[] =[];

  documentStatusList : Observable<DocumentStatusModel[]>;

  cardText : string = "Incoming Order";
  buttonText: string = "Submit";
  
  incomingOrder : IncomingOrderModel;

  errorAlertMessage : string = '';

  constructor(private fb : FormBuilder,
    private router: Router,
    private masterDataService : MasterDataService,
    private stockService : StockService,
    private route: ActivatedRoute,    
    private spinner: NgxSpinnerService) { }
    
  ngOnInit(): void {
    this.orderBookingForm = this.fb.group({
      id : [''],
      blNo : ['', Validators.required],
      arrivalPortId  : ['',Validators.required],    
      loadingWeekNo : [''],
      estDateOfLoading : ['',Validators.required],
      estDateOfArrival : ['',Validators.required],
      countryId : ['',Validators.required],    
      shipperId : ['',Validators.required],    
      invoiceNo : ['',Validators.required],
      noOfContainer : ['',Validators.required],
      packingListQty : ['',Validators.required],
      totalGrossWeight : ['',Validators.required],
      netWeight : ['',Validators.required],
      documentStatusId : ['',Validators.required], 
      documentReceivedDate : [null],   
      vesselNo : ['',Validators.required],
      shippingLineId : ['',Validators.required],    
      shippingTerms : ['',Validators.required],
      paymentTermsAdv : [''],   
      paymentTermsOnDoc : [''],   
      paymentTermsAfterArr : [''],   
      freight : [''],
      currency : ['',Validators.required],
      exchangeRate : [''],
      phytoNo : [''], 
      certificateOfOrigin : [''], 
      nonGmoCertificate : [''], 
      performaInvoiceNo : [''],
      containerDetails : this.fb.array([
        this.addContainerDetailsFormGroup()
      ])
    
    });

    this.arrivalPortList = this.masterDataService.getArrivalPortList();
    this.countryList = this.masterDataService.getCountryList();

    this.partyList$ = this.masterDataService.getPartyList();
    this.masterDataService.getItemList().subscribe(items=>{
      this.itemList = items;
    });
    
    this.documentStatusList = this.masterDataService.getDocumentStatusList();
    

    this.partyList$.subscribe(res=>{
      this.shippingLineList = res.filter(r=>r.partyGroupName.toLowerCase() == "shipping line");
      this.shipperNameList = res.filter(r=>r.partyGroupName.toLowerCase() == "vendor");
      this.customerList = res.filter(r=>r.partyGroupName.toLowerCase() == "customer");
    });

    this.route.params.subscribe(
      (params: Params) => {
        this.editMode = !!params['id'];
        this.buttonText = this.editMode ? "Update" : "Submit";
        if (this.editMode) {
          this.cardText = "Update Incoming Order";
          const incomingOrderIdToEdit = +params['id'];

          this.stockService.getIncomingOrderById(incomingOrderIdToEdit).subscribe(res=>{
              this.PopulateForm(res);
          });
        }
      }
    );
  }
  get f() { return this.orderBookingForm.controls; }
  validationMessages = {    
    'blNo' : {
      'required' : 'B.L. no. is required'
    },
    'arrivalPortId' : {
      'required' : 'Arrival port is required'
    },
    'estDateOfLoading' : {
      'required' : 'Est. date of loading required'
    },
    'estDateOfArrival' : {
      'required' : 'Est. date of arrival is required'
    },
    'countryId' : {
      'required' : 'Country is required'
    },
    'shipperId' : {
      'required' : 'Shipper name is required'
    },
    'invoiceNo' : {
      'required' : 'Invoice no. is required'
    },
    'noOfContainer' : {
      'required' : 'No. of container is required'
    },
    'packingListQty' : {
      'required' : 'Packing list qty is required'
    },
    'totalGrossWeight' : {
      'required' : 'Total gross weight is required'
    },
    'netWeight' : {
      'required' : 'Net weight is required'
    },
    'documentStatusId' : {
      'required' : 'Document status is required'
    },
    'vesselNo' : {
      'required' : 'Vessel no. is required'
    },
    'shippingLineId' : {
      'required' : 'Shipping line is required'
    },
    'shippingTerms' : {
      'required' : 'Shipping terms is required'
    },
    'currency' : {
      'required' : 'Currency is required'
    },
    'containerNo' : {
      'required' : 'Container no. is required'
    },
    'totalQty' : {
      'required' : 'Total qty is required'
    },
    'itemId' : {
      'required' : 'Item is required'
    },
    'brandId' : {
      'required' : 'Brand is required'
    },
    'packingId' : {
      'required' : 'Packing is required'
    },
    'countId' : {
      'required' : 'Item Count is required'
    },
    'qty' : {
      'required' : 'Item qty is required'
    },
    'rate' : {
      'required' : 'Item rate is required'
    }
  };

  formErrors = {
    'blNo' : '',
    'arrivalPortId' : '',
    'estDateOfLoading' : '',
    'estDateOfArrival' : '',
    'countryId' : '',
    'shipperId' : '',
    'invoiceNo' : '',
    'noOfContainer' : '',
    'packingListQty' : '',
    'totalGrossWeight' : '',
    'netWeight' : '',
    'documentStatusId' : '',
    'vesselNo' : '',
    'shippingLineId' : '',
    'shippingTerms' : '',
    'currency' : '',
    'containerNo' : '',
    'totalQty' : '',
    'itemId' : '',
    'brandId' : '',
    'packingId' : '',
    'countId' : '',
    'qty' : '',
    'rate' : ''
  }

  PopulateForm(incomingOrder: IncomingOrderModel) {
    if (incomingOrder) {      
      this.orderBookingForm.patchValue({
        id: incomingOrder.id,  
        blNo : incomingOrder.blNo,
        arrivalPortId  : incomingOrder.arrivalPortId,
        loadingWeekNo : incomingOrder.loadingWeekNo,
        estDateOfLoading : moment(incomingOrder.estDateOfLoading).format('D-MMM-YYYY'),
        estDateOfArrival : moment(incomingOrder.estDateOfArrival).format('D-MMM-YYYY'),
        countryId : incomingOrder.countryId,    
        shipperId : incomingOrder.shipperId,   
        invoiceNo : incomingOrder.invoiceNo,
        noOfContainer : incomingOrder.noOfContainer,
        packingListQty : incomingOrder.packingListQty,
        totalGrossWeight : incomingOrder.totalGrossWeight,
        netWeight : incomingOrder.netWeight,
        documentStatusId : incomingOrder.documentStatusId, 
        vesselNo : incomingOrder.vesselNo,
        shippingLineId : incomingOrder.shipperId,    
        shippingTerms : incomingOrder.shippingTerms,
        paymentTermsAdv : incomingOrder.paymentTermsAdv,
        paymentTermsOnDoc : incomingOrder.paymentTermsOnDoc,
        paymentTermsAfterArr : incomingOrder.paymentTermsAfterArr,
        freight : incomingOrder.freight,
        currency : incomingOrder.currency,
        exchangeRate : incomingOrder.exchangeRate,
        phytoNo : incomingOrder.phytoNo,
        certificateOfOrigin : incomingOrder.certificateOfOrigin,
        nonGmoCertificate : incomingOrder.nonGmoCertificate,
        performaInvoiceNo : incomingOrder.performaInvoiceNo
      });

      this.orderBookingForm.setControl('containerDetails',this.setExistingContainers(incomingOrder.containerDetails))

    }
  }

  setExistingContainers(containers : IncomingOrderContainerDetailModel[]) : FormArray{
    const formArray = new FormArray([]);
    containers.forEach(container => {
      const _fg = this.fb.group({
        containerNo : container.containerNo,
        totalQty : container.totalQty,      
      });
      _fg.setControl('containerItemDetails',this.setExistingContainerItems(container.containerItemDetails))
      formArray.push(_fg);
    });
    return formArray;
  }
  setExistingContainerItems(items : IncomingOrderContainerItemDetailModel[]) : FormArray{
    const formArray = new FormArray([]);
    items.forEach(item => {
      const _fg = this.fb.group({
        itemId : item.itemId,
        brandId : item.brandId,
        packingId : item.packingId,
        countId : item.countId,
        qty : item.qty,
        rate : item.rate,
        selfAllocated : item.selfAllocated,
        allocatedPartyId : item.allocatedPartyId
      });      

      formArray.push(_fg);
    });
    return formArray;
  }

  getItemBrands(containerIndex,containerItemIndex){
    let _itemId = (<FormGroup>this.containerItems(containerIndex).at(containerItemIndex)).get('itemId').value;    
    if(_itemId){
      return this.itemList.filter(i=>i.id == _itemId)[0].itemBrandList;
    }    
  }
  getItemPackings(containerIndex,containerItemIndex){
    let _itemId = (<FormGroup>this.containerItems(containerIndex).at(containerItemIndex)).get('itemId').value;
    if(_itemId){
      return this.itemList.filter(i=>i.id == _itemId)[0].itemPackingList;
    }
  }
  getItemCounts(containerIndex,containerItemIndex){
    let _itemId = (<FormGroup>this.containerItems(containerIndex).at(containerItemIndex)).get('itemId').value;
    if(_itemId){
      return this.itemList.filter(i=>i.id == _itemId)[0].itemCountList;
    }
  }
  
  addContainerDetailsFormGroup() : FormGroup{
    return this.fb.group({
      containerNo : ['',Validators.required],
      totalQty : ['',Validators.required],
      containerItemDetails : this.fb.array([
        this.addContainerItemDetailsFormGroup()
      ])
    });
  }

  addContainerItemDetailsFormGroup() : FormGroup{
    return this.fb.group({
      itemId : ['',Validators.required],
      brandId : ['',Validators.required],
      packingId : ['',Validators.required],
      countId : ['',Validators.required],
      qty : ['',Validators.required],
      rate : ['',Validators.required],
      selfAllocated : [''],
      allocatedPartyId : ['']
    });
  }
  
  addContainerDetails() : void{
    (<FormArray>this.orderBookingForm.get('containerDetails')).push(this.addContainerDetailsFormGroup());
  }
  addContainerItemDetails(containerIndex : number) : void{
    let _containerFg = <FormGroup>((<FormArray>this.orderBookingForm.get('containerDetails')).at(containerIndex));
    (<FormArray>_containerFg.get('containerItemDetails')).push(this.addContainerItemDetailsFormGroup());
  }


  deleteContainerDetails(containerIndex){
    this.containers().removeAt(containerIndex);    
  }
  deleteContainerItemDetails(containerIndex,containerItemIndex){
    this.containerItems(containerIndex).removeAt(containerItemIndex);    
  }

  containers(){
    return this.orderBookingForm.get("containerDetails") as FormArray
  }
  containerItems(containerIndex){
    return this.containers().at(containerIndex).get("containerItemDetails") as FormArray
  }

  onSubmit() {
    console.log(this.orderBookingForm);
    if (!this.orderBookingForm.valid) {
      this.alertMessage = "Please enter valid details";      
      return;
    }

    

    let formValue = this.orderBookingForm.getRawValue();
    let incomingOrderData: IncomingOrderModel = {
      ...this.incomingOrder,
      ...formValue
    };
    console.log('incomingOrderData : ', incomingOrderData);

    if (!this.editMode) {   
      this.spinner.show();
      incomingOrderData.id = 0;
      this.stockService.createIncomingOrder(incomingOrderData).subscribe(res=>{
        console.log('res : ',res);
        if(res){
          if(res['statusCode'] == 200){
            this.orderBookingForm.reset();
          }
          this.alertMessage = res['statusMessage']          
        }
        this.spinner.hide();
      });
    }
    else {
      this.spinner.show();
      this.stockService.updateIncomingOrder(incomingOrderData).subscribe(res=>{
        console.log('res : ',res);
        this.spinner.hide();
      });
    }
  }
  closeAlert() {
    this.alertMessage = null;    
  }

  logValidationErrors(group : FormGroup = this.orderBookingForm) : void {
    console.log(this.orderBookingForm);
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else if(abstractControl instanceof FormArray){
        abstractControl.controls.forEach(control => {
          if(control instanceof FormGroup){
            this.logValidationErrors(control);
          }
        });              
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid &&
          (abstractControl.touched || abstractControl.dirty)){
            const messages = this.validationMessages[key];

            for(const errorKey in abstractControl.errors){
              if(errorKey){         
                       console.log('errorKey : ',errorKey);
                       console.log('messageerrorKey : ',messages);
                       
                if(messages){
                  this.formErrors[key] += messages[errorKey] + ' ';                
                }                
              }
            }
          }
      }
    });
  }

  logValidationErrorsOnSubmit(group : FormGroup = this.orderBookingForm) : void {
    this.errorAlertMessage ='';
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else if(abstractControl instanceof FormArray){
        abstractControl.controls.forEach(control => {
          if(control instanceof FormGroup){
            this.logValidationErrors(control);
          }
        });              
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid ){
            const messages = this.validationMessages[key];
            for(const errorKey in abstractControl.errors){
              if(errorKey){
                abstractControl.markAsTouched({ onlySelf: true });
                if(messages[errorKey]){
                  this.formErrors[key] += messages[errorKey] + ' ';                
                }
                if(this.errorAlertMessage == ''){
                  this.errorAlertMessage = messages[errorKey];
                }
              }
            }
          }
      }
    });
  }
}

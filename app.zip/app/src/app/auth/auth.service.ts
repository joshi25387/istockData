import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthorityModel, User, UserCreationModel, UserDetail, UserRoleModel } from './models/user.model';
import { of, BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({'providedIn' : 'root'})
export class AuthService {

    constructor(private http : HttpClient){}


    userDetail = new BehaviorSubject<UserDetail>({
        isLoaded : false,        
        name : "",
        role : ""
    })

    user : User = {
        userId : 'SS0020',
        userName : 'SS0020',
        role : 'Admin',
        token : 'abcd123456'
    }

    setUserDetail(userDet : UserDetail){        
        this.userDetail.next(userDet);
    }

    authenticateUser(userId : string, password : string){         
        
        //return of(this.user);      
        return this.http.post<User>(environment.apiUrl + 'Account/Login',{userName : userId,password});
    }

    getRoles(){
        return this.http.get<UserRoleModel[]>(environment.apiUrl + 'Account/GetRoles').pipe(map(res => res['roleList']));
    }

    getUserDetail(userId : string){
        return this.http.get<UserDetail>(environment.apiUrl + 'Account/GetUserDetail/' + userId);
    }

    createUser(userDetail : UserCreationModel){
        return this.http.post(environment.apiUrl  + 'Account/CreateUser',userDetail);
    }

    updateUser(userDetail : UserCreationModel){
        return this.http.post(environment.apiUrl  + 'Account/UpdateUser',userDetail);
    }

    getAuthority(){
        return this.http.get<AuthorityModel[]>(environment.apiUrl + 'User/GetUserAuthority')
                                            .pipe(map(x=>x['authorityDetails']));
    }
}
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Routes, RouterModule } from '@angular/router';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { EntityDataModule } from '@ngrx/data';
import {metaReducers, reducers} from './reducers';
import { AuthGuard } from './auth/auth.guard';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from '../environments/environment';

import * as fromAuth from './auth/reducers';
import { AuthEffects } from './auth/auth.effects';

import { AuthInterceptor } from './interceptors/auth.interceptor';

import { NgxSpinnerModule } from "ngx-spinner";
import { AgmCoreModule } from '@agm/core';
import { SharedModule } from './shared/shared.module';



const appRoutes : Routes = [
  { path : "", pathMatch : "full" , redirectTo : "login" },
  
  { path : "login" , loadChildren : () => import('./auth/auth.module').then(m => m.AuthModule) },
  { path : "user" , 
    loadChildren : () => import('./auth/auth.module').then(m => m.AuthModule),
    canActivate : [AuthGuard] 
  },
  { path : "clients" , 
    loadChildren : () => import('./clients/client.module').then(m => m.ClientsModule),
    canActivate : [AuthGuard]
   },
   { path : "agents" , 
    loadChildren : () => import('./agents/agent.module').then(m => m.AgentModule),
    canActivate : [AuthGuard]
   },
   { path : "stores" , 
    loadChildren : () => import('./stores/store.module').then(m => m.StoresModule),
    canActivate : [AuthGuard]
   },
   
   { path : "stock" , 
    loadChildren : () => import('./stock/stock.module').then(m => m.StockModule),
    canActivate : [AuthGuard]
   }
];



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SideNavComponent
  ],
  imports: [   
    
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,   
    SharedModule,
    AppRoutingModule,    
    RouterModule.forRoot(appRoutes),
    StoreModule.forRoot(reducers, {metaReducers,runtimeChecks:{
      strictStateImmutability : true,
      
    }}),
    StoreModule.forFeature(fromAuth.authFeatureKey,
      fromAuth.authReducer),
    EffectsModule.forRoot([]),
    EffectsModule.forFeature([
        AuthEffects
    ]),
    EntityDataModule.forRoot({}),
    StoreDevtoolsModule.instrument({ maxAge: 25, logOnly: environment.production }),
    NgxSpinnerModule,
    AgmCoreModule.forRoot({
      // apiKey: 'AIzaSyDGfJVCbFk58qp-dYjGbkZYMCeRIG6odMg',
     // apiKey: 'AIzaSyDZNjew5t-gBKa5ddbumJN5ai8vm0O40kE',
      apiKey: 'AIzaSyAZxwzLAaV7jtqF4Gq9tMU24jRNzORCrJM',
      libraries: ['places']
    })
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }, 
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

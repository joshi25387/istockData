import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { UserDetail } from 'src/app/auth/models/user.model';
import { ItemModel } from '../model/master-data.model';
import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { MasterDataService } from '../services/master-data.service';
import { AuthService } from 'src/app/auth/auth.service';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';

@Component({
  selector: 'item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css']
})
export class ItemListComponent implements OnInit {

  confirmMessage: string = null;  

  itemList$: Observable<ItemModel[]>;
  filter = new FormControl('');

  arrivalPortToUpdate: number = -1;

  showAckDialog : boolean = false;
  
  alertMessage:string =null;
  frameworkComponents: any;

  itemIdToDelete : number = -1;

  orderStatusFilter : string;
  storeIdFilter : number;
  userDetail : UserDetail;

  
  columnDefs = [    
    {  headerName: 'Id',field: 'id', sortable: true, filter: true,resizable:true,width:110,pinned:'left'},        
    { headerName: 'Item Name', field: 'itemName', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: 'Item Group', field: 'itemGroupName', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: 'Created Date', field: 'createdDate', sortable : true, filter : true,width : 180 ,
          resizable : true,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
      },  
    { headerName: 'Created By', field: 'createdBy', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: '', cellRenderer: 'editDeleteButtonRenderer', 
    cellRendererParams: {
        onEditClick: this.editItem.bind(this),
        onDeleteClick: this.deleteItem.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private masterDataService : MasterDataService,
    private authService : AuthService) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }

    this.authService.userDetail.subscribe(userDet => {      
      this.userDetail = userDet
    });
    this.itemList$ = this.masterDataService.getItemList();
 
        
  }

  onConfirmOk(){
    if(this.itemIdToDelete > -1){

      this.masterDataService.deleteItem(this.itemIdToDelete).subscribe(res=>{
        if(res){
          this.alertMessage = res['statusMessage'];
          this.itemList$ = this.masterDataService.getItemList();
        }
      });
    }
    this.confirmMessage = null;
  }

  onConfirmCancel(){
    this.itemIdToDelete = -1;
    this.confirmMessage = null;
  }

  editItem(itemRow){
    let itemId : number = +itemRow.rowData.id;
    this.router.navigate([itemId,'edit'],{relativeTo:this.route});
  }

  deleteItem(itemRow){
    this.itemIdToDelete = +itemRow.rowData.id;
    this.confirmMessage = "Are you sure to delete item " + itemRow.rowData.itemName + " ?";
  }


  
  closeAlert() {
    this.alertMessage = null;    
  }

}

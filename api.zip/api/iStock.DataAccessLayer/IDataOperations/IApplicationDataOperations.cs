﻿using iStock.Models.DALModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace iStock.DataAccessLayer.IDataOperations
{
    public interface IApplicationDataOperations
    {
        Task<string> GetApplicationVersion();        
    }
}

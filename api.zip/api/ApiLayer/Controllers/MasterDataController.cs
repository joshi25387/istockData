﻿using iStock.CrudBusinessLayer.Interfaces;
using iStock.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace iStock.ApiLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterDataController : ControllerBase
    {
        private readonly IMasterDataCrudLogics masterDataCrudOps;

        public MasterDataController(IMasterDataCrudLogics masterDataCrudOps)
        {
            this.masterDataCrudOps = masterDataCrudOps;
        }        

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetArrivalPortMaster")]
        public async Task<IActionResult> GetArrivalPortMaster()
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetArrivalPortMaster(requestor);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetArrivalPortById/{id}")]
        public async Task<IActionResult> GetArrivalPortById(int id)
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetArrivalPortById(requestor,id);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("CreateArrivalPort")]
        public async Task<IActionResult> CreateArrivalPort([FromBody] ArrivalPortMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.CreateArrivalPort(requestor,model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("UpdateArrivalPort")]
        public async Task<IActionResult> UpdateArrivalPort([FromBody]ArrivalPortMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.UpdateArrivalPort(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeleteArrivalPort/{id}")]
        public async Task<IActionResult> DeleteArrivalPort(int id)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.DeleteArrivalPort(requestor, id);
        }



        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetCountryMaster")]
        public async Task<IActionResult> GetCountryMaster()
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetCountryMaster(requestor);
        }


        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetStateMaster")]
        public async Task<IActionResult> GetStateMaster()
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetStateMaster(requestor);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetCityMaster/{id}")]
        public async Task<IActionResult> GetCityMaster(int id)
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetCityMaster(requestor,id);
        }



        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetCountryById/{id}")]
        public async Task<IActionResult> GetCountryById(int id)
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetCountryById(requestor,id);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("CreateCountry")]
        public async Task<IActionResult> CreateCountry([FromBody]CountryMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.CreateCountry(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("UpdateCountry")]
        public async Task<IActionResult> UpdateCountry([FromBody]CountryMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.UpdateCountry(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeleteCountry/{id}")]
        public async Task<IActionResult> DeleteCountry(int id)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.DeleteCountry(requestor, id);
        }



        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetDocumentStatusMaster")]
        public async Task<IActionResult> GetDocumentStatusMaster()
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetDocumentStatusMaster(requestor);
        }
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetItemMaster")]

        public async Task<IActionResult> GetItemMaster()
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetItemMaster(requestor);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetItemById/{id}")]
        public async Task<IActionResult> GetItemById(int id)
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetItemById(requestor,id);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetPartyGroupMaster")]
        public async Task<IActionResult> GetPartyGroupMaster()
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetPartyGroupMaster(requestor);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetPartyGroupById/{id}")]
        public async Task<IActionResult> GetPartyGroupById(int id)
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetPartyGroupById(requestor,id);
        }


        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetPartyMaster")]
        public async Task<IActionResult> GetPartyMaster()
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetPartyMaster(requestor);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetPartyById/{id}")]
        public async Task<IActionResult> GetPartyById(int id)
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetPartyById(requestor,id);
        }


        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("CreatePartyGroup")]
        public async Task<IActionResult> CreatePartyGroup([FromBody]PartyGroupMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.CreatePartyGroup(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("UpdatePartyGroup")]
        public async Task<IActionResult> UpdatePartyGroup([FromBody] PartyGroupMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.UpdatePartyGroup(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeletePartyGroup/{id}")]
        public async Task<IActionResult> DeletePartyGroup(int id)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.DeletePartyGroup(requestor, id);
        }


        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("CreateParty")]
        public async Task<IActionResult> CreateParty([FromBody] PartyMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.CreateParty(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("UpdateParty")]
        public async Task<IActionResult> UpdateParty([FromBody] PartyMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.UpdateParty(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeleteParty/{id}")]
        public async Task<IActionResult> DeleteParty( int id) 
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.DeleteParty(requestor, id);
        }


        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("CreateDocumentStatus")]
        public async Task<IActionResult> CreateDocumentStatus([FromBody] DocumentStatusMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.CreateDocumentStatus(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("UpdateDocumentStatus")]
        public async Task<IActionResult> UpdateDocumentStatus([FromBody] DocumentStatusMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.UpdateDocumentStatus(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeleteDocumentStatus/{id}")]
        public async Task<IActionResult> DeleteDocumentStatus(int id)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.DeleteDocumentStatus(requestor, id);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("CreateItem")]
        public async Task<IActionResult> CreateItem([FromBody] ItemMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.CreateItem(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("UpdateItem")]
        public async Task<IActionResult> UpdateItem([FromBody] ItemMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.UpdateItem(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeleteItem/{id}")]
        public async Task<IActionResult> DeleteItem(int id)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.DeleteItem(requestor, id);
        }


        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("CreateItemGroup")]
        public async Task<IActionResult> CreateItemGroup([FromBody] ItemGroupMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.CreateItemGroup(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("UpdateItemGroup")]
        public async Task<IActionResult> UpdateItemGroup([FromBody] ItemGroupMasterModel model)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.UpdateItemGroup(requestor, model);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeleteItemGroup/{id}")]
        public async Task<IActionResult> DeleteItemGroup(int id)
        {
            var requestor = string.Empty;
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.DeleteItemGroup(requestor, id);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetItemGroupById/{id}")]
        public async Task<IActionResult> GetItemGroupById(int id)
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetItemGroupById(requestor, id);
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetItemGroupMaster")]

        public async Task<IActionResult> GetItemGroupMaster()
        {
            var requestor = "";
            var identity = User.Identity as ClaimsIdentity;
            if (identity != null && identity.Claims.Count() > 0)
            {
                var userIdClaim = identity.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
                if (userIdClaim != null && !string.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    requestor = userIdClaim.Value;
                }
            }
            return await masterDataCrudOps.GetItemGroupMaster(requestor);
        }

    }
}

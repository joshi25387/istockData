﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace iStock.Models
{
    public class UserDetailModel
    {
        public bool IsLoaded { get; set; }
        public string Name { get; set; }       
        public string Role { get; set; }
        public string UserCode { get; set; }        
    }

    public class UserDetailRequestModel
    {
        public string Latitude { get; set; }

        public string Longitude { get; set; }

        public string Address { get; set; }
        public string deviceId { get; set; }
        public string firebaseId { get; set; }

    }

    public class UserLocationDetailModel
    {
        public string geolat { get; set; }
        public string geolong { get; set; }

        public string resolvedAddress { get; set; }
        public bool online { get; set; }

        public string infoSource { get; set; }

        public string deviceDate { get; set; }
        public decimal? distanceFromStore { get; set; }
    }

    

    /*
     * added by richa on 31july20
     */



    public class CustomerSupportModel
    {
        public string PhoneNo { get; set; }
        public string EmailId { get; set; }
    }

    public class FTPDetailModel
    {
        public string FTPIP { get; set; }
        public string FTPUser { get; set; }
        public string FTPPassword { get; set; }
        public int? FTPPort { get; set; }
        public string FTPDirectory { get; set; }
    }

    public class AgentDetailRequestModel
    {
        public string deviceId { get; set; }

        public string firebaseId { get; set; }



        public UserLocationDetailModel userLocDetail { get; set; }


    }
    public class AgentLocationModel
    {
        public string deviceId { get; set; }
        public List<UserLocationDetailModel> userLocDetail { get; set; }

    }


    public class FieldAgentDetailModel
    {
        public string UserId { get; set; }
        public string Name { get; set; }       
        public bool LogEnable { get; set; }        
        public string Role { get; set; }
        public string Circle { get; set; }        
        public FTPDetailModel FTPDetail { get; set; }
        public int MinimumDocuments { get; set; }
        public List<DocumentTypeModel> DocumentTypeDetails { get; set; }
    }
    public class DocumentTypeModel
    {
        public int Id { get; set; }
        public string DocumentType { get; set; }
        public string ShowType { get; set; }
    }
}

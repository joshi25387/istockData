import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule } from '@angular/forms';
import { ArrivalPortListComponent } from './arrival-port-list/arrival-port-list.component';
import { ArrivalPortComponent } from './arrival-port/arrival-port.component';
import { CountryListComponent } from './country-list/country-list.component';
import { CountryComponent } from './country/country.component';
import { PartyListComponent } from './party-list/party-list.component';
import { PartyComponent } from './party/party.component';
import { PartyGroupListComponent } from './party-group-list/party-group-list.component';
import { PartyGroupComponent } from './party-group/party-group.component';
import { ItemListComponent } from './item-list/item-list.component';
import { ItemComponent } from './item/item.component';
import { HomeComponent } from './home/home.component';
import { IncomingOrderComponent } from './incoming-order/incoming-order.component';
import { IncomingOrderListComponent } from './incoming-order-list/incoming-order-list.component';
import { ItemGroupComponent } from './item-group/item-group.component';
import { ItemGroupListComponent } from './item-group-list/item-group-list.component';
import { PerformaInvoiceComponent } from './performa-invoice/performa-invoice.component';
import { InwardingComponent } from './inwarding/inwarding.component';
import { PerformaInvoiceListComponent } from './performa-invoice-list/performa-invoice-list.component';


const stockRoutes: Routes = [
  {
    path: '',
    component: HomeComponent,    
  },
  {
    path: 'home',
    component: HomeComponent,    
  },
  {
    path: 'arrival-port',
    component: ArrivalPortListComponent,    
  },
  {
    path: 'arrival-port/new',
    component: ArrivalPortComponent,    
  },
  {
    path : "arrival-port/:id/edit",
    component: ArrivalPortComponent,    
  },
  {
    path: 'country',
    component: CountryListComponent,    
  },
  {
    path: 'country/new',
    component: CountryComponent,    
  },
  {
    path : "country/:id/edit",
    component: CountryComponent,    
  },
  {
    path: 'party-group',
    component: PartyGroupListComponent,    
  },
  {
    path: 'party-group/new',
    component: PartyGroupComponent,    
  },
  {
    path : "party-group/:id/edit",
    component: PartyGroupComponent,    
  },
  {
    path: 'party',
    component: PartyListComponent,    
  },
  {
    path: 'party/new',
    component: PartyComponent,    
  },
  {
    path : "party/:id/edit",
    component: PartyComponent,    
  },
  {
    path: 'item-group',
    component: ItemGroupListComponent,    
  },
  {
    path: 'item-group/new',
    component: ItemGroupComponent,    
  },
  {
    path : "item-group/:id/edit",
    component: ItemGroupComponent,    
  },
  {
    path: 'item',
    component: ItemListComponent,    
  },
  {
    path: 'item/new',
    component: ItemComponent,    
  },
  {
    path : "item/:id/edit",
    component: ItemComponent,    
  },
  {
    path: 'incoming-order',
    component: IncomingOrderListComponent,    
  },
  {
    path: 'incoming-order/new',
    component: IncomingOrderComponent,    
  },
  {
    path : "incoming-order/:id/edit",
    component: IncomingOrderComponent,    
  },
  {
    path: 'performa-invoice',
    component: PerformaInvoiceListComponent,    
  },
  {
    path: 'performa-invoice/new',
    component: PerformaInvoiceComponent,    
  },
  {
    path : "performa-invoice/:id/edit",
    component: PerformaInvoiceComponent,    
  }
];

@NgModule({
  declarations: [HomeComponent,ArrivalPortListComponent, ArrivalPortComponent, CountryListComponent, CountryComponent, PartyListComponent, PartyComponent, PartyGroupListComponent, PartyGroupComponent, ItemListComponent, ItemComponent, IncomingOrderComponent, IncomingOrderListComponent, ItemGroupComponent, ItemGroupListComponent, PerformaInvoiceComponent, InwardingComponent, PerformaInvoiceListComponent],
  imports: [
    
    SharedModule,
    RouterModule.forChild(stockRoutes),
    NgSelectModule,
    FormsModule    
  ],
  providers: [
    
  ]
})
export class StockModule { }
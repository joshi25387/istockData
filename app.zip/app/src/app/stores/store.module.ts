import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { StoreListComponent } from './store-list/store-list.component';
import { StoreComponent } from './store/store.component';
import { StoresResolver } from './services/stores.resolver';


const storeRoutes : Routes = [
    {
        path : "" , 
        component : StoreListComponent,
        resolve : {
            stores : StoresResolver
           }
    },
    {
        path : "new",
        component : StoreComponent
    },
    {
        path : ":id/edit",
        component : StoreComponent
    }
];


@NgModule({
   imports : [
        SharedModule,
        RouterModule.forChild(storeRoutes)
   ],
   providers : [    
        StoresResolver
   ],
   declarations: [StoreListComponent, StoreComponent]
})
export class StoresModule{
    
}
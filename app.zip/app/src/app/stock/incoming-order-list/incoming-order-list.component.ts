import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { UserDetail } from 'src/app/auth/models/user.model';
import { IncomingOrderModel } from '../model/order.model';
import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { StockService } from '../services/stock.service';
import { AuthService } from 'src/app/auth/auth.service';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';

@Component({
  selector: 'incoming-order-list',
  templateUrl: './incoming-order-list.component.html',
  styleUrls: ['./incoming-order-list.component.css']
})
export class IncomingOrderListComponent implements OnInit {

  confirmMessage: string = null;  

  incomingOrderList$: Observable<IncomingOrderModel[]>;
  filter = new FormControl('');

  incomingOrderToUpdate: number = -1;

  showAckDialog : boolean = false;
  
  alertMessage:string =null;
  frameworkComponents: any;

  incomingOrderIdToDelete : number = -1;

  orderStatusFilter : string;
  storeIdFilter : number;
  userDetail : UserDetail;

  
  columnDefs = [    
    {  headerName: 'Id',field: 'id', sortable: true, filter: true,resizable:true,width:110,pinned:'left'},        
    { headerName: 'B.L. No.', field: 'blNo', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: 'Created Date', field: 'createdDate', sortable : true, filter : true,width : 180 ,
          resizable : true,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
      },  
    { headerName: 'Created By', field: 'createdBy', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: '', cellRenderer: 'editDeleteButtonRenderer', 
    cellRendererParams: {
        onEditClick: this.editIncomingOrder.bind(this),
        onDeleteClick: this.deleteIncomingOrder.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private stockService : StockService,
    private authService : AuthService) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }

    this.authService.userDetail.subscribe(userDet => {      
      this.userDetail = userDet
    });
    this.incomingOrderList$ = this.stockService.getIncomingOrderList();
 
        
  }

  onConfirmOk(){
    if(this.incomingOrderIdToDelete > -1){

      this.stockService.deleteIncomingOrder(this.incomingOrderIdToDelete).subscribe(res=>{
        if(res){
          this.alertMessage = res['statusMessage'];
          this.incomingOrderList$ = this.stockService.getIncomingOrderList();
        }
      });
    }
    this.confirmMessage = null;
  }

  onConfirmCancel(){
    this.incomingOrderIdToDelete = -1;
    this.confirmMessage = null;
  }

  editIncomingOrder(incomingOrderRow){
    let incomingOrderId : number = +incomingOrderRow.rowData.id;
    this.router.navigate([incomingOrderId,'edit'],{relativeTo:this.route});
  }

  deleteIncomingOrder(incomingOrderRow){
    this.incomingOrderIdToDelete = +incomingOrderRow.rowData.id;
    this.confirmMessage = "Are you sure to delete B.L. No. " + incomingOrderRow.rowData.blNo + " ?";
  }


  
  closeAlert() {
    this.alertMessage = null;    
  }

}

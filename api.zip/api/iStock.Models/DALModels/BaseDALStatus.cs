﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace iStock.Models.DALModels
{
    public class BaseDALStatus
    {
        public HttpStatusCode HttpStatus { get; set; }
        public string Message { get; set; }
        public int AdditionalStatusCode { get; set; }
    }
}

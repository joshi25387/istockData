import { Address } from 'src/app/shared/models/address.model';
import { LocationCoordinate } from 'src/app/shared/models/location.model';
import { KycDocument } from 'src/app/shared/models/kycDocument.model';
import { BankDetail } from 'src/app/shared/models/bankDetail.model';
import { AgentStoreMapDetails } from 'src/app/agents/models/agentStoreMapDet';

export interface Agent{
    id : number,
    agentName : string,
    mobile : number,
    email : string,
    permanentAddress : Address,
    currentAddress : Address,
    vehicleType : number,
    vehicleNumber : string,
    drivingLicenseNo : string,
    aadharNo : string,
    panNumber : string,
    geolocation : LocationCoordinate,    
    kycDocuments : KycDocument[],
    bankDetails : BankDetail[],
    createdBy? : string;
    createdDate? : Date;
    updatedBy? : string;
    updatedDate? : Date;
    isActive? : boolean;
    agentStoreMapping : AgentStoreMapDetails[],
    imeiDetails: string[]
}
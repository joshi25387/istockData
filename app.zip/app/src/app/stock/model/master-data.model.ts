export interface ArrivalPortModel{
    id? : number,
    city : string,
    createdBy? : string,
    createdDate? : Date
}

export interface CountryModel{
    id? : number,
    country : string,
    createdBy? : string,
    createdDate? : Date
}

export interface StateModel{
    id? : number,
    stateName : string,
    createdBy? : string,
    createdDate? : Date
}

export interface CityModel{
    id? : number,
    stateId : number,
    stateName? : string,
    cityName : string,
    createdBy? : string,
    createdDate? : Date
}

export interface PartyGroupModel{
    id? : number,
    groupName : string,
    createdBy? : string,
    createdDate? : Date
}

export interface PartyModel{
    id? :  number,
    partyName : string,
    partyGroupId : number,
    partyGroupName? : string,
    partyAddress : string,
    stateId : number,
    stateName? : string,
    cityId : number,
    cityName : string,
    pincode? : string,
    panNo : string,
    creditLimit : number,
    paymentTerms : number,
    contactNo : string,
    email : string,
    createdBy? : string,
    createdDate? : Date    
}

export interface ItemGroupModel{
    id? : number,
    itemGroupName : string,
    createdBy? : string,
    createdDate? : Date
}

export interface ItemModel{
    id? : number,
    itemGroupId : number,
    itemGroupName? : string,
    itemName : string,    
    itemBrandList : ItemBrandModel[],
    itemPackingList : ItemPackingModel[],
    itemCountList : ItemCountModel[],
    createdBy? : string,
    createdDate? : Date
}

export interface ItemBrandModel{
    id? : number,
    itemBrandName : string
}
export interface ItemPackingModel{
    id? : number,
    itemPacking : string
}
export interface ItemCountModel{
    id? : number,
    itemCount : string
}


export interface DocumentStatusModel{
    id? : number,
    docStatus : string
}


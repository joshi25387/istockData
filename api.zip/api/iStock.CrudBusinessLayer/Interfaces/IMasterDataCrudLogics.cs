﻿using iStock.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace iStock.CrudBusinessLayer.Interfaces
{
    public interface IMasterDataCrudLogics
    {
        Task<IActionResult> GetArrivalPortMaster(string requestor);
        Task<IActionResult> GetArrivalPortById(string requestor,int id);
        Task<IActionResult> CreateArrivalPort(string requestor, ArrivalPortMasterModel model);
        Task<IActionResult> UpdateArrivalPort(string requestor, ArrivalPortMasterModel model);
        Task<IActionResult> DeleteArrivalPort(string requestor, int id);


        Task<IActionResult> GetCountryMaster(string requestor);

        Task<IActionResult> GetStateMaster(string requestor);
        Task<IActionResult> GetCityMaster(string requestor,int stateId);


        Task<IActionResult> GetCountryById(string requestor,int id);
        Task<IActionResult> CreateCountry(string requestor, CountryMasterModel model);
        Task<IActionResult> UpdateCountry(string requestor, CountryMasterModel model);
        Task<IActionResult> DeleteCountry(string requestor, int id);



        Task<IActionResult> GetPartyGroupMaster(string requestor);
        Task<IActionResult> GetPartyGroupById(string requestor,int id);
        Task<IActionResult> CreatePartyGroup(string requestor, PartyGroupMasterModel model);
        Task<IActionResult> UpdatePartyGroup(string requestor, PartyGroupMasterModel model);
        Task<IActionResult> DeletePartyGroup(string requestor, int id);



        Task<IActionResult> GetPartyMaster(string requestor);
        Task<IActionResult> GetPartyById(string requestor,int id);
        Task<IActionResult> CreateParty(string requestor, PartyMasterModel model);
        Task<IActionResult> UpdateParty(string requestor, PartyMasterModel model);
        Task<IActionResult> DeleteParty(string requestor, int id);        


        Task<IActionResult> GetDocumentStatusMaster(string requestor);
        Task<IActionResult> CreateDocumentStatus(string requestor, DocumentStatusMasterModel model);
        Task<IActionResult> UpdateDocumentStatus(string requestor, DocumentStatusMasterModel model);
        Task<IActionResult> DeleteDocumentStatus(string requestor, int id);



        Task<IActionResult> GetItemMaster(string requestor);
        Task<IActionResult> GetItemById(string requestor,int id);
        Task<IActionResult> CreateItem(string requestor, ItemMasterModel model);
        Task<IActionResult> UpdateItem(string requestor, ItemMasterModel model);
        Task<IActionResult> DeleteItem(string requestor, int id);


        Task<IActionResult> GetItemGroupMaster(string requestor);
        Task<IActionResult> GetItemGroupById(string requestor, int id);
        Task<IActionResult> CreateItemGroup(string requestor, ItemGroupMasterModel model);
        Task<IActionResult> UpdateItemGroup(string requestor, ItemGroupMasterModel model);
        Task<IActionResult> DeleteItemGroup(string requestor, int id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.ResponseModels
{
    public class UserDetailResponseModel : BaseResponseModel
    {
        public List<UserDetailModel> UserDetails { get; set; }
    }
}

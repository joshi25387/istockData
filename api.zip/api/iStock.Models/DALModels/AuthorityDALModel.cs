﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models.DALModels
{
    public class AuthorityDALModel : BaseDALStatus
    {
        public List<AuthorityModel> AuthorityDetails { get; set; }
    }
}

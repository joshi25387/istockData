﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class IncomingOrderDetails
    {
        public IncomingOrderDetails()
        {
            IncomingOrderContainerDetails = new HashSet<IncomingOrderContainerDetails>();
        }

        public int Id { get; set; }
        public string Blno { get; set; }
        public int? ArrivalPortId { get; set; }
        public int? LoadingWeekNo { get; set; }
        public DateTime? EstDateOfLoading { get; set; }
        public DateTime? EstDateOfArrival { get; set; }
        public DateTime? ActualArrivalDate { get; set; }
        public int? CountryId { get; set; }
        public int? ShipperId { get; set; }
        public string InvoiceNo { get; set; }
        public int? NoOfContainer { get; set; }
        public int? PackingListQty { get; set; }
        public decimal? TotalGrossWeight { get; set; }
        public decimal? NetWeight { get; set; }
        public int? DocumentStatusId { get; set; }
        public string VesselNo { get; set; }
        public int? ShippingLineId { get; set; }
        public string ShippingTerms { get; set; }
        public string PaymentTermsAdv { get; set; }
        public string PaymentTermsOnDoc { get; set; }
        public string PaymentTermsAfterArr { get; set; }
        public decimal? Freight { get; set; }
        public string Currency { get; set; }
        public decimal? ExchangeRate { get; set; }
        public string PhytoNo { get; set; }
        public string CertificateOfOrigin { get; set; }
        public string NonGmoCertificate { get; set; }
        public string PerformaInvoiceNo { get; set; }
        public decimal? ConversionRate { get; set; }
        public decimal? CustomDuty { get; set; }
        public decimal? CleaningExpense { get; set; }
        public decimal? OtherExpenses { get; set; }
        public bool? InwardingDone { get; set; }
        public string InwardingBy { get; set; }
        public DateTime? InwardingDate { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual ArrivalPortMaster ArrivalPort { get; set; }
        public virtual CountryMaster Country { get; set; }
        public virtual DocumentStatusMaster DocumentStatus { get; set; }
        public virtual PartyMaster Shipper { get; set; }
        public virtual PartyMaster ShippingLine { get; set; }
        public virtual ICollection<IncomingOrderContainerDetails> IncomingOrderContainerDetails { get; set; }
    }
}

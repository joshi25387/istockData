﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class AuditTrailLog
    {
        public int Id { get; set; }
        public string EntityName { get; set; }
        public string PropertyName { get; set; }
        public string PrimaryKeyValue { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
        public string ChangedBy { get; set; }
        public DateTime? ChangedDate { get; set; }
        public string ActionType { get; set; }
    }
}

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ClientEntityService } from '../services/client-entity.service';
import { map, tap } from 'rxjs/operators';
import { ClientModel } from '../models/client.model';
import { BankDetail } from 'src/app/shared/models/bankDetail.model';
import { KycDocument } from 'src/app/shared/models/kycDocument.model';
import { NgxSpinnerService } from "ngx-spinner";
import { AddressComponent } from 'src/app/shared/address/address.component';
import { BankDetailComponent } from 'src/app/shared/bank-detail/bank-detail.component';
import { KycDocumentComponent } from 'src/app/shared/kyc-document/kyc-document.component';
import { SharedService } from 'src/app/shared/service/shared.service';

@Component({
  selector: 'client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  clientRegForm: FormGroup;
  alertMessage: string = null;
  editMode: boolean = false;

  buttonText: string = "Submit";
  totalClientCount: number = -1;


  client  :ClientModel;

  constructor(private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private clientEntityService: ClientEntityService,
    private spinner : NgxSpinnerService,
    private sharedService : SharedService) { }

  ngOnInit(): void {
    this.clientRegForm = this.fb.group({
      id: [''],
      companyName: ['', Validators.required],      
      contactName: ['', [Validators.required, Validators.pattern("[a-zA-Z ]*")]],
      phone: ['', [Validators.required, Validators.pattern("^(?:(?:\\+|0{0,2})91(\\s*[\\-]\\s*)?|[0]?)?[6789]\\d{9}$")]],
      email: ['', [Validators.required, Validators.email]],
      regAddress: []      
    });


    this.route.params.subscribe(
      (params: Params) => {
        this.editMode = !!params['id'];
        this.buttonText = this.editMode ? "Update" : "Submit";
        if (this.editMode) {

          const clientIdToEdit = +params['id'];

          if (!this.clientEntityService.loaded$) {
            this.clientEntityService.getByKey(clientIdToEdit).subscribe(client => {
              this.PopulateForm(client);
            });
          }
          else {
            this.clientEntityService.entities$.pipe(
              map(clients => clients.find(client => client.id == clientIdToEdit))
            ).subscribe(client => {
              this.PopulateForm(client);
            });
          }

        }
      }
    );

    this.clientEntityService.count$.subscribe(count => {
      this.totalClientCount = count;
    })
  }

  get f() { return this.clientRegForm.controls; }

  PopulateForm(client: ClientModel) {

    if(client){
      console.log('PopulateForm client : ',client);

      this.clientRegForm.patchValue({
        id: client.id,
        companyName: client.companyName,        
        contactName: client.contactName,
        phone: client.phone,
        email: client.email
      });
  
  
      (<FormGroup>this.clientRegForm.get('regAddress')).patchValue({
        address1: client.regAddress.address1,
        address2: client.regAddress.address2,        
        pincode: client.regAddress.pincode,
        state :client.regAddress.state,
        city :client.regAddress.city,
      });  
    }
  }
  
  SetFormToInitialValues(){
    this.clientRegForm.patchValue({
      id: '',
      companyName: '',
      contactName: '',
      phone: '',
      email: '',
    });


    (<FormGroup>this.clientRegForm.get('regAddress')).patchValue({
      address1: '',
      address2: '',
      pincode: '',
      state: '',
      city: '',
    });
  }

  onSubmit() {
    
    console.log('clientRegForm : ', this.clientRegForm);
    if (!this.clientRegForm.valid) {
      this.alertMessage = "Please enter valid details";
      this.validateAllFormFields(this.clientRegForm);
      this.sharedService.setValidateAddress(true);
      return;
    }
    let formValue = this.clientRegForm.value;
    let clientData: ClientModel = {
      ...this.client,
      ...formValue
    }; 
    console.log('clientData : ', clientData);
    
    clientData.regAddress = formValue.regAddress;
  
    if(!this.editMode){
      
      clientData.id = this.totalClientCount + 1;
      clientData.createdDate = new Date();
      clientData.isActive = true;      
      

      this.spinner.show();

      this.clientEntityService.add(clientData).subscribe(res=>{        
        this.spinner.hide();
        this.alertMessage = "Client added successfully";   
        this.SetFormToInitialValues();           
      },
      error => {
        console.log('error : ',error);
        this.spinner.hide();
        this.alertMessage = error.error.error.statusMessage; 
      });            
    }
    else{
      this.spinner.show();
      this.clientEntityService.update(clientData).subscribe(res => {
        this.spinner.hide();
        this.alertMessage = "Client updated successfully";
      },
      error => {
        console.log('error : ',error);
        this.spinner.hide();
        this.alertMessage = error.error.error.statusMessage; 
      });      
    }    
  }

  closeAlert() {
    this.alertMessage = null;
    if(this.editMode && this.clientRegForm.valid){
      this.router.navigateByUrl('/clients');
    }    
  }

  validateAllFormFields(formGroup: FormGroup) {
  Object.keys(formGroup.controls).forEach(field => {  
    const control = formGroup.get(field);             
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);             
    }
  });
}

}

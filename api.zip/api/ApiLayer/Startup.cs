using System;
using System.IO;
using System.Text;
using iStock.ApiLayer.Hubs;

using iStock.CrudBusinessLayer;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
//using SoftAge.EmailService;
//using SoftAge.SMSService;

namespace iStock.ApiLayer
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddSignalR();

            services.AddCors(options =>
            {
                options.AddPolicy("iStockPolicy",
                    builder =>
                    {
                        builder.AllowAnyMethod()
                                .AllowAnyHeader()
                                .WithOrigins("http://localhost:4200", "http://localhost:5000","https://www.softageteledocm.com", "https://softageteledocm.com", "https://www.softageahm.com", "https://softageahm.com", "http://14.142.226.172")
                                .AllowCredentials();                        
                    });
                
            });

            services.Configure<FormOptions>(o =>
            {
                o.ValueLengthLimit = int.MaxValue;
                o.MultipartBodyLengthLimit = int.MaxValue;
                o.MemoryBufferThreshold = int.MaxValue;
            });

            services.AddDbContext<AuthDbContext>(options => options
                                                        .UseSqlServer(Configuration.GetConnectionString("LMDConnection")));

            services.AddIdentity<IdentityUser, IdentityRole>()
                .AddEntityFrameworkStores<AuthDbContext>()
                .AddDefaultTokenProviders();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                                        .AddJwtBearer(options =>
                                            options.TokenValidationParameters = new TokenValidationParameters
                                            {
                                                ValidateIssuer = false,
                                                ValidateAudience = false,
                                                ValidateLifetime = true,
                                                ValidateIssuerSigningKey = true,
                                                IssuerSigningKey = new SymmetricSecurityKey(
                                                    Encoding.UTF8.GetBytes(Configuration["jwt:key"])),
                                                ClockSkew = TimeSpan.Zero
                                            });

            //var emailConfig = Configuration
            //                        .GetSection("EmailConfiguration")
            //                        .Get<EmailConfiguration>();

            //var smsConfig = Configuration
            //                        .GetSection("SMSConfiguration")
            //                        .Get<SMSConfiguration>();

            //services.AddSingleton(emailConfig);
            //services.AddSingleton(smsConfig);

            //services.AddScoped<IEmailSender, EmailSender>();
            //services.AddScoped<ISMSSender, SMSSender>();

            services.AddControllers().SetCompatibilityVersion(CompatibilityVersion.Latest).AddNewtonsoftJson();

            services.AddCrudBusinessLayerDependencies();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "iStock API",
                    Description = "iStock ASP.NET Core Web API",
                    Contact = new OpenApiContact() { Name = "Genius", Email = "joshi.25387@gmail.com" }
                });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddFile("Logs/log-{Date}.txt");


            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors("iStockPolicy");
           
            app.UseRouting();
            

            app.UseStaticFiles();
            //app.UseStaticFiles(new StaticFileOptions
            //{
            //    FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), @"www\Uploads\Error")),
            //    RequestPath = new PathString("/UploadError")
            //});

            app.UseAuthorization();

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.DocumentTitle = "iStock API info";
                c.RoutePrefix = string.Empty;
                c.SwaggerEndpoint("swagger/v1/swagger.json", "iStock API V1");
            });
                       

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHub<NotificationHub>("/notificationHub");
            });
        }
    }
}




//Scaffold-DbContext "Server=.;Initial Catalog=iStock;Persist Security Info=False;User ID=sa;Password=Softage@123456;MultipleActiveResultSets=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;" Microsoft.EntityFrameworkCore.SqlServer -OutputDir EntityModels -f
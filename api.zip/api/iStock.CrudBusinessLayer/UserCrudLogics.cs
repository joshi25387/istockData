﻿using Microsoft.AspNetCore.Mvc;
using iStock.CrudBusinessLayer.Interfaces;
using iStock.DataAccessLayer.IDataOperations;
using iStock.Models.ResponseModels;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using iStock.Models;

namespace iStock.CrudBusinessLayer
{
    public class UserCrudLogics : IUserCrudLogics
    {
        private readonly IUserDataOperations userDataOperations;

        public UserCrudLogics(IUserDataOperations userDataOperations)
        {
            this.userDataOperations = userDataOperations;
        }
        public async Task<IActionResult> GetRoles(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await userDataOperations.GetRoles(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new RoleResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message, RoleList = dataLayerResponse.RoleList })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
        public async Task<IActionResult> CreateUser(string requestor, UserModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }
                if (model == null)
                {
                    return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.MethodNotAllowed, StatusMessage = "Invalid input" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await userDataOperations.CreateUser(requestor, model);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                return new ObjectResult(new BaseResponseModel()
                { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                { StatusCode = (int)dataLayerResponse.HttpStatus };
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusCode = (int)HttpStatusCode.InternalServerError, StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
        public async Task<IActionResult> GetUserAuthority(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }


                var dataLayerResponse = await userDataOperations.GetUserAuthority(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                else if (dataLayerResponse.HttpStatus != HttpStatusCode.OK)
                {
                    return new ObjectResult(new BaseResponseModel()
                    { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                    { StatusCode = (int)dataLayerResponse.HttpStatus };
                }
                else
                {
                    return new ObjectResult(new AuthorityResponseModel()
                    { AuthorityDetails = dataLayerResponse.AuthorityDetails, StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message });
                }
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<IActionResult> GetUserDetails(string requestor)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(requestor))
                {
                    return new ObjectResult(new BaseResponseModel() { StatusMessage = "No requestor Id found" })
                    { StatusCode = (int)HttpStatusCode.MethodNotAllowed };
                }

                var dataLayerResponse = await userDataOperations.GetUserDetails(requestor);
                if (dataLayerResponse == null)
                {
                    return new ObjectResult(new { Message = "Service Unavailable" }) { StatusCode = (int)HttpStatusCode.ServiceUnavailable };
                }
                else if (dataLayerResponse.HttpStatus != HttpStatusCode.OK || dataLayerResponse.UserDetails == null)
                {
                    return new ObjectResult(new BaseResponseModel()
                    { StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message })
                    { StatusCode = (int)dataLayerResponse.HttpStatus };
                }
                else
                {
                    return new ObjectResult(new UserDetailResponseModel()
                    { UserDetails = dataLayerResponse.UserDetails, StatusCode = dataLayerResponse.AdditionalStatusCode, StatusMessage = dataLayerResponse.Message });
                }
            }
            catch (Exception ex)
            {
                var exMsg = ex.InnerException is null ? ex.Message : ex.InnerException.Message;
                return new ObjectResult(new BaseResponseModel() { StatusMessage = exMsg })
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
            }
        }
    }
}

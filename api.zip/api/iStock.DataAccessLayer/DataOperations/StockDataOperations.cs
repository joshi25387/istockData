﻿using iStock.DataAccessLayer.DataContext;
using iStock.DataAccessLayer.IDataOperations;
using iStock.Models;
using iStock.Models.DALModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iStock.DataAccessLayer.DataOperations
{
    public class StockDataOperations : IStockDataOperations
    {
        public async Task<BaseDALStatus> CreateIncomingOrder(string requestor, IncomingOrderModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    if (dbContext.IncomingOrderDetails.Any(a => a.Blno.ToLower() == model.BlNo.ToLower() && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "B.L. No. already exists"
                        };
                    }

                    var _incomingOrderRecord = new EntityModels.IncomingOrderDetails
                    {
                        Blno = model.BlNo,
                        ArrivalPortId = model.ArrivalPortId,
                        CountryId = model.CountryId,
                        DocumentStatusId = model.DocumentStatusId,
                        EstDateOfArrival = model.EstDateOfArrival,
                        EstDateOfLoading = model.EstDateOfLoading,
                        InvoiceNo = model.InvoiceNo,
                        LoadingWeekNo = model.LoadingWeekNo,
                        NetWeight = model.NetWeight,
                        NoOfContainer = model.NoOfContainer,
                        PackingListQty = model.PackingListQty,
                        PaymentTermsAdv = model.PaymentTermsAdv,
                        PaymentTermsOnDoc = model.PaymentTermsOnDoc,
                        PaymentTermsAfterArr = model.PaymentTermsAfterArr,
                        Freight = model.Freight,
                        Currency = model.Currency,
                        ExchangeRate = model.ExchangeRate,
                        PhytoNo = model.PhytoNo,
                        CertificateOfOrigin = model.CertificateOfOrigin,
                        NonGmoCertificate = model.NonGmoCertificate,
                        PerformaInvoiceNo = model.PerformaInvoiceNo,
                        InwardingDone = false,
                        ShipperId = model.ShipperId,
                        ShippingLineId = model.ShippingLineId,
                        ShippingTerms = model.ShippingTerms,
                        VesselNo = model.VesselNo,
                        TotalGrossWeight = model.TotalGrossWeight,
                        IsActive = true,
                        CreatedBy = requestor,
                        CreatedDate = DateTime.Now
                    };

                    dbContext.IncomingOrderDetails.Add(_incomingOrderRecord);

                    await dbContext.SaveChangesAsync();


                    if (!string.IsNullOrEmpty(model.PerformaInvoiceNo))
                    {
                        var _performaInvoiceCheckRecord = await dbContext.PerformaInvoiceDetails.Where(p => p.PerformaInvoiceNo.ToLower() == model.PerformaInvoiceNo.ToLower()
                                                                                                                && p.IsActive == true && p.InvoiceStatus == "Pending").FirstOrDefaultAsync();

                        if (_performaInvoiceCheckRecord != null)
                        {
                            _performaInvoiceCheckRecord.InvoiceStatus = "Done";
                            _performaInvoiceCheckRecord.UpdatedBy = requestor;
                            _performaInvoiceCheckRecord.UpdatedDate = DateTime.Now;

                            dbContext.Entry(_performaInvoiceCheckRecord).State = EntityState.Modified;
                            await dbContext.SaveChangesAsync();
                        }
                    }


                    foreach (var _containerRecords in model.ContainerDetails)
                    {
                        foreach (var _itemRecords in _containerRecords.ContainerItemDetails)
                        {
                            dbContext.IncomingOrderContainerDetails.Add(new EntityModels.IncomingOrderContainerDetails()
                            {
                                IncomingOrderId = _incomingOrderRecord.Id,
                                ContainerNo = _containerRecords.ContainerNo,
                                TotalQty = _containerRecords.TotalQty,
                                ItemId = _itemRecords.ItemId,
                                BrandId = _itemRecords.BrandId,
                                PackingId = _itemRecords.PackingId,
                                CountId = _itemRecords.CountId,
                                Qty = _itemRecords.Qty,
                                //SelfAllocated = _itemRecords.SelfAllocated,
                                //AllocatedPartyId = _itemRecords.AllocatedPartyId,
                                CreatedBy = requestor,
                                CreatedDate = DateTime.Now,
                                IsActive = true                                
                            });
                            await dbContext.SaveChangesAsync();
                        }
                    }                    

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Incoming successfully done"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> DeleteIncomingOrder(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _incomingOrderRecord = await dbContext.IncomingOrderDetails.Where(a => a.Id == id).FirstOrDefaultAsync();
                    if (_incomingOrderRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Data not found"
                        };
                    }

                    _incomingOrderRecord.IsActive = false;
                    _incomingOrderRecord.UpdatedBy = requestor;
                    _incomingOrderRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_incomingOrderRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    var _incomingOrderContainerRecords = await dbContext.IncomingOrderContainerDetails
                                                                .Where(a => a.IncomingOrderId == _incomingOrderRecord.Id && a.IsActive == true)
                                                                .ToListAsync();

                    foreach (var _record in _incomingOrderContainerRecords)
                    {
                        _record.IsActive = false;
                        _record.UpdatedBy = requestor;
                        _record.UpdatedDate = DateTime.Now;
                        dbContext.Entry(_record).State = EntityState.Modified;
                        await dbContext.SaveChangesAsync();
                    }

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "B.L. No. deleted successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<IncomingOrderSingleDALModel> GetIncomingOrderById(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _incomingOrderRecord = await dbContext.IncomingOrderDetails.Where(a => a.Id == id && a.IsActive == true)
                                                                        .Select(x=>new IncomingOrderModel()
                                                                        { 
                                                                            Id = x.Id,
                                                                            BlNo = x.Blno,
                                                                            ArrivalPortId = x.ArrivalPortId,
                                                                            CountryId = x.CountryId,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate,
                                                                            DocumentStatusId = x.DocumentStatusId,
                                                                            EstDateOfArrival = x.EstDateOfArrival,
                                                                            EstDateOfLoading = x.EstDateOfLoading,
                                                                            InvoiceNo = x.InvoiceNo,
                                                                            LoadingWeekNo = x.LoadingWeekNo,
                                                                            NetWeight = x.NetWeight,
                                                                            NoOfContainer = x.NoOfContainer,
                                                                            PackingListQty = x.PackingListQty,
                                                                            PaymentTermsAdv = x.PaymentTermsAdv,
                                                                            PaymentTermsOnDoc = x.PaymentTermsOnDoc,
                                                                            PaymentTermsAfterArr = x.PaymentTermsAfterArr,
                                                                            Freight = x.Freight,
                                                                            Currency = x.Currency,
                                                                            ExchangeRate = x.ExchangeRate,
                                                                            PhytoNo = x.PhytoNo,
                                                                            CertificateOfOrigin = x.CertificateOfOrigin,
                                                                            NonGmoCertificate = x.NonGmoCertificate,
                                                                            PerformaInvoiceNo = x.PerformaInvoiceNo,
                                                                            ShipperId = x.ShipperId,
                                                                            ShippingLineId = x.ShippingLineId,
                                                                            ShippingTerms = x.ShippingTerms,
                                                                            TotalGrossWeight = x.TotalGrossWeight,                                                                            
                                                                            VesselNo = x.VesselNo                                                                                                                                   
                                                                        })
                                                                        .FirstOrDefaultAsync();


                    var _incomingOrderContainerRecords = await dbContext.IncomingOrderContainerDetails
                                                                    .Where(a => a.IncomingOrderId == _incomingOrderRecord.Id && a.IsActive == true)
                                                                    .ToListAsync();

                    var _dictinctContainers = _incomingOrderContainerRecords.Select(x => x.ContainerNo).Distinct().ToList();

                    List<IncomingOrderContainerDetailModel> _containerDetails = new List<IncomingOrderContainerDetailModel>();

                    foreach (var _container in _dictinctContainers)
                    {
                        var _incomingOrderContainerItemRecords = await dbContext.IncomingOrderContainerDetails
                                                                        .Where(a => a.IncomingOrderId == _incomingOrderRecord.Id
                                                                                    && a.ContainerNo == _container
                                                                                    && a.IsActive == true)
                                                                        .Select(x => new IncomingOrderContainerItemDetailModel()
                                                                        {
                                                                            ItemId = x.ItemId,
                                                                            BrandId = x.BrandId,
                                                                            PackingId = x.PackingId,
                                                                            CountId = x.CountId,
                                                                            Qty = x.Qty,
                                                                            SelfAllocated = x.SelfAllocated,
                                                                            AllocatedPartyId = x.AllocatedPartyId
                                                                        })
                                                                        .ToListAsync();
                        var _containerRecord = new IncomingOrderContainerDetailModel()
                        {
                            ContainerNo = _container,
                            TotalQty = _incomingOrderContainerRecords.Where(c=>c.ContainerNo == _container).FirstOrDefault().TotalQty,
                            ContainerItemDetails = _incomingOrderContainerItemRecords
                        };

                        _containerDetails.Add(_containerRecord);
                    }

                    _incomingOrderRecord.ContainerDetails = _containerDetails;
                    return new IncomingOrderSingleDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        IncomingOrderDetails = _incomingOrderRecord,
                        Message = "Success"
                    };

                    
                }
                catch (Exception ex)
                {
                    return new IncomingOrderSingleDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        IncomingOrderDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<IncomingOrderDALModel> GetIncomingOrders(string requestor)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _incomingOrderRecords = await dbContext.IncomingOrderDetails.Where(a => a.IsActive == true)
                                                                        .Select(x => new IncomingOrderModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            BlNo = x.Blno,
                                                                            ArrivalPortId = x.ArrivalPortId,
                                                                            CountryId = x.CountryId,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate,
                                                                            DocumentStatusId = x.DocumentStatusId,
                                                                            EstDateOfArrival = x.EstDateOfArrival,
                                                                            EstDateOfLoading = x.EstDateOfLoading,
                                                                            InvoiceNo = x.InvoiceNo,
                                                                            LoadingWeekNo = x.LoadingWeekNo,
                                                                            NetWeight = x.NetWeight,
                                                                            NoOfContainer = x.NoOfContainer,
                                                                            PackingListQty = x.PackingListQty,
                                                                            PaymentTermsAdv = x.PaymentTermsAdv,
                                                                            PaymentTermsOnDoc = x.PaymentTermsOnDoc,
                                                                            PaymentTermsAfterArr = x.PaymentTermsAfterArr,
                                                                            Freight = x.Freight,
                                                                            Currency = x.Currency,
                                                                            ExchangeRate = x.ExchangeRate,
                                                                            PhytoNo = x.PhytoNo,
                                                                            CertificateOfOrigin = x.CertificateOfOrigin,
                                                                            NonGmoCertificate = x.NonGmoCertificate,
                                                                            PerformaInvoiceNo = x.PerformaInvoiceNo,
                                                                            ShipperId = x.ShipperId,
                                                                            ShippingLineId = x.ShippingLineId,
                                                                            ShippingTerms = x.ShippingTerms,
                                                                            TotalGrossWeight = x.TotalGrossWeight,
                                                                            VesselNo = x.VesselNo
                                                                        }).ToListAsync();

                    return new IncomingOrderDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        IncomingOrderDetails = _incomingOrderRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new IncomingOrderDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        IncomingOrderDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> UpdateIncomingOrder(string requestor, IncomingOrderModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _incomingOrderRecord = await dbContext.IncomingOrderDetails.Where(a => a.Id == model.Id).FirstOrDefaultAsync();
                    if (_incomingOrderRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "B.L. No. not found"
                        };
                    }

                    if (dbContext.IncomingOrderDetails.Any(a => a.Blno.ToLower() == model.BlNo.ToLower() && a.Id != model.Id && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "B.L. No. already exists"
                        };
                    }

                    _incomingOrderRecord.Blno = model.BlNo;
                    _incomingOrderRecord.ArrivalPortId = model.ArrivalPortId;
                    _incomingOrderRecord.CountryId = model.CountryId;
                    _incomingOrderRecord.DocumentStatusId = model.DocumentStatusId;
                    _incomingOrderRecord.EstDateOfArrival = model.EstDateOfArrival;
                    _incomingOrderRecord.EstDateOfLoading = model.EstDateOfLoading;
                    _incomingOrderRecord.InvoiceNo = model.InvoiceNo;
                    _incomingOrderRecord.LoadingWeekNo = model.LoadingWeekNo;
                    _incomingOrderRecord.NetWeight = model.NetWeight;
                    _incomingOrderRecord.NoOfContainer = model.NoOfContainer;
                    _incomingOrderRecord.PackingListQty = model.PackingListQty;
                    _incomingOrderRecord.PaymentTermsAdv = model.PaymentTermsAdv;
                    _incomingOrderRecord.PaymentTermsOnDoc = model.PaymentTermsOnDoc;
                    _incomingOrderRecord.PaymentTermsAfterArr = model.PaymentTermsAfterArr;
                    _incomingOrderRecord.Freight = model.Freight;
                    _incomingOrderRecord.Currency = model.Currency;
                    _incomingOrderRecord.ExchangeRate = model.ExchangeRate;
                    _incomingOrderRecord.PhytoNo = model.PhytoNo;
                    _incomingOrderRecord.CertificateOfOrigin = model.CertificateOfOrigin;
                    _incomingOrderRecord.NonGmoCertificate = model.NonGmoCertificate;
                    _incomingOrderRecord.PerformaInvoiceNo = model.PerformaInvoiceNo;                    
                    _incomingOrderRecord.ShipperId = model.ShipperId;
                    _incomingOrderRecord.ShippingLineId = model.ShippingLineId;
                    _incomingOrderRecord.ShippingTerms = model.ShippingTerms;
                    _incomingOrderRecord.VesselNo = model.VesselNo;
                    _incomingOrderRecord.TotalGrossWeight = model.TotalGrossWeight;
                    _incomingOrderRecord.IsActive = true;
                    _incomingOrderRecord.UpdatedBy = requestor;
                    _incomingOrderRecord.UpdatedDate = DateTime.Now;

                    dbContext.Entry(_incomingOrderRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();


                    if (!string.IsNullOrEmpty(model.PerformaInvoiceNo))
                    {
                        var _performaInvoiceCheckRecord = await dbContext.PerformaInvoiceDetails.Where(p => p.PerformaInvoiceNo.ToLower() == model.PerformaInvoiceNo.ToLower()
                                                                                                                && p.IsActive == true && p.InvoiceStatus == "Pending").FirstOrDefaultAsync();

                        if (_performaInvoiceCheckRecord != null)
                        {
                            _performaInvoiceCheckRecord.InvoiceStatus = "Done";
                            _performaInvoiceCheckRecord.UpdatedBy = requestor;
                            _performaInvoiceCheckRecord.UpdatedDate = DateTime.Now;

                            dbContext.Entry(_performaInvoiceCheckRecord).State = EntityState.Modified;
                            await dbContext.SaveChangesAsync();
                        }
                    }

                    var _incomingOrderContainerRecords = await dbContext.IncomingOrderContainerDetails
                                            .Where(a => a.IncomingOrderId == _incomingOrderRecord.Id && a.IsActive == true)
                                            .ToListAsync();

                    foreach (var _record in _incomingOrderContainerRecords)
                    {
                        _record.IsActive = false;
                        _record.UpdatedBy = requestor;
                        _record.UpdatedDate = DateTime.Now;
                        dbContext.Entry(_record).State = EntityState.Modified;
                        await dbContext.SaveChangesAsync();
                    }

                    foreach (var _containerRecords in model.ContainerDetails)
                    {
                        foreach (var _itemRecords in _containerRecords.ContainerItemDetails)
                        {
                            dbContext.IncomingOrderContainerDetails.Add(new EntityModels.IncomingOrderContainerDetails()
                            {
                                IncomingOrderId = _incomingOrderRecord.Id,
                                ContainerNo = _containerRecords.ContainerNo,
                                TotalQty = _containerRecords.TotalQty,
                                ItemId = _itemRecords.ItemId,
                                BrandId = _itemRecords.BrandId,
                                PackingId = _itemRecords.PackingId,
                                CountId = _itemRecords.CountId,
                                Qty = _itemRecords.Qty,
                                SelfAllocated = _itemRecords.SelfAllocated,
                                AllocatedPartyId = _itemRecords.AllocatedPartyId,
                                CreatedBy = requestor,
                                CreatedDate = DateTime.Now,
                                IsActive = true
                            });
                            await dbContext.SaveChangesAsync();
                        }
                    }


                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "B.L. no. updated successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }



        public async Task<BaseDALStatus> CreatePerformaInvoice(string requestor, PerformaInvoiceModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    if (dbContext.PerformaInvoiceDetails.Any(a => a.PerformaInvoiceNo.ToLower() == model.PerformaInvoiceNo.ToLower() && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Performa invoice no. already exists"
                        };
                    }

                    var _performaInvoiceRecord = new EntityModels.PerformaInvoiceDetails
                    {
                        PerformaInvoiceNo = model.PerformaInvoiceNo,
                        InvoiceDate = model.InvoiceDate,
                        VendorId = model.VendorId,
                        Amount = model.Amount,
                        InvoiceStatus = "Pending",                        
                        IsActive = true,
                        CreatedBy = requestor,
                        CreatedDate = DateTime.Now
                    };

                    dbContext.PerformaInvoiceDetails.Add(_performaInvoiceRecord);

                    await dbContext.SaveChangesAsync();                    

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Performa invoice successfully created"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<BaseDALStatus> DeletePerformaInvoice(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _performaInvoiceRecord = await dbContext.PerformaInvoiceDetails.Where(a => a.Id == id).FirstOrDefaultAsync();
                    if (_performaInvoiceRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Data not found"
                        };
                    }

                    _performaInvoiceRecord.IsActive = false;
                    _performaInvoiceRecord.UpdatedBy = requestor;
                    _performaInvoiceRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_performaInvoiceRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();
                    
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Performa invoice deleted successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<PerformaInvoiceSingleDALModel> GetPerformaInvoiceById(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _performaInvoiceRecord = await dbContext.PerformaInvoiceDetails.Include(p=>p.Vendor).Where(a => a.Id == id && a.IsActive == true)
                                                                        .Select(x => new PerformaInvoiceModel()
                                                                        {
                                                                            Id = x.Id,                                                                            
                                                                            PerformaInvoiceNo = x.PerformaInvoiceNo,
                                                                            InvoiceDate = x.InvoiceDate,
                                                                            Amount = x.Amount,
                                                                            VendorId = x.VendorId,
                                                                            VendorName = x.Vendor.PartyName,
                                                                            InvoiceStatus = x.InvoiceStatus,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        })
                                                                        .FirstOrDefaultAsync();
                    
                    return new PerformaInvoiceSingleDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        PerformaInvoiceDetails = _performaInvoiceRecord,
                        Message = "Success"
                    };


                }
                catch (Exception ex)
                {
                    return new PerformaInvoiceSingleDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        PerformaInvoiceDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<PerformaInvoiceDALModel> GetPerformaInvoices(string requestor)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _performaInvoiceRecords = await dbContext.PerformaInvoiceDetails.Include(p=>p.Vendor).Where(a => a.IsActive == true)
                                                                        .Select(x => new PerformaInvoiceModel()
                                                                        {
                                                                            Id = x.Id,                                                                            
                                                                            PerformaInvoiceNo = x.PerformaInvoiceNo,
                                                                            InvoiceDate = x.InvoiceDate,
                                                                            Amount = x.Amount,
                                                                            VendorId = x.VendorId,
                                                                            VendorName = x.Vendor.PartyName,
                                                                            InvoiceStatus = x.InvoiceStatus,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).ToListAsync();

                    return new PerformaInvoiceDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        PerformaInvoiceDetails = _performaInvoiceRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new PerformaInvoiceDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        PerformaInvoiceDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<BaseDALStatus> UpdatePerformaInvoice(string requestor, PerformaInvoiceModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _performaInvoiceRecord = await dbContext.PerformaInvoiceDetails.Where(a => a.Id == model.Id).FirstOrDefaultAsync();
                    if (_performaInvoiceRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Perfoma invoice no. not found"
                        };
                    }

                    if (dbContext.PerformaInvoiceDetails.Any(a => a.PerformaInvoiceNo.ToLower() == model.PerformaInvoiceNo.ToLower() && a.Id != model.Id && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Performa invoice no. already exists"
                        };
                    }
                    
                    _performaInvoiceRecord.PerformaInvoiceNo = model.PerformaInvoiceNo;
                    _performaInvoiceRecord.InvoiceDate = model.InvoiceDate;
                    _performaInvoiceRecord.VendorId = model.VendorId;
                    _performaInvoiceRecord.Amount = model.Amount;                    
                    _performaInvoiceRecord.IsActive = true;
                    _performaInvoiceRecord.UpdatedBy = requestor;
                    _performaInvoiceRecord.UpdatedDate = DateTime.Now;

                    dbContext.Entry(_performaInvoiceRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();                  

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Performa invoice updated successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }
    }
}

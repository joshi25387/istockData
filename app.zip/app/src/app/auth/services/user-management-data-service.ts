import { DefaultDataService, HttpUrlGenerator } from '@ngrx/data';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Update } from '@ngrx/entity';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { UserInfoModel } from '../models/user.model';



@Injectable({providedIn : 'root'})
export class UserClientStoreMappingDataService extends DefaultDataService<UserInfoModel>{

  entities: UserInfoModel[] = [];

  constructor(http: HttpClient, httpUrlGenerator: HttpUrlGenerator) {
    super('UserClientStoreMapping', http, httpUrlGenerator);
  }


  getAll() : Observable<UserInfoModel[]>{
    return this.http.get(environment.apiUrl + "user/GetAllUserClientStoreMapping").pipe(map(response => response['userDetail']));
  }
  
  getWithQuery(userCode) : Observable<UserInfoModel[]>{
      console.log(environment.apiUrl + "user/GetUserClientStoreMapping/"+ userCode);
    return this.http.get(environment.apiUrl + "user/GetUserClientStoreMapping/"+ userCode).pipe(map(response => response['userDetail']));
  }
  
  update(update : Update<UserInfoModel>): Observable<UserInfoModel>{   
    return this.http.put<UserInfoModel>(environment.apiUrl+ 'user/UpdateUserStoreMapping/'+update.id, update.changes)
                    .pipe(map(response => response['userDetail']));
  }  

}
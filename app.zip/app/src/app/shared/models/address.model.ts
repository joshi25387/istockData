export interface Address{
    address1 : string,
    address2 : string,
    state? : number,
    city? : number,
    pincode : number
}


export interface PincodeModel {
    pincode : number,
    state : string,
    city : string
}
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { PartyGroupModel } from '../model/master-data.model';
import { MasterDataService } from '../services/master-data.service';

@Component({
  selector: 'party-group',
  templateUrl: './party-group.component.html',
  styleUrls: ['./party-group.component.css']
})
export class PartyGroupComponent implements OnInit {

  partyGroupForm: FormGroup;
  alertMessage: string = null;
  editMode: boolean = false;
  viewMode: boolean = false;
  
  cardText : string = "Add Party Group";
  buttonText: string = "Submit";

  errorAlertMessage : string = '';
  
  partyGroup: PartyGroupModel;

  constructor(private fb: FormBuilder,
    private router: Router,
    private masterDataService : MasterDataService,
    private route: ActivatedRoute,    
    private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.partyGroupForm = this.fb.group({
      id: [''],
      groupName: ['', Validators.required],      
    });

    this.route.params.subscribe(
      (params: Params) => {
        this.editMode = !!params['id'];
        this.buttonText = this.editMode ? "Update" : "Submit";
        if (this.editMode) {
          this.cardText = "Update Party Group";
          const partyGroupIdToEdit = +params['id'];

          this.masterDataService.getPartyGroupById(partyGroupIdToEdit).subscribe(res=>{
              this.PopulateForm(res);
          });
        }
      }
    );

    this.partyGroupForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.partyGroupForm);
    });
         
  }

  validationMessages = {
    'groupName' : {
      'required' : 'Party group name is required'
    }
  };

  formErrors = {
    'groupName' : ''
  }

  get f() { return this.partyGroupForm.controls; }

  PopulateForm(partyGroup: PartyGroupModel) {
    if (partyGroup) {      
      this.partyGroupForm.patchValue({
        id: partyGroup.id,
        groupName: partyGroup.groupName        
      });
    }
  }


  onSubmit() {

    this.logValidationErrorsOnSubmit();
   
    if(this.errorAlertMessage!=''){
      this.alertMessage = this.errorAlertMessage;
      return;
    }
    
    if (!this.partyGroupForm.valid) {
      this.alertMessage = "Please enter valid details";      
      return;
    }

    

    let formValue = this.partyGroupForm.getRawValue();
    let partyGroupData: PartyGroupModel = {
      ...this.partyGroup,
      ...formValue
    };
    console.log('partyGroupData : ', partyGroupData);

    if (!this.editMode) {   
      this.spinner.show();
      partyGroupData.id = 0;
      this.masterDataService.createPartyGroup(partyGroupData).subscribe(res=>{
        console.log('res : ',res);
        if(res){
          if(res['statusCode'] == 200){
            this.partyGroupForm.reset();
          }
          this.alertMessage = res['statusMessage']          
        }
        this.spinner.hide();
      });
    }
    else {
      this.spinner.show();
      this.masterDataService.updatePartyGroup(partyGroupData).subscribe(res=>{
        console.log('res : ',res);
        this.spinner.hide();
      });
    }
  }

  closeAlert() {
    this.alertMessage = null;    
  }

  logValidationErrors(group : FormGroup = this.partyGroupForm) : void {
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid &&
          (abstractControl.touched || abstractControl.dirty)){
            const messages = this.validationMessages[key];

            for(const errorKey in abstractControl.errors){
              if(errorKey){
                this.formErrors[key] += messages[errorKey] + ' ';                
              }
            }
          }
      }
    });
  }

  logValidationErrorsOnSubmit(group : FormGroup = this.partyGroupForm) : void {
    this.errorAlertMessage ='';
    Object.keys(group.controls).forEach((key : string) => {
      const abstractControl = group.get(key);
      if(abstractControl instanceof FormGroup){
        this.logValidationErrors(abstractControl);
      }
      else{
        this.formErrors[key] =  '';
        if(abstractControl && !abstractControl.valid ){
            const messages = this.validationMessages[key];
            for(const errorKey in abstractControl.errors){
              if(errorKey){
                abstractControl.markAsTouched({ onlySelf: true });
                this.formErrors[key] += messages[errorKey] + ' ';
                if(this.errorAlertMessage == ''){
                  this.errorAlertMessage = messages[errorKey];
                }
              }
            }
          }
      }
    });
  }

}

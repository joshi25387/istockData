﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class PartyMaster
    {
        public PartyMaster()
        {
            IncomingOrderContainerDetails = new HashSet<IncomingOrderContainerDetails>();
            IncomingOrderDetailsShipper = new HashSet<IncomingOrderDetails>();
            IncomingOrderDetailsShippingLine = new HashSet<IncomingOrderDetails>();
            PerformaInvoiceDetails = new HashSet<PerformaInvoiceDetails>();
        }

        public int Id { get; set; }
        public string PartyName { get; set; }
        public int PartyGroupId { get; set; }
        public string PartyAddress { get; set; }
        public string ContactNo { get; set; }
        public string Email { get; set; }
        public string StoreRentCalculationType { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int StateId { get; set; }
        public int CityId { get; set; }
        public string Pincode { get; set; }
        public string Panno { get; set; }
        public decimal CreditLimit { get; set; }
        public int PaymentTerms { get; set; }

        public virtual CityMaster City { get; set; }
        public virtual PartyGroupMaster PartyGroup { get; set; }
        public virtual StateMaster State { get; set; }
        public virtual ICollection<IncomingOrderContainerDetails> IncomingOrderContainerDetails { get; set; }
        public virtual ICollection<IncomingOrderDetails> IncomingOrderDetailsShipper { get; set; }
        public virtual ICollection<IncomingOrderDetails> IncomingOrderDetailsShippingLine { get; set; }
        public virtual ICollection<PerformaInvoiceDetails> PerformaInvoiceDetails { get; set; }
    }
}

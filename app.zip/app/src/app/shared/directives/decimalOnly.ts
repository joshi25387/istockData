import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { Key } from 'protractor';

@Directive({
  selector: 'input[decimalOnly]',
  host: {
    '[style.text-align]': '"right"',
  }
})
export class DecimalDirective {
  constructor(private _el: ElementRef) { }
  @HostListener('keydown', ['$event']) OnInput(event:KeyboardEvent) {
    console.log(event.keyCode);
    let _inputValue = event.target['value'];
    let _allowedKeyCodes = [8,9,37,39,46];
    if((event.keyCode >=48 && event.keyCode <=57) 
          || (event.keyCode >=96 && event.keyCode <=105) 
          || event.keyCode==190 
          || event.keyCode==110 
          || _allowedKeyCodes.indexOf(event.keyCode) >= 0){
      
      if(_inputValue==''){
        if(event.keyCode==190 || event.keyCode==110){
          event.target['value'] = '0';
        }        
      }
      else{
        if(event.keyCode==190 || event.keyCode==110){
          if(_inputValue.indexOf('.') >= 0){
            event.preventDefault();
          }
        }
      }
    }
    else{
      event.preventDefault();
    }
  }

}
import { createSelector, createFeatureSelector } from '@ngrx/store';
import { SideNavState } from './side-nav.reducer';


export const sideNavState = createFeatureSelector<SideNavState>("sideNav");

export const isVisible = createSelector(
    sideNavState,
    sideNavState => sideNavState.visible
);



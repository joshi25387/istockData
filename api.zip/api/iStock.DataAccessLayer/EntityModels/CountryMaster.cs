﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class CountryMaster
    {
        public CountryMaster()
        {
            IncomingOrderDetails = new HashSet<IncomingOrderDetails>();
        }

        public int Id { get; set; }
        public string Country { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual ICollection<IncomingOrderDetails> IncomingOrderDetails { get; set; }
    }
}

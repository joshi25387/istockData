import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArrivalPortComponent } from './arrival-port.component';

describe('ArrivalPortComponent', () => {
  let component: ArrivalPortComponent;
  let fixture: ComponentFixture<ArrivalPortComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArrivalPortComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArrivalPortComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

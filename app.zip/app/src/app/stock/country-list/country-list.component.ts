import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { UserDetail } from 'src/app/auth/models/user.model';
import { CountryModel } from '../model/master-data.model';
import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { MasterDataService } from '../services/master-data.service';
import { AuthService } from 'src/app/auth/auth.service';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';

@Component({
  selector: 'country-list',
  templateUrl: './country-list.component.html',
  styleUrls: ['./country-list.component.css']
})
export class CountryListComponent implements OnInit {

  confirmMessage: string = null;  

  countryList$: Observable<CountryModel[]>;
  filter = new FormControl('');

  countryToUpdate: number = -1;

  showAckDialog : boolean = false;
  
  alertMessage:string =null;
  frameworkComponents: any;

  countryIdToDelete : number = -1;

  orderStatusFilter : string;
  storeIdFilter : number;
  userDetail : UserDetail;

  
  columnDefs = [    
    {  headerName: 'Id',field: 'id', sortable: true, filter: true,resizable:true,width:110,pinned:'left'},        
    { headerName: 'Country', field: 'country', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: 'Created Date', field: 'createdDate', sortable : true, filter : true,width : 180 ,
          resizable : true,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
      },  
    { headerName: 'Created By', field: 'createdBy', sortable: true, filter: true,resizable:true,width:130,pinned : 'left' },
    { headerName: '', cellRenderer: 'editDeleteButtonRenderer', 
    cellRendererParams: {
        onEditClick: this.editCountry.bind(this),
        onDeleteClick: this.deleteCountry.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private masterDataService : MasterDataService,
    private authService : AuthService) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }

    this.authService.userDetail.subscribe(userDet => {      
      this.userDetail = userDet
    });
    this.countryList$ = this.masterDataService.getCountryList();        
  }

  onConfirmOk(){
    if(this.countryIdToDelete > -1){

      this.masterDataService.deleteCountry(this.countryIdToDelete).subscribe(res=>{
        if(res){
          this.alertMessage = res['statusMessage'];
          this.countryList$ = this.masterDataService.getCountryList();
        }
      });
    }
    this.confirmMessage = null;
  }

  onConfirmCancel(){
    this.countryIdToDelete = -1;
    this.confirmMessage = null;
  }

  editCountry(countryRow){
    let countryId : number = +countryRow.rowData.id;
    this.router.navigate([countryId,'edit'],{relativeTo:this.route});
  }

  deleteCountry(countryRow){
    this.countryIdToDelete = +countryRow.rowData.id;
    this.confirmMessage = "Are you sure to delete country " + countryRow.rowData.country + " ?";
  }
  
  closeAlert() {
    this.alertMessage = null;    
  }
}

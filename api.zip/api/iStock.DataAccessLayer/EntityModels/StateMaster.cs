﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class StateMaster
    {
        public StateMaster()
        {
            CityMaster = new HashSet<CityMaster>();
            PartyMaster = new HashSet<PartyMaster>();
        }

        public int Id { get; set; }
        public string StateName { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual ICollection<CityMaster> CityMaster { get; set; }
        public virtual ICollection<PartyMaster> PartyMaster { get; set; }
    }
}

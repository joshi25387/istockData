import { Component, OnInit } from '@angular/core';
import { AgentEntityService } from '../services/agent-entity.service';
import { Observable } from 'rxjs';

import { FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Agent } from '../models/agent.model';
import { EditDeleteButtonRendererComponent } from 'src/app/shared/ag-grid-renderers/edit-delete-button-renderer';

import * as moment from 'moment';

@Component({
  selector: 'agent-list',
  templateUrl: './agent-list.component.html',
  styleUrls: ['./agent-list.component.css']
})
export class AgentListComponent implements OnInit {

  confirmMessage : string = null;
  agentsList$ : Observable<Agent[]>;
  filter = new FormControl('');

  agentIdToDelete : number = -1;

  frameworkComponents : any;

  columnDefs = [
    { headerName: 'Name', field: 'agentName', sortable : true, filter : true ,width : 180, resizable : true},
    { headerName: 'Mobile', field: 'mobile', sortable : true, filter : true,width : 180, resizable : true },
    { headerName: 'Creation Date', field: 'createdDate', sortable : true, filter : true,width : 180, 
          resizable : true ,
          valueFormatter: function (params) {
            return moment(params.value).format('D-MMM-YYYY');
            }
      },
    { headerName: '', cellRenderer: 'editDeleteButtonRenderer', 
    cellRendererParams: {
        onEditClick: this.editAgent.bind(this),
        onDeleteClick: this.deleteAgent.bind(this)        
      },      
      type: 'rightAligned'
    }
  ];

  constructor(private agentEntityService : AgentEntityService,
              private router : Router,
              private route : ActivatedRoute) { }

  ngOnInit(): void {
    this.frameworkComponents = {
      editDeleteButtonRenderer: EditDeleteButtonRendererComponent      
    }
    this.agentsList$ = this.agentEntityService.entities$;        
  }

  onConfirmOk(){
    if(this.agentIdToDelete > -1){
      this.agentEntityService.delete(this.agentIdToDelete);
    }
    this.confirmMessage = null;
  }
  onConfirmCancel(){
    this.agentIdToDelete = -1;
    this.confirmMessage = null;
  }

  editAgent(agentRow){
    let agentId : number = +agentRow.rowData.id;
    this.router.navigate([agentId,'edit'],{relativeTo:this.route});
  }

  deleteAgent(agentRow){
    this.agentIdToDelete = +agentRow.rowData.id;
    this.confirmMessage = "Are you sure to delete agent " + this.agentIdToDelete + " ?";
  }

}

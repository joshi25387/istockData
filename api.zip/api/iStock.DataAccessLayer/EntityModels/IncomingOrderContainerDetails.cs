﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class IncomingOrderContainerDetails
    {
        public int Id { get; set; }
        public int? IncomingOrderId { get; set; }
        public string ContainerNo { get; set; }
        public int? TotalQty { get; set; }
        public int? ItemId { get; set; }
        public int? BrandId { get; set; }
        public int? PackingId { get; set; }
        public int? CountId { get; set; }
        public int? Qty { get; set; }
        public decimal? Rate { get; set; }
        public string SelfAllocated { get; set; }
        public int? AllocatedPartyId { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual PartyMaster AllocatedParty { get; set; }
        public virtual ItemBrandMaster Brand { get; set; }
        public virtual ItemCountMaster Count { get; set; }
        public virtual IncomingOrderDetails IncomingOrder { get; set; }
        public virtual ItemMaster Item { get; set; }
        public virtual ItemPackingMaster Packing { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace iStock.DataAccessLayer.EntityModels
{
    public partial class PaymentBankRejectionDetails
    {
        public int Id { get; set; }
        public int PaymentBankDetailId { get; set; }
        public int RejectionReasonId { get; set; }
        public bool? IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }

        public virtual PaymentBankDetails PaymentBankDetail { get; set; }
        public virtual RejectionReason RejectionReason { get; set; }
    }
}

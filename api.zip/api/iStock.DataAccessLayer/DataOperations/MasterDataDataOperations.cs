﻿using iStock.DataAccessLayer.DataContext;
using iStock.DataAccessLayer.IDataOperations;
using iStock.Models;
using iStock.Models.DALModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iStock.DataAccessLayer.DataOperations
{
    public class MasterDataDataOperations : IMasterDataDataOperations
    {
        public async Task<BaseDALStatus> CreateArrivalPort(string requestor, ArrivalPortMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    if (dbContext.ArrivalPortMaster.Any(a => a.City.ToLower() == model.City.ToLower() && a.IsActive==true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Arrival port already exists"
                        };
                    }

                    dbContext.ArrivalPortMaster.Add(new EntityModels.ArrivalPortMaster()
                    {
                        City = model.City,
                        IsActive = true,
                        CreatedBy = requestor,
                        CreatedDate = DateTime.Now                        
                    });
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Arrival port created successfully"
                    };                    
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,                        
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> CreateCountry(string requestor, CountryMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    if (dbContext.CountryMaster.Any(a => a.Country.ToLower() == model.Country.ToLower() && a.IsActive==true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Country already exists"
                        };
                    }

                    dbContext.CountryMaster.Add(new EntityModels.CountryMaster()
                    {
                        Country = model.Country,
                        IsActive = true,
                        CreatedBy = requestor,
                        CreatedDate = DateTime.Now
                    });
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Country created successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> CreateDocumentStatus(string requestor, DocumentStatusMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    if (dbContext.DocumentStatusMaster.Any(a => a.DocStatus.ToLower() == model.DocStatus.ToLower() && a.IsActive==true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Document status already exists"
                        };
                    }

                    dbContext.DocumentStatusMaster.Add(new EntityModels.DocumentStatusMaster()
                    {
                        DocStatus = model.DocStatus,
                        IsActive = true,
                        CreatedBy = requestor,
                        CreatedDate = DateTime.Now
                    });
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Document status created successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> CreateItem(string requestor, ItemMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    if (dbContext.ItemMaster.Any(a => a.ItemName.ToLower() == model.ItemName.ToLower() && a.IsActive==true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Item already exists"
                        };
                    }

                    var _itemMasterRecord = new EntityModels.ItemMaster()
                    {
                        ItemGroupId = model.ItemGroupId,
                        ItemName = model.ItemName,
                        IsActive = true,
                        CreatedBy = requestor,
                        CreatedDate = DateTime.Now
                    };

                    dbContext.ItemMaster.Add(_itemMasterRecord);
                    await dbContext.SaveChangesAsync();

                    foreach (var _brand in model.ItemBrandList)
                    {
                        dbContext.ItemBrandMaster.Add(new EntityModels.ItemBrandMaster
                        {
                            ItemId = _itemMasterRecord.Id,
                            ItemBrandName = _brand.ItemBrandName,
                            CreatedBy = requestor,
                            CreatedDate = DateTime.Now,
                            IsActive = true                            
                        });
                        await dbContext.SaveChangesAsync();
                    }
                    foreach (var _packing in model.ItemPackingList)
                    {
                        dbContext.ItemPackingMaster.Add(new EntityModels.ItemPackingMaster
                        {
                            ItemId = _itemMasterRecord.Id,
                            ItemPacking = _packing.ItemPacking,
                            CreatedBy = requestor,
                            CreatedDate = DateTime.Now,
                            IsActive = true
                        });
                        await dbContext.SaveChangesAsync();
                    }
                    foreach (var _count in model.ItemCountList)
                    {
                        dbContext.ItemCountMaster.Add(new EntityModels.ItemCountMaster
                        {
                            ItemId = _itemMasterRecord.Id,
                            ItemCount = _count.ItemCount,
                            CreatedBy = requestor,
                            CreatedDate = DateTime.Now,
                            IsActive = true
                        });
                        await dbContext.SaveChangesAsync();
                    }
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Item created successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> CreateParty(string requestor, PartyMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    if (dbContext.PartyMaster.Any(a => a.PartyName.ToLower() == model.PartyName.ToLower() 
                                                            && a.PartyGroupId == model.PartyGroupId && a.IsActive==true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Party already exists"
                        };
                    }

                    dbContext.PartyMaster.Add(new EntityModels.PartyMaster()
                    {
                        PartyName = model.PartyName,
                        PartyGroupId = model.PartyGroupId,
                        Panno = model.PanNo,
                        ContactNo = model.ContactNo,
                        Email = model.Email,
                        PartyAddress = model.PartyAddress,    
                        StateId = model.StateId,
                        CityId = model.CityId,
                        Pincode = model.Pincode,
                        CreditLimit = model.CreditLimit,
                        PaymentTerms = model.PaymentTerms,
                        StoreRentCalculationType = model.StoreRentCalculationType,
                        IsActive = true,
                        CreatedBy = requestor,
                        CreatedDate = DateTime.Now
                    });
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Party created successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> CreatePartyGroup(string requestor, PartyGroupMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    if (dbContext.PartyGroupMaster.Any(a => a.GroupName.ToLower() == model.GroupName.ToLower()                                                                                 
                                                                                && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Party group already exists"
                        };
                    }

                    dbContext.PartyGroupMaster.Add(new EntityModels.PartyGroupMaster()
                    {
                        GroupName = model.GroupName,
                        IsActive = true,
                        CreatedBy = requestor,
                        CreatedDate = DateTime.Now
                    });
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Party group created successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> DeleteArrivalPort(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _arrivalPortRecord = await dbContext.ArrivalPortMaster.Where(a => a.Id == id).FirstOrDefaultAsync();
                    if (_arrivalPortRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Arrival port not found"
                        };
                    }

                    _arrivalPortRecord.IsActive = false;
                    _arrivalPortRecord.UpdatedBy = requestor;
                    _arrivalPortRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_arrivalPortRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus =  System.Net.HttpStatusCode.OK,
                        Message = "Arrival port deleted successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> DeleteCountry(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _countryRecord = await dbContext.CountryMaster.Where(a => a.Id == id).FirstOrDefaultAsync();
                    if (_countryRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Country not found"
                        };
                    }

                    _countryRecord.IsActive = false;
                    _countryRecord.UpdatedBy = requestor;
                    _countryRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_countryRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Country deleted successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> DeleteDocumentStatus(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _documentStatusRecord = await dbContext.DocumentStatusMaster.Where(a => a.Id == id).FirstOrDefaultAsync();
                    if (_documentStatusRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Document status not found"
                        };
                    }

                    _documentStatusRecord.IsActive = false;
                    _documentStatusRecord.UpdatedBy = requestor;
                    _documentStatusRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_documentStatusRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Document status deleted successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> DeleteItem(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _itemRecord = await dbContext.ItemMaster.Where(a => a.Id == id).FirstOrDefaultAsync();
                    if (_itemRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Item not found"
                        };
                    }

                    _itemRecord.IsActive = false;
                    _itemRecord.UpdatedBy = requestor;
                    _itemRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_itemRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    var _itemBrands = await dbContext.ItemBrandMaster.Where(i => i.ItemId == id && i.IsActive == true).ToListAsync();

                    foreach (var _brand in _itemBrands)
                    {
                        _brand.IsActive = false;
                        _brand.UpdatedBy = requestor;
                        _brand.UpdatedDate = DateTime.Now;
                        dbContext.Entry(_brand).State = EntityState.Modified;
                        await dbContext.SaveChangesAsync();
                    }

                    var _itemPackings = await dbContext.ItemPackingMaster.Where(i => i.ItemId == id && i.IsActive == true).ToListAsync();

                    foreach (var _packing in _itemPackings)
                    {
                        _packing.IsActive = false;
                        _packing.UpdatedBy = requestor;
                        _packing.UpdatedDate = DateTime.Now;
                        dbContext.Entry(_packing).State = EntityState.Modified;
                        await dbContext.SaveChangesAsync();
                    }
                    var _itemCounts = await dbContext.ItemCountMaster.Where(i => i.ItemId == id && i.IsActive == true).ToListAsync();

                    foreach (var _count in _itemCounts)
                    {
                        _count.IsActive = false;
                        _count.UpdatedBy = requestor;
                        _count.UpdatedDate = DateTime.Now;
                        dbContext.Entry(_count).State = EntityState.Modified;
                        await dbContext.SaveChangesAsync();
                    }

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Item deleted successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> DeleteParty(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _partyRecord = await dbContext.PartyMaster.Where(a => a.Id == id).FirstOrDefaultAsync();
                    if (_partyRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Party not found"
                        };
                    }

                    _partyRecord.IsActive = false;
                    _partyRecord.UpdatedBy = requestor;
                    _partyRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_partyRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Party deleted successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> DeletePartyGroup(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _partyGroupRecord = await dbContext.PartyGroupMaster.Where(a => a.Id == id).FirstOrDefaultAsync();
                    if (_partyGroupRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Party group not found"
                        };
                    }

                    _partyGroupRecord.IsActive = false;
                    _partyGroupRecord.UpdatedBy = requestor;
                    _partyGroupRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_partyGroupRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Party group deleted successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<ArrivalPortMasterDALModel> GetArrivalPortMaster(string requestor)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _arrivalPortMasterRecords = await dbContext.ArrivalPortMaster.Where(a => a.IsActive == true)
                                                                        .Select(x => new ArrivalPortMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            City = x.City,
                                                                            CreatedDate = x.CreatedDate,
                                                                            CreatedBy = x.CreatedBy
                                                                        }).ToListAsync();

                    return new ArrivalPortMasterDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        ArrivalPortDetails = _arrivalPortMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new ArrivalPortMasterDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        ArrivalPortDetails = null,
                        Message = ex.Message
                    };
                }                
            }            
        }

        public async Task<ArrivalPortSingleDALModel> GetArrivalPortById(string requestor,int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _arrivalPortMasterRecords = await dbContext.ArrivalPortMaster.Where(a => a.Id == id && a.IsActive == true)
                                                                        .Select(x => new ArrivalPortMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            City = x.City,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).FirstOrDefaultAsync();

                    return new ArrivalPortSingleDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        ArrivalPortDetails = _arrivalPortMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new ArrivalPortSingleDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        ArrivalPortDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<CountryMasterDALModel> GetCountryMaster(string requestor)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _countryMasterRecords = await dbContext.CountryMaster.Where(a => a.IsActive == true)
                                                                        .Select(x => new CountryMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            Country = x.Country,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).ToListAsync();

                    return new CountryMasterDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        CountryDetails = _countryMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new CountryMasterDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        CountryDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }


        public async Task<StateMasterDALModel> GetStateMaster(string requestor)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _stateMasterRecords = await dbContext.StateMaster.Where(a => a.IsActive == true)
                                                                        .Select(x => new StateMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            StateName = x.StateName,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).ToListAsync();

                    return new StateMasterDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        StateDetails = _stateMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new StateMasterDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        StateDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<CityMasterDALModel> GetCityMaster(string requestor,int stateId)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _cityMasterRecords = await dbContext.CityMaster.Include(c=>c.State).Where(a => a.StateId == stateId && a.IsActive == true)
                                                                        .Select(x => new CityMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            CityName = x.CityName,
                                                                            StateId = x.StateId,
                                                                            StateName = x.State.StateName,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).ToListAsync();

                    return new CityMasterDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        CityDetails = _cityMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new CityMasterDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        CityDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<CountrySingleDALModel> GetCountryById(string requestor,int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _countryMasterRecords = await dbContext.CountryMaster.Where(a => a.Id == id && a.IsActive == true)
                                                                        .Select(x => new CountryMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            Country = x.Country,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).FirstOrDefaultAsync();

                    return new CountrySingleDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        CountryDetails = _countryMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new CountrySingleDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        CountryDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<DocumentStatusMasterDALModel> GetDocumentStatusMaster(string requestor)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _documentStatusMasterRecords = await dbContext.DocumentStatusMaster.Where(a => a.IsActive == true)
                                                                        .Select(x => new DocumentStatusMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            DocStatus = x.DocStatus
                                                                        }).ToListAsync();

                    return new DocumentStatusMasterDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        DocumentStatusDetails = _documentStatusMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new DocumentStatusMasterDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        DocumentStatusDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<ItemMasterDALModel> GetItemMaster(string requestor)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _itemMasterRecords = await dbContext.ItemMaster.Include(i=>i.ItemGroup).Include(i=>i.ItemBrandMaster)
                                                                        .Include(i=>i.ItemPackingMaster)
                                                                        .Include(i => i.ItemCountMaster)
                                                                        .Where(a => a.IsActive == true)
                                                                        .Select(x => new ItemMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            ItemGroupId = x.ItemGroupId,
                                                                            ItemGroupName = x.ItemGroup.ItemGroupName,
                                                                            ItemName = x.ItemName,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate,
                                                                            ItemBrandList = x.ItemBrandMaster.Where(i => i.IsActive == true).Select(g=>new ItemBrandMasterModel()
                                                                            { 
                                                                                Id = g.Id,
                                                                                ItemBrandName = g.ItemBrandName
                                                                            }).ToList(),
                                                                            ItemPackingList = x.ItemPackingMaster.Where(i => i.IsActive == true).Select(p => new ItemPackingMasterModel()
                                                                            {
                                                                                Id = p.Id,
                                                                                ItemPacking = p.ItemPacking
                                                                            }).ToList(),
                                                                            ItemCountList = x.ItemCountMaster.Where(i => i.IsActive == true).Select(p => new ItemCountMasterModel()
                                                                            {
                                                                                Id = p.Id,
                                                                                ItemCount = p.ItemCount
                                                                            }).ToList()
                                                                        }).ToListAsync();

                    return new ItemMasterDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        ItemDetails = _itemMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new ItemMasterDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        ItemDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<ItemSingleDALModel> GetItemById(string requestor,int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _itemMasterRecords = await dbContext.ItemMaster.Include(i => i.ItemGroup).Include(i => i.ItemBrandMaster)
                                                                        .Include(i => i.ItemPackingMaster)
                                                                        .Include(i => i.ItemCountMaster)
                                                                        .Where(a => a.Id == id && a.IsActive == true)
                                                                        .Select(x => new ItemMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            ItemGroupId = x.ItemGroupId,
                                                                            ItemGroupName = x.ItemGroup.ItemGroupName,
                                                                            ItemName = x.ItemName,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate,
                                                                            ItemBrandList = x.ItemBrandMaster.Where(i=>i.IsActive == true).Select(g => new ItemBrandMasterModel()
                                                                            {
                                                                                Id = g.Id,
                                                                                ItemBrandName = g.ItemBrandName
                                                                            }).ToList(),
                                                                            ItemPackingList = x.ItemPackingMaster.Where(i => i.IsActive == true).Select(p => new ItemPackingMasterModel()
                                                                            {
                                                                                Id = p.Id,
                                                                                ItemPacking = p.ItemPacking
                                                                            }).ToList(),
                                                                            ItemCountList = x.ItemCountMaster.Where(i => i.IsActive == true).Select(p => new ItemCountMasterModel()
                                                                            {
                                                                                Id = p.Id,
                                                                                ItemCount = p.ItemCount
                                                                            }).ToList(),
                                                                        }).FirstOrDefaultAsync();

                    return new ItemSingleDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        ItemDetails = _itemMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new ItemSingleDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        ItemDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }


        public async Task<PartyGroupMasterDALModel> GetPartyGroupMaster(string requestor)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _partyGroupMasterRecords = await dbContext.PartyGroupMaster.Where(a => a.IsActive == true)
                                                                        .Select(x => new PartyGroupMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            GroupName = x.GroupName,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).ToListAsync();

                    return new PartyGroupMasterDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        PartyGroupDetails = _partyGroupMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new PartyGroupMasterDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        PartyGroupDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<PartyGroupSingleDALModel> GetPartyGroupById(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _partyGroupMasterRecords = await dbContext.PartyGroupMaster.Where(a => a.Id == id && a.IsActive == true)
                                                                        .Select(x => new PartyGroupMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            GroupName = x.GroupName,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).FirstOrDefaultAsync();

                    return new PartyGroupSingleDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        PartyGroupDetails = _partyGroupMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new PartyGroupSingleDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        PartyGroupDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<PartyMasterDALModel> GetPartyMaster(string requestor)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _partyMasterRecords = await dbContext.PartyMaster.Include(p=>p.PartyGroup)
                                                                            .Include(p=>p.State)
                                                                            .Include(p => p.City).Where(a => a.IsActive == true)
                                                                        .Select(x => new PartyMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            PartyName = x.PartyName,
                                                                            PartyGroupId = x.PartyGroupId,
                                                                            PartyGroupName = x.PartyGroup.GroupName,
                                                                            ContactNo = x.ContactNo,
                                                                            Email = x.Email,
                                                                            PartyAddress = x.PartyAddress,
                                                                            StateId = x.StateId,
                                                                            StateName = x.State.StateName,
                                                                            CityId = x.CityId,
                                                                            CityName = x.City.CityName,
                                                                            PanNo = x.Panno,
                                                                            Pincode = x.Pincode,
                                                                            CreditLimit = x.CreditLimit,
                                                                            PaymentTerms = x.PaymentTerms,                                                                            
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).ToListAsync();

                    return new PartyMasterDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        PartyDetails = _partyMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new PartyMasterDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        PartyDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<PartySingleDALModel> GetPartyById(string requestor,int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _partyMasterRecords = await dbContext.PartyMaster.Include(p => p.PartyGroup)
                        .Include(p => p.State).Include(p => p.City).Where(a => a.Id == id && a.IsActive == true)
                                                                        .Select(x => new PartyMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            PartyName = x.PartyName,
                                                                            PartyGroupId = x.PartyGroupId,                                                                            
                                                                            PartyGroupName = x.PartyGroup.GroupName,
                                                                            ContactNo = x.ContactNo,
                                                                            Email = x.Email,
                                                                            PartyAddress = x.PartyAddress,
                                                                            StateId = x.StateId,
                                                                            StateName = x.State.StateName,
                                                                            CityId = x.CityId,
                                                                            CityName = x.City.CityName,
                                                                            PanNo = x.Panno,
                                                                            Pincode = x.Pincode,
                                                                            CreditLimit = x.CreditLimit,
                                                                            PaymentTerms = x.PaymentTerms,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).FirstOrDefaultAsync();

                    return new PartySingleDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        PartyDetails = _partyMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new PartySingleDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        PartyDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> UpdateArrivalPort(string requestor, ArrivalPortMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _arrivalPortRecord = await dbContext.ArrivalPortMaster.Where(a => a.Id == model.Id).FirstOrDefaultAsync();
                    if (_arrivalPortRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Arrival port not found"
                        };
                    }

                    if (dbContext.ArrivalPortMaster.Any(a => a.City.ToLower() == model.City.ToLower() && a.Id != model.Id && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Arrival port already exists"
                        };
                    }

                    _arrivalPortRecord.City = model.City;
                    _arrivalPortRecord.IsActive = true;
                    _arrivalPortRecord.UpdatedBy = requestor;
                    _arrivalPortRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_arrivalPortRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Arrival port updated successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> UpdateCountry(string requestor, CountryMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _countryRecord = await dbContext.CountryMaster.Where(a => a.Id == model.Id).FirstOrDefaultAsync();
                    if (_countryRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Country not found"
                        };
                    }

                    if (dbContext.CountryMaster.Any(a => a.Country.ToLower() == model.Country.ToLower() && a.Id != model.Id && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Country already exists"
                        };
                    }

                    _countryRecord.Country = model.Country;
                    _countryRecord.IsActive = true;
                    _countryRecord.UpdatedBy = requestor;
                    _countryRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_countryRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Country updated successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> UpdateDocumentStatus(string requestor, DocumentStatusMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _documentStatusRecord = await dbContext.DocumentStatusMaster.Where(a => a.Id == model.Id).FirstOrDefaultAsync();
                    if (_documentStatusRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Document status not found"
                        };
                    }

                    if (dbContext.DocumentStatusMaster.Any(a => a.DocStatus.ToLower() == model.DocStatus.ToLower() && a.Id != model.Id && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Document status already exists"
                        };
                    }

                    _documentStatusRecord.DocStatus = model.DocStatus;
                    _documentStatusRecord.IsActive = true;
                    _documentStatusRecord.UpdatedBy = requestor;
                    _documentStatusRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_documentStatusRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Document status updated successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> UpdateItem(string requestor, ItemMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _itemRecord = await dbContext.ItemMaster.Where(a => a.Id == model.Id).FirstOrDefaultAsync();
                    if (_itemRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Item not found"
                        };
                    }

                    if (dbContext.ItemMaster.Any(a => a.ItemGroupId == model.ItemGroupId && a.ItemName.ToLower() == model.ItemName.ToLower() && a.Id != model.Id && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Item already exists"
                        };
                    }


                    _itemRecord.ItemGroupId = model.ItemGroupId;
                    _itemRecord.ItemName = model.ItemName;
                    _itemRecord.IsActive = true;
                    _itemRecord.UpdatedBy = requestor;
                    _itemRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_itemRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();


                    var _itemBrands = await dbContext.ItemBrandMaster.Where(i => i.ItemId == model.Id && i.IsActive == true).ToListAsync();

                    foreach (var _brand in _itemBrands)
                    {
                        _brand.IsActive = false;
                        _brand.UpdatedBy = requestor;
                        _brand.UpdatedDate = DateTime.Now;
                        dbContext.Entry(_brand).State = EntityState.Modified;
                        await dbContext.SaveChangesAsync();
                    }

                    var _itemPackings = await dbContext.ItemPackingMaster.Where(i => i.ItemId == model.Id && i.IsActive == true).ToListAsync();

                    foreach (var _packing in _itemPackings)
                    {
                        _packing.IsActive = false;
                        _packing.UpdatedBy = requestor;
                        _packing.UpdatedDate = DateTime.Now;
                        dbContext.Entry(_packing).State = EntityState.Modified;
                        await dbContext.SaveChangesAsync();
                    }

                    var _itemCounts = await dbContext.ItemCountMaster.Where(i => i.ItemId == model.Id && i.IsActive == true).ToListAsync();

                    foreach (var _count in _itemCounts)
                    {
                        _count.IsActive = false;
                        _count.UpdatedBy = requestor;
                        _count.UpdatedDate = DateTime.Now;
                        dbContext.Entry(_count).State = EntityState.Modified;
                        await dbContext.SaveChangesAsync();
                    }


                    foreach (var _brand in model.ItemBrandList)
                    {
                        dbContext.ItemBrandMaster.Add(new EntityModels.ItemBrandMaster
                        {
                            ItemId = model.Id.Value,
                            ItemBrandName = _brand.ItemBrandName,
                            CreatedBy = requestor,
                            CreatedDate = DateTime.Now,
                            IsActive = true
                        });
                        await dbContext.SaveChangesAsync();
                    }
                    foreach (var _packing in model.ItemPackingList)
                    {
                        dbContext.ItemPackingMaster.Add(new EntityModels.ItemPackingMaster
                        {
                            ItemId = model.Id.Value,
                            ItemPacking = _packing.ItemPacking,
                            CreatedBy = requestor,
                            CreatedDate = DateTime.Now,
                            IsActive = true
                        });
                        await dbContext.SaveChangesAsync();
                    }
                    foreach (var _count in model.ItemCountList)
                    {
                        dbContext.ItemCountMaster.Add(new EntityModels.ItemCountMaster
                        {
                            ItemId = model.Id.Value,
                            ItemCount = _count.ItemCount,
                            CreatedBy = requestor,
                            CreatedDate = DateTime.Now,
                            IsActive = true
                        });
                        await dbContext.SaveChangesAsync();
                    }

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Item updated successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> UpdateParty(string requestor, PartyMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _partyRecord = await dbContext.PartyMaster.Where(a => a.Id == model.Id).FirstOrDefaultAsync();
                    if (_partyRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Party not found"
                        };
                    }

                    if (dbContext.PartyMaster.Any(a => a.PartyName.ToLower() == model.PartyName.ToLower()
                                                                                    && a.PartyGroupId == model.PartyGroupId
                                                                                    && a.Id != model.Id && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Party already exists"
                        };
                    }

                    _partyRecord.PartyName = model.PartyName;
                    _partyRecord.PartyGroupId = model.PartyGroupId;
                    _partyRecord.Panno = model.PanNo;
                    _partyRecord.PartyAddress = model.PartyAddress;
                    _partyRecord.StateId = model.StateId;
                    _partyRecord.CityId = model.CityId;
                    _partyRecord.Pincode = model.Pincode;
                    _partyRecord.Panno = model.PanNo;
                    _partyRecord.CreditLimit = model.CreditLimit;
                    _partyRecord.PaymentTerms = model.PaymentTerms;
                    _partyRecord.ContactNo = model.ContactNo;
                    _partyRecord.Email = model.Email;
                    _partyRecord.StoreRentCalculationType = model.StoreRentCalculationType;
                    _partyRecord.IsActive = true;
                    _partyRecord.UpdatedBy = requestor;
                    _partyRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_partyRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Party updated successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }

        public async Task<BaseDALStatus> UpdatePartyGroup(string requestor, PartyGroupMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _partyGroupRecord = await dbContext.PartyGroupMaster.Where(a => a.Id == model.Id).FirstOrDefaultAsync();
                    if (_partyGroupRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Party group not found"
                        };
                    }

                    if (dbContext.PartyGroupMaster.Any(a => a.GroupName.ToLower() == model.GroupName.ToLower()                                                                                    
                                                                                    && a.Id != model.Id && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Party group already exists"
                        };
                    }

                    _partyGroupRecord.GroupName = model.GroupName;                    
                    _partyGroupRecord.IsActive = true;
                    _partyGroupRecord.UpdatedBy = requestor;
                    _partyGroupRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_partyGroupRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Party group updated successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }


        public async Task<BaseDALStatus> CreateItemGroup(string requestor, ItemGroupMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    if (dbContext.ItemGroupMaster.Any(a => a.ItemGroupName.ToLower() == model.ItemGroupName.ToLower() && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Item group already exists"
                        };
                    }

                    dbContext.ItemGroupMaster.Add(new EntityModels.ItemGroupMaster()
                    {
                        ItemGroupName = model.ItemGroupName,
                        IsActive = true,
                        CreatedBy = requestor,
                        CreatedDate = DateTime.Now
                    });
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Item group created successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<BaseDALStatus> UpdateItemGroup(string requestor, ItemGroupMasterModel model)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _itemGroupRecord = await dbContext.ItemGroupMaster.Where(a => a.Id == model.Id).FirstOrDefaultAsync();
                    if (_itemGroupRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Item group not found"
                        };
                    }

                    if (dbContext.ItemGroupMaster.Any(a => a.ItemGroupName.ToLower() == model.ItemGroupName.ToLower() && a.Id != model.Id && a.IsActive == true))
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Item group already exists"
                        };
                    }

                    _itemGroupRecord.ItemGroupName = model.ItemGroupName;
                    _itemGroupRecord.IsActive = true;
                    _itemGroupRecord.UpdatedBy = requestor;
                    _itemGroupRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_itemGroupRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Item group updated successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<BaseDALStatus> DeleteItemGroup(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _itemGroupRecord = await dbContext.ItemGroupMaster.Where(a => a.Id == id).FirstOrDefaultAsync();
                    if (_itemGroupRecord == null)
                    {
                        return new BaseDALStatus()
                        {
                            AdditionalStatusCode = 201,
                            HttpStatus = System.Net.HttpStatusCode.OK,
                            Message = "Item group not found"
                        };
                    }

                    _itemGroupRecord.IsActive = false;
                    _itemGroupRecord.UpdatedBy = requestor;
                    _itemGroupRecord.UpdatedDate = DateTime.Now;
                    dbContext.Entry(_itemGroupRecord).State = EntityState.Modified;
                    await dbContext.SaveChangesAsync();

                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        Message = "Item group deleted successfully"
                    };
                }
                catch (Exception ex)
                {
                    return new BaseDALStatus()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<ItemGroupMasterDALModel> GetItemGroupMaster(string requestor)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _itemGroupMasterRecords = await dbContext.ItemGroupMaster.Where(a => a.IsActive == true)
                                                                        .Select(x => new ItemGroupMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            ItemGroupName = x.ItemGroupName,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).ToListAsync();

                    return new ItemGroupMasterDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        ItemGroupDetails = _itemGroupMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new ItemGroupMasterDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        ItemGroupDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }
        public async Task<ItemGroupSingleDALModel> GetItemGroupById(string requestor, int id)
        {
            using (var dbContext = new LMD_DataContext(LMD_DataContext.option.Options, requestor))
            {
                try
                {
                    var _itemGroupMasterRecords = await dbContext.ItemGroupMaster.Where(a => a.Id == id && a.IsActive == true)
                                                                        .Select(x => new ItemGroupMasterModel()
                                                                        {
                                                                            Id = x.Id,
                                                                            ItemGroupName = x.ItemGroupName,
                                                                            CreatedBy = x.CreatedBy,
                                                                            CreatedDate = x.CreatedDate
                                                                        }).FirstOrDefaultAsync();

                    return new ItemGroupSingleDALModel()
                    {
                        AdditionalStatusCode = 200,
                        HttpStatus = System.Net.HttpStatusCode.OK,
                        ItemGroupDetails = _itemGroupMasterRecords,
                        Message = "Success"
                    };
                }
                catch (Exception ex)
                {
                    return new ItemGroupSingleDALModel()
                    {
                        AdditionalStatusCode = 500,
                        HttpStatus = System.Net.HttpStatusCode.InternalServerError,
                        ItemGroupDetails = null,
                        Message = ex.Message
                    };
                }
            }
        }
    }
}

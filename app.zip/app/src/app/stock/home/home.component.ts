import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/auth.service';
import { UserDetailEntityService } from 'src/app/shared/service/user-entity.service';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private userDetailEntityService : UserDetailEntityService,private authService : AuthService) { }

  ngOnInit(): void {
    this.userDetailEntityService.getAll().subscribe(data => {    
      this.authService.setUserDetail(data[0]);
    });
  }

}

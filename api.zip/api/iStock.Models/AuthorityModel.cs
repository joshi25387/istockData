﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iStock.Models
{
    public class AuthorityModel
    {
        public string RoutePath { get; set; }
        public string MenuName { get; set; }
    }
}

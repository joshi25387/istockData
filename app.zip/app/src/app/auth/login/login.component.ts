import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Store, select } from '@ngrx/store';
import { AppState } from 'src/app/reducers';
import { authenticateUser, loginState, resetErrorMessage, logout } from '../auth.actions';
import { hideSideNav, toggleSideNav } from 'src/app/side-nav/side-nav.actions';
import { Observable, empty, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm : FormGroup;
  error$ : Observable<string>;

  constructor(private fb : FormBuilder, private store : Store<AppState>,
    private spinner : NgxSpinnerService) { }

  ngOnInit(): void {
    this.store.dispatch(logout());


    this.error$ = this.store.pipe(select(loginState)).pipe(
                        tap(loginState => {
                          if(loginState.errorMessage!=""){
                            this.spinner.hide();                    
                          }                          
                        }),
                        map(loginState => loginState.errorMessage)
                    );
                    
    // this.error$.subscribe((error)=>{
    //   console.log('error subscribe');     
    //   console.log('error message : ',error);
    // });

    this.loginForm = this.fb.group({
      userId : ['',Validators.required],
      password : ['',Validators.required]
    });

    
    
  }

  login(){
    const formValue = this.loginForm.value;    
    if(this.loginForm.valid){ 
      

      this.spinner.show();

      this.store.dispatch(authenticateUser({userId : formValue.userId,password : formValue.password}));

      
    }    
  }

  closeAlert(){
    this.store.dispatch(resetErrorMessage());
  }

}

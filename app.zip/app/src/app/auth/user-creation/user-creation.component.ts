import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { ClientStoreService } from 'src/app/shared/service/client-store.service';
import { SharedService } from 'src/app/shared/service/shared.service';
import { AuthService } from '../auth.service';

import { UserClientModel, UserStoreModel } from '../models/client-store.model';
import { UserCreationModel, UserInfoModel, UserRoleModel } from '../models/user.model';
import { UserDataStorage } from '../services/user-data-storage.service';

@Component({
  selector: 'user-creation',
  templateUrl: './user-creation.component.html',
  styleUrls: ['./user-creation.component.css']
})
export class UserCreationComponent implements OnInit {

  userCreationForm: FormGroup;
  alertMessage: string = null;
    
  editMode : boolean = false;

  roleList$ : Observable<UserRoleModel[]>;
  roleList : UserRoleModel[] = [];
  
  clientList$ : Observable<UserClientModel[]>;
  storeList$ : Observable<UserStoreModel[]> = of([]);

  cardText : string = "User Registration";
  buttonText: string = "Submit";

  newUser: UserCreationModel;
  
  constructor(private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,        
    private authService : AuthService,
    private sharedService: SharedService,
    private clientStoreService : ClientStoreService,
    private userDataStorage : UserDataStorage,
    private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.userCreationForm = this.fb.group({
      id: [''],
      userId: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      mobileNo: ['', [Validators.required]],
      roleId: ['', Validators.required],
      // isClient: ['', Validators.required],
      // isClientAdmin: ['', Validators.required],
      // isAdmin: ['', Validators.required],
      clientId : ['', Validators.required],
      storeId : ['', Validators.required]
      //deviceId : ['']
    });


    this.clientList$ = this.clientStoreService.GetUserClientList();    

    this.roleList$ = this.authService.getRoles();

    this.roleList$.subscribe(roles => {
      this.roleList = roles;
    });

    this.userCreationForm.get('clientId').valueChanges.subscribe(clientId => {
        let _clientId = +clientId;
        this.storeList$ = of([]);
        if(_clientId > 0){
            this.storeList$ = this.clientStoreService.GetUserStoreList(_clientId);            
        }
        
    });

    this.route.queryParams.subscribe(params => {
      if(params['id']){
        this.spinner.show();
        let _userToEdit : UserInfoModel = this.userDataStorage.userToEdit;

        if(_userToEdit && _userToEdit.userId == params['id']){
            console.log('_userToEdit : ',_userToEdit);
            this.userCreationForm.patchValue({
              id: _userToEdit.id,
              userId: _userToEdit.userId,
              firstName: _userToEdit.firstName,
              lastName: _userToEdit.lastName,
              emailId: _userToEdit.emailId,
              mobileNo: _userToEdit.contactNo,
              roleId: _userToEdit.roleId,
              // isClient: _userToEdit.isClient,
              // isClientAdmin: _userToEdit.isClientAdmin,
              // isAdmin: _userToEdit.isAdmin,
              clientId : _userToEdit.clientId == null ? '' : _userToEdit.clientId,
              storeId : _userToEdit.storeId == null ? '' : _userToEdit.storeId
              //deviceId : _userToEdit.deviceId
            });

            this.cardText = "User Updation";
            this.buttonText = "Update";
            this.editMode = true;
            this.userCreationForm.get('userId').disable();
        }
        else{
          this.router.navigate(['/user/user-management']);
        }
        this.spinner.hide();
      }
    });

  }

  get f() { return this.userCreationForm.controls; }

  onSubmit(){
    if(this.userCreationForm.valid){

        this.spinner.show();

        let _isClient : boolean = false;
        let _isClientAdmin : boolean = false;
        let _isAdmin : boolean = false;

        let _selectedRoleName : string = this.roleList.filter(r=>r.id == this.userCreationForm.get('roleId').value)[0].name;
      

        console.log('_selectedRoleName : ',_selectedRoleName);


        if(_selectedRoleName.toLowerCase() == 'client'){
          _isClient = true;
          _isClientAdmin = false;
          _isAdmin = false;
        }
        else if(_selectedRoleName.toLowerCase() == 'clientadmin'){
          _isClient = true;
          _isClientAdmin = true;
          _isAdmin = false;
        }
        else if(_selectedRoleName.toLowerCase() == 'admin'){
          _isClient = false;
          _isClientAdmin = false;
          _isAdmin = true;
        }
        else{
          _isClient = false;
          _isClientAdmin = false;
          _isAdmin = false;
        }

        this.newUser = {
            userName : this.userCreationForm.get('userId').value.toString().trim(),
            firstName : this.userCreationForm.get('firstName').value.toString().trim(),
            lastName : this.userCreationForm.get('lastName').value.toString().trim(),
            mobileNumber : this.userCreationForm.get('mobileNo').value,
            email : this.userCreationForm.get('emailId').value.toString().trim(),
            isAdmin : _isAdmin,
            isClientAdmin : _isClientAdmin,
            isClient : _isClient,
            clientId : this.userCreationForm.get('clientId').value,
            storeId : this.userCreationForm.get('storeId').value,
            roleId : this.userCreationForm.get('roleId').value,
            //deviceId : this.userCreationForm.get('deviceId').value,
            isActive : true
        }

        if(!this.editMode){
          this.authService.createUser(this.newUser).subscribe(response => {
            console.log('response : ',response);
            this.spinner.hide();
            this.alertMessage = "User created successfully";
            this.userCreationForm.reset();
            this.userCreationForm.patchValue({
                // 'isAdmin' : '',
                // 'isClientAdmin' : '',
                // 'isClient' : '',
                'roleId' : '',
                'clientId' : '',
                'storeId' : '',
                //'deviceId' : ''
            });
          },
          error=>{
              this.spinner.hide();
              this.alertMessage = error.error[0].description;
              console.log('error : ',error);
          });
        }
        else{
          this.authService.updateUser(this.newUser).subscribe(response => {
            console.log('response : ',response);
            this.spinner.hide();
            this.alertMessage = "User updated successfully";
            this.userCreationForm.reset();
            this.userCreationForm.patchValue({
                // 'isAdmin' : '',
                // 'isClientAdmin' : '',
                // 'isClient' : '',
                'roleId' : '',
                'clientId' : '',
                'storeId' : '',
                //'deviceId' : ''
            });
            this.router.navigate(['/user/user-management']);
          },
          error=>{
              this.spinner.hide();
              this.alertMessage = error.error[0].description;
              console.log('error : ',error);
          });
        }        
    }
    else{
        this.alertMessage = "Please provide all details";
    }
  }

  closeAlert(){
      this.alertMessage = null;
  }

}
